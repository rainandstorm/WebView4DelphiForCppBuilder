﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVInterfaces.pas' rev: 36.00 (Windows)

#ifndef UwvinterfacesHPP
#define UwvinterfacesHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvinterfaces
{
//-- forward type declarations -----------------------------------------------
__interface DELPHIINTERFACE IWVLoaderEvents;
typedef System::DelphiInterface<IWVLoaderEvents> _di_IWVLoaderEvents;
__interface DELPHIINTERFACE IWVBrowserEvents;
typedef System::DelphiInterface<IWVBrowserEvents> _di_IWVBrowserEvents;
//-- type declarations -------------------------------------------------------
__interface  INTERFACE_UUID("{5B91E1BB-CA98-476E-A2F0-10BDED27A916}") IWVLoaderEvents  : public System::IInterface 
{
	virtual HRESULT __fastcall EnvironmentCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2Environment result_) = 0 ;
	virtual HRESULT __fastcall NewBrowserVersionAvailableEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall BrowserProcessExitedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs args) = 0 ;
	virtual HRESULT __fastcall ProcessInfosChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const System::_di_IInterface args) = 0 ;
};

__interface  INTERFACE_UUID("{4E06D91F-1213-46C1-ABB8-D41D8CC19E81}") IWVBrowserEvents  : public System::IInterface 
{
	virtual HRESULT __fastcall EnvironmentCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2Environment result_) = 0 ;
	virtual HRESULT __fastcall ControllerCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2Controller result_) = 0 ;
	virtual HRESULT __fastcall ExecuteScriptCompletedHandler_Invoke(HRESULT errorCode, System::WideChar * result_, int aExecutionID) = 0 ;
	virtual HRESULT __fastcall CapturePreviewCompletedHandler_Invoke(HRESULT errorCode) = 0 ;
	virtual HRESULT __fastcall NavigationStartingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs args) = 0 ;
	virtual HRESULT __fastcall NavigationCompletedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs args) = 0 ;
	virtual HRESULT __fastcall SourceChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventArgs args) = 0 ;
	virtual HRESULT __fastcall HistoryChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall ContentLoadingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs args) = 0 ;
	virtual HRESULT __fastcall DocumentTitleChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall NewWindowRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs args) = 0 ;
	virtual HRESULT __fastcall FrameNavigationStartingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs args) = 0 ;
	virtual HRESULT __fastcall FrameNavigationCompletedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs args) = 0 ;
	virtual HRESULT __fastcall WebResourceRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventArgs args) = 0 ;
	virtual HRESULT __fastcall ScriptDialogOpeningEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventArgs args) = 0 ;
	virtual HRESULT __fastcall PermissionRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs args) = 0 ;
	virtual HRESULT __fastcall ProcessFailedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs args) = 0 ;
	virtual HRESULT __fastcall WebMessageReceivedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs args) = 0 ;
	virtual HRESULT __fastcall ContainsFullScreenElementChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall WindowCloseRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall ZoomFactorChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall MoveFocusRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventArgs args) = 0 ;
	virtual HRESULT __fastcall AcceleratorKeyPressedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventArgs args) = 0 ;
	virtual HRESULT __fastcall GotFocusEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall LostFocusEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall DevToolsProtocolEventReceivedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventArgs args, const Uwvtypes::wvstring aEventName, int aEventID) = 0 ;
	virtual HRESULT __fastcall CreateCoreWebView2CompositionControllerCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2CompositionController result_) = 0 ;
	virtual HRESULT __fastcall CursorChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2CompositionController sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall BrowserProcessExitedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs args) = 0 ;
	virtual HRESULT __fastcall RasterizationScaleChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall WebResourceResponseReceivedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventArgs args) = 0 ;
	virtual HRESULT __fastcall DOMContentLoadedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs args) = 0 ;
	virtual HRESULT __fastcall WebResourceResponseViewGetContentCompletedHandler_Invoke(HRESULT errorCode, const _di_IStream result_, int aResourceID) = 0 ;
	virtual HRESULT __fastcall GetCookiesCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2CookieList result_) = 0 ;
	virtual HRESULT __fastcall TrySuspendCompletedHandler_Invoke(HRESULT errorCode, int result_) = 0 ;
	virtual HRESULT __fastcall FrameCreatedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs args) = 0 ;
	virtual HRESULT __fastcall DownloadStartingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventArgs args) = 0 ;
	virtual HRESULT __fastcall ClientCertificateRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventArgs args) = 0 ;
	virtual HRESULT __fastcall PrintToPdfCompletedHandler_Invoke(HRESULT errorCode, int result_) = 0 ;
	virtual HRESULT __fastcall BytesReceivedChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation sender, const System::_di_IInterface args, int aDownloadID) = 0 ;
	virtual HRESULT __fastcall EstimatedEndTimeChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation sender, const System::_di_IInterface args, int aDownloadID) = 0 ;
	virtual HRESULT __fastcall StateChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation sender, const System::_di_IInterface args, int aDownloadID) = 0 ;
	virtual HRESULT __fastcall FrameNameChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const System::_di_IInterface args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall FrameDestroyedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const System::_di_IInterface args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall CallDevToolsProtocolMethodCompletedHandler_Invoke(HRESULT errorCode, System::WideChar * result_, int aExecutionID) = 0 ;
	virtual HRESULT __fastcall AddScriptToExecuteOnDocumentCreatedCompletedHandler_Invoke(HRESULT errorCode, System::WideChar * id) = 0 ;
	virtual HRESULT __fastcall IsMutedChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall IsDocumentPlayingAudioChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall IsDefaultDownloadDialogOpenChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall ProcessInfosChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall FrameNavigationStartingEventHandler2_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall FrameNavigationCompletedEventHandler2_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall FrameContentLoadingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall FrameDOMContentLoadedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall FrameWebMessageReceivedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall BasicAuthenticationRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventArgs args) = 0 ;
	virtual HRESULT __fastcall ContextMenuRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventArgs args) = 0 ;
	virtual HRESULT __fastcall CustomItemSelectedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2ContextMenuItem sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall StatusBarTextChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall FramePermissionRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs2 args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall ClearBrowsingDataCompletedHandler_Invoke(HRESULT errorCode) = 0 ;
	virtual HRESULT __fastcall ClearServerCertificateErrorActionsCompletedHandler_Invoke(HRESULT errorCode) = 0 ;
	virtual HRESULT __fastcall ServerCertificateErrorDetectedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventArgs args) = 0 ;
	virtual HRESULT __fastcall FaviconChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall GetFaviconCompletedHandler_Invoke(HRESULT errorCode, const _di_IStream result_) = 0 ;
	virtual HRESULT __fastcall PrintCompletedHandler_Invoke(HRESULT errorCode, Uwvtypelibrary::COREWEBVIEW2_PRINT_STATUS result_) = 0 ;
	virtual HRESULT __fastcall PrintToPdfStreamCompletedHandler_Invoke(HRESULT errorCode, const _di_IStream result_) = 0 ;
	virtual HRESULT __fastcall GetNonDefaultPermissionSettingsCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2PermissionSettingCollectionView result_) = 0 ;
	virtual HRESULT __fastcall SetPermissionStateCompletedHandler_Invoke(HRESULT errorCode) = 0 ;
	virtual HRESULT __fastcall LaunchingExternalUriSchemeEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventArgs args) = 0 ;
	virtual HRESULT __fastcall GetProcessExtendedInfosCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2ProcessExtendedInfoCollection result_) = 0 ;
	virtual HRESULT __fastcall BrowserExtensionRemoveCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypes::wvstring aExtensionID) = 0 ;
	virtual HRESULT __fastcall BrowserExtensionEnableCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypes::wvstring aExtensionID) = 0 ;
	virtual HRESULT __fastcall ProfileAddBrowserExtensionCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2BrowserExtension result_) = 0 ;
	virtual HRESULT __fastcall ProfileGetBrowserExtensionsCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2BrowserExtensionList result_) = 0 ;
	virtual HRESULT __fastcall ProfileDeletedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Profile sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall ExecuteScriptWithResultCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptResult result_, int aExecutionID) = 0 ;
	virtual HRESULT __fastcall NonClientRegionChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2CompositionController sender, const Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventArgs args) = 0 ;
	virtual HRESULT __fastcall NotificationReceivedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventArgs args) = 0 ;
	virtual HRESULT __fastcall NotificationCloseRequestedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Notification sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall SaveAsUIShowingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventArgs args) = 0 ;
	virtual HRESULT __fastcall ShowSaveAsUICompletedHandler_Invoke(HRESULT errorCode, Uwvtypelibrary::COREWEBVIEW2_SAVE_AS_UI_RESULT result_) = 0 ;
	virtual HRESULT __fastcall SaveFileSecurityCheckStartingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventArgs args) = 0 ;
	virtual HRESULT __fastcall ScreenCaptureStartingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs args) = 0 ;
	virtual HRESULT __fastcall FrameScreenCaptureStartingEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall FrameChildFrameCreatedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs args, unsigned aFrameID) = 0 ;
	virtual HRESULT __fastcall FindActiveMatchIndexChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Find sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall FindMatchCountChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Find sender, const System::_di_IInterface args) = 0 ;
	virtual HRESULT __fastcall FindStartCompletedHandler_Invoke(HRESULT errorCode) = 0 ;
};

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvinterfaces */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVINTERFACES)
using namespace Uwvinterfaces;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvinterfacesHPP
