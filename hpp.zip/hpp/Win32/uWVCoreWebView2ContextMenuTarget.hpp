﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ContextMenuTarget.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2contextmenutargetHPP
#define Uwvcorewebview2contextmenutargetHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2contextmenutarget
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ContextMenuTarget;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ContextMenuTarget : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ContextMenuTarget FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVMenuTargetKind __fastcall GetKind();
	bool __fastcall GetIsEditable();
	bool __fastcall GetIsRequestedForMainFrame();
	Uwvtypes::wvstring __fastcall GetPageUri();
	Uwvtypes::wvstring __fastcall GetFrameUri();
	bool __fastcall GetHasLinkUri();
	Uwvtypes::wvstring __fastcall GetLinkUri();
	bool __fastcall GetHasLinkText();
	Uwvtypes::wvstring __fastcall GetLinkText();
	bool __fastcall GetHasSourceUri();
	Uwvtypes::wvstring __fastcall GetSourceUri();
	bool __fastcall GetHasSelection();
	Uwvtypes::wvstring __fastcall GetSelectionText();
	
public:
	__fastcall TCoreWebView2ContextMenuTarget(const Uwvtypelibrary::_di_ICoreWebView2ContextMenuTarget aBaseIntf);
	__fastcall virtual ~TCoreWebView2ContextMenuTarget();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ContextMenuTarget BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVMenuTargetKind Kind = {read=GetKind, nodefault};
	__property bool IsEditable = {read=GetIsEditable, nodefault};
	__property bool IsRequestedForMainFrame = {read=GetIsRequestedForMainFrame, nodefault};
	__property Uwvtypes::wvstring PageUri = {read=GetPageUri};
	__property Uwvtypes::wvstring FrameUri = {read=GetFrameUri};
	__property bool HasLinkUri = {read=GetHasLinkUri, nodefault};
	__property Uwvtypes::wvstring LinkUri = {read=GetLinkUri};
	__property bool HasLinkText = {read=GetHasLinkText, nodefault};
	__property Uwvtypes::wvstring LinkText = {read=GetLinkText};
	__property bool HasSourceUri = {read=GetHasSourceUri, nodefault};
	__property Uwvtypes::wvstring SourceUri = {read=GetSourceUri};
	__property bool HasSelection = {read=GetHasSelection, nodefault};
	__property Uwvtypes::wvstring SelectionText = {read=GetSelectionText};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2contextmenutarget */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2CONTEXTMENUTARGET)
using namespace Uwvcorewebview2contextmenutarget;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2contextmenutargetHPP
