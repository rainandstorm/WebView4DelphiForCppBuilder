﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Controller.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2controllerHPP
#define Uwvcorewebview2controllerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <System.UITypes.hpp>
#include <Winapi.Windows.hpp>
#include <System.SysUtils.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2controller
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Controller;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2Controller : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Controller FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2Controller2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2Controller3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2Controller4 FBaseIntf4;
	Uwvtypelibrary::EventRegistrationToken FAcceleratorKeyPressedToken;
	Uwvtypelibrary::EventRegistrationToken FGotFocusToken;
	Uwvtypelibrary::EventRegistrationToken FLostFocusToken;
	Uwvtypelibrary::EventRegistrationToken FMoveFocusRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FZoomFactorChangedToken;
	Uwvtypelibrary::EventRegistrationToken FRasterizationScaleChangedToken;
	bool __fastcall GetInitialized();
	double __fastcall GetZoomFactor();
	bool __fastcall GetIsVisible();
	Winapi::Windows::TRect __fastcall GetBounds();
	Winapi::Windows::THandle __fastcall GetParentWindow();
	System::Uitypes::TColor __fastcall GetDefaultBackgroundColor();
	double __fastcall GetRasterizationScale();
	bool __fastcall GetShouldDetectMonitorScaleChanges();
	Uwvtypes::TWVBoundsMode __fastcall GetBoundsMode();
	Uwvtypelibrary::_di_ICoreWebView2 __fastcall GetCoreWebView2();
	bool __fastcall GetAllowExternalDrop();
	void __fastcall SetZoomFactor(const double aValue);
	void __fastcall SetIsVisible(const bool aValue);
	void __fastcall SetBounds(const Winapi::Windows::TRect &aValue);
	void __fastcall SetParentWindow(Winapi::Windows::THandle aValue);
	void __fastcall SetDefaultBackgroundColor(const System::Uitypes::TColor aValue);
	void __fastcall SetRasterizationScale(const double aValue);
	void __fastcall SetShouldDetectMonitorScaleChanges(bool aValue);
	void __fastcall SetBoundsMode(Uwvtypes::TWVBoundsMode aValue);
	void __fastcall SetAllowExternalDrop(bool aValue);
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddAcceleratorKeyPressedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddGotFocusEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddLostFocusEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddMoveFocusRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddZoomFactorChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddRasterizationScaleChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2Controller(const Uwvtypelibrary::_di_ICoreWebView2Controller aBaseIntf);
	__fastcall virtual ~TCoreWebView2Controller();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall MoveFocus(Uwvtypes::TWVMoveFocusReason aReason);
	bool __fastcall Close();
	bool __fastcall SetBoundsAndZoomFactor(const Winapi::Windows::TRect &aBounds, const double aZoomFactor);
	bool __fastcall NotifyParentWindowPositionChanged();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Controller BaseIntf = {read=FBaseIntf};
	__property double ZoomFactor = {read=GetZoomFactor, write=SetZoomFactor};
	__property bool IsVisible = {read=GetIsVisible, write=SetIsVisible, nodefault};
	__property Winapi::Windows::TRect Bounds = {read=GetBounds, write=SetBounds};
	__property Winapi::Windows::THandle ParentWindow = {read=GetParentWindow, write=SetParentWindow, nodefault};
	__property System::Uitypes::TColor DefaultBackgroundColor = {read=GetDefaultBackgroundColor, write=SetDefaultBackgroundColor, nodefault};
	__property double RasterizationScale = {read=GetRasterizationScale, write=SetRasterizationScale};
	__property bool ShouldDetectMonitorScaleChanges = {read=GetShouldDetectMonitorScaleChanges, write=SetShouldDetectMonitorScaleChanges, nodefault};
	__property Uwvtypes::TWVBoundsMode BoundsMode = {read=GetBoundsMode, write=SetBoundsMode, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2 CoreWebView2 = {read=GetCoreWebView2};
	__property bool AllowExternalDrop = {read=GetAllowExternalDrop, write=SetAllowExternalDrop, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2controller */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2CONTROLLER)
using namespace Uwvcorewebview2controller;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2controllerHPP
