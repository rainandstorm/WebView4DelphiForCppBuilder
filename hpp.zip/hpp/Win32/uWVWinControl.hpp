﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVWinControl.pas' rev: 36.00 (Windows)

#ifndef UwvwincontrolHPP
#define UwvwincontrolHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.Graphics.hpp>
#include <System.UITypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvwincontrol
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWVWinControl;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWVWinControl : public Vcl::Controls::TWinControl
{
	typedef Vcl::Controls::TWinControl inherited;
	
protected:
	Winapi::Windows::THandle __fastcall GetChildWindowHandle();
	DYNAMIC void __fastcall Resize();
	
public:
	virtual void __fastcall CreateHandle();
	void __fastcall InvalidateChildren();
	virtual void __fastcall UpdateSize();
	__property Winapi::Windows::THandle ChildWindowHandle = {read=GetChildWindowHandle, nodefault};
	
__published:
	__property Align = {default=0};
	__property Anchors = {default=3};
	__property Color = {default=-16777211};
	__property Constraints;
	__property TabStop = {default=0};
	__property TabOrder = {default=-1};
	__property Visible = {default=1};
	__property Enabled = {default=1};
	__property ShowHint;
	__property Hint = {default=0};
	__property DragKind = {default=0};
	__property DragCursor = {default=-12};
	__property DragMode = {default=0};
	__property OnResize;
	__property OnEnter;
	__property OnExit;
	__property OnDragDrop;
	__property OnDragOver;
	__property OnStartDrag;
	__property OnEndDrag;
	__property OnCanResize;
	__property Touch;
	__property OnGesture;
	__property DoubleBuffered;
	__property ParentDoubleBuffered = {default=1};
public:
	/* TWinControl.Create */ inline __fastcall virtual TWVWinControl(System::Classes::TComponent* AOwner) : Vcl::Controls::TWinControl(AOwner) { }
	/* TWinControl.CreateParented */ inline __fastcall TWVWinControl(HWND ParentWindow) : Vcl::Controls::TWinControl(ParentWindow) { }
	/* TWinControl.Destroy */ inline __fastcall virtual ~TWVWinControl() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvwincontrol */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVWINCONTROL)
using namespace Uwvwincontrol;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvwincontrolHPP
