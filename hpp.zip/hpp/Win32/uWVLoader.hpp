﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVLoader.pas' rev: 36.00 (Windows)

#ifndef UwvloaderHPP
#define UwvloaderHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <System.Classes.hpp>
#include <System.SysUtils.hpp>
#include <Winapi.ActiveX.hpp>
#include <System.Win.Registry.hpp>
#include <Winapi.ShlObj.hpp>
#include <System.Math.hpp>
#include <uWVLibFunctions.hpp>
#include <uWVInterfaces.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>
#include <uWVEvents.hpp>
#include <uWVCoreWebView2Environment.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvloader
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWVLoader;
class DELPHICLASS TWVProxySettings;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWVLoader : public System::Classes::TComponent
{
	typedef System::Classes::TComponent inherited;
	
protected:
	Uwvcorewebview2environment::TCoreWebView2Environment* FCoreWebView2Environment;
	Uwvevents::_di_TLoaderNotifyEvent FOnEnvironmentCreated;
	Uwvevents::_di_TLoaderNewBrowserVersionAvailableEvent FOnNewBrowserVersionAvailable;
	Uwvevents::_di_TLoaderNotifyEvent FOnInitializationError;
	Uwvevents::_di_TLoaderBrowserProcessExitedEvent FOnBrowserProcessExited;
	Uwvevents::_di_TLoaderProcessInfosChangedEvent FOnProcessInfosChanged;
	Uwvevents::_di_TLoaderGetCustomSchemesEvent FOnGetCustomSchemes;
	Winapi::Windows::THandle FLibHandle;
	System::Classes::TStringList* FErrorLog;
	__int64 FError;
	Uwvtypes::wvstring FBrowserExecPath;
	Uwvtypes::wvstring FUserDataFolder;
	Uwvtypes::TWV2LoaderStatus FStatus;
	bool FSetCurrentDir;
	bool FCheckFiles;
	bool FShowMessageDlg;
	bool FInitCOMLibrary;
	bool FLocalCOMInitMade;
	float FDeviceScaleFactor;
	float FForcedDeviceScaleFactor;
	bool FReRaiseExceptions;
	Uwvtypes::wvstring FLoaderDllPath;
	bool FUseInternalLoader;
	bool FAllowOldRuntime;
	Uwvtypes::wvstring FAdditionalBrowserArguments;
	Uwvtypes::wvstring FLanguage;
	Uwvtypes::wvstring FTargetCompatibleBrowserVersion;
	bool FAllowSingleSignOnUsingOSPrimaryAccount;
	bool FExclusiveUserDataFolderAccess;
	bool FCustomCrashReportingEnabled;
	bool FEnableTrackingPrevention;
	bool FAreBrowserExtensionsEnabled;
	Uwvtypes::TWVChannelSearchKind FChannelSearchKind;
	Uwvtypes::TWVReleaseChannels FReleaseChannels;
	Uwvtypes::TWVScrollBarStyle FScrollBarStyle;
	bool FEnableGPU;
	Uwvtypes::wvstring FEnableFeatures;
	Uwvtypes::wvstring FDisableFeatures;
	Uwvtypes::wvstring FEnableBlinkFeatures;
	Uwvtypes::wvstring FDisableBlinkFeatures;
	Uwvtypes::wvstring FBlinkSettings;
	Uwvtypes::wvstring FForceFieldTrials;
	Uwvtypes::wvstring FForceFieldTrialParams;
	bool FSmartScreenProtectionEnabled;
	bool FAllowInsecureLocalhost;
	bool FDisableWebSecurity;
	Uwvtypes::TWVState FTouchEvents;
	bool FHyperlinkAuditing;
	Uwvtypes::TWVAutoplayPolicy FAutoplayPolicy;
	bool FMuteAudio;
	Uwvtypes::wvstring FDefaultEncoding;
	bool FKioskPrinting;
	TWVProxySettings* FProxySettings;
	bool FAllowFileAccessFromFiles;
	bool FAllowRunningInsecureContent;
	bool FDisableBackgroundNetworking;
	int FRemoteDebuggingPort;
	Uwvtypes::wvstring FRemoteAllowOrigins;
	Uwvtypes::TWV2DebugLog FDebugLog;
	Uwvtypes::TWV2DebugLogLevel FDebugLogLevel;
	Uwvtypes::wvstring FJavaScriptFlags;
	bool FDisableEdgePitchNotification;
	Uwvtypes::wvstring FTreatInsecureOriginAsSecure;
	bool FOpenOfficeDocumentsInWebViewer;
	bool FMicrosoftSignIn;
	Uwvtypes::TWVState FPostQuantumKyber;
	Uwvtypes::wvstring FUserAgent;
	bool FAutoAcceptCamAndMicCapture;
	Uwvtypes::wvstring __fastcall GetInternalAvailableBrowserVersion();
	Uwvtypes::wvstring __fastcall GetAvailableBrowserVersion();
	Uwvtypes::wvstring __fastcall GetAvailableBrowserVersionWithOptions();
	bool __fastcall GetInitialized();
	bool __fastcall GetInitializationError();
	bool __fastcall GetEnvironmentIsInitialized();
	System::UnicodeString __fastcall GetDefaultUserDataPath();
	Uwvtypelibrary::_di_ICoreWebView2Environment __fastcall GetEnvironment();
	Uwvtypelibrary::_di_ICoreWebView2ProcessInfoCollection __fastcall GetProcessInfos();
	bool __fastcall GetSupportsCompositionController();
	bool __fastcall GetSupportsControllerOptions();
	Uwvtypes::wvstring __fastcall GetCustomCommandLineSwitches();
	Uwvtypes::wvstring __fastcall GetInstalledRuntimeVersion();
	Uwvtypes::wvstring __fastcall GetErrorMessage();
	Uwvtypes::wvstring __fastcall GetFailureReportFolderPath();
	bool __fastcall CreateEnvironment();
	void __fastcall DestroyEnvironment();
	bool __fastcall GetFileVersion(const Uwvtypes::wvstring aFile, Uwvtypes::TFileVersionInfo &aVersionInfo);
	unsigned __int64 __fastcall GetExtendedFileVersion(const Uwvtypes::wvstring aFileName);
	bool __fastcall LoadLibProcedures();
	bool __fastcall LoadWebView2Library();
	void __fastcall UnLoadWebView2Library();
	bool __fastcall CheckWV2Library();
	bool __fastcall CheckBrowserExecPath();
	bool __fastcall CheckWebViewRuntimeVersion();
	bool __fastcall CheckWV2DLL();
	bool __fastcall CheckFileVersion(const Uwvtypes::wvstring aFile, System::Word aMajor, System::Word aMinor, System::Word aRelease, System::Word aBuild);
	bool __fastcall GetDLLHeaderMachine(const System::UnicodeString aDLLFile, int &aMachine);
	bool __fastcall Is32BitProcess();
	bool __fastcall CheckInstalledRuntimeRegEntry(bool aLocalMachine, const System::UnicodeString aPath, Uwvtypes::wvstring &aVersion);
	void __fastcall ShowErrorMessageDlg(const Uwvtypes::wvstring aError);
	bool __fastcall SearchInstalledProgram(const System::UnicodeString aDisplayName, const System::UnicodeString aPublisher);
	bool __fastcall SearchInstalledProgramInPath(const System::UnicodeString aRegPath, const System::UnicodeString aDisplayName, const System::UnicodeString aPublisher, bool aLocalMachine);
	virtual void __fastcall doOnInitializationError();
	virtual void __fastcall doOnEnvironmentCreated();
	virtual void __fastcall doOnNewBrowserVersionAvailable(const Uwvtypelibrary::_di_ICoreWebView2Environment aEnvironment);
	virtual void __fastcall doOnBrowserProcessExitedEvent(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs args);
	virtual void __fastcall doProcessInfosChangedEvent(const Uwvtypelibrary::_di_ICoreWebView2Environment sender);
	virtual void __fastcall doOnGetCustomSchemes(Uwvtypes::TWVCustomSchemeRegistrationArray &aSchemeRegistrations);
	HRESULT __fastcall EnvironmentCompletedHandler_Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2Environment result_);
	HRESULT __fastcall NewBrowserVersionAvailableEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const System::_di_IInterface args);
	HRESULT __fastcall BrowserProcessExitedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs args);
	HRESULT __fastcall ProcessInfosChangedEventHandler_Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const System::_di_IInterface args);
	__property System::UnicodeString DefaultUserDataPath = {read=GetDefaultUserDataPath};
	__property bool EnvironmentIsInitialized = {read=GetEnvironmentIsInitialized, nodefault};
	
public:
	__fastcall virtual TWVLoader(System::Classes::TComponent* AOwner);
	__fastcall virtual ~TWVLoader();
	virtual void __fastcall AfterConstruction();
	bool __fastcall StartWebView2();
	bool __fastcall CompareVersions(const Uwvtypes::wvstring aVersion1, const Uwvtypes::wvstring aVersion2, int &aCompRslt);
	virtual void __fastcall UpdateDeviceScaleFactor();
	void __fastcall AppendErrorLog(const Uwvtypes::wvstring aText);
	__property Uwvtypelibrary::_di_ICoreWebView2Environment Environment = {read=GetEnvironment};
	__property Uwvtypes::TWV2LoaderStatus Status = {read=FStatus, nodefault};
	__property Uwvtypes::wvstring AvailableBrowserVersion = {read=GetAvailableBrowserVersion};
	__property Uwvtypes::wvstring AvailableBrowserVersionWithOptions = {read=GetAvailableBrowserVersionWithOptions};
	__property Uwvtypes::wvstring ErrorMessage = {read=GetErrorMessage};
	__property __int64 ErrorCode = {read=FError};
	__property bool SetCurrentDir = {read=FSetCurrentDir, write=FSetCurrentDir, nodefault};
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property bool InitializationError = {read=GetInitializationError, nodefault};
	__property bool CheckFiles = {read=FCheckFiles, write=FCheckFiles, nodefault};
	__property bool ShowMessageDlg = {read=FShowMessageDlg, write=FShowMessageDlg, nodefault};
	__property bool InitCOMLibrary = {read=FInitCOMLibrary, write=FInitCOMLibrary, nodefault};
	__property Uwvtypes::wvstring CustomCommandLineSwitches = {read=GetCustomCommandLineSwitches};
	__property float DeviceScaleFactor = {read=FDeviceScaleFactor};
	__property bool ReRaiseExceptions = {read=FReRaiseExceptions, write=FReRaiseExceptions, nodefault};
	__property Uwvtypes::wvstring InstalledRuntimeVersion = {read=GetInstalledRuntimeVersion};
	__property Uwvtypes::wvstring LoaderDllPath = {read=FLoaderDllPath, write=FLoaderDllPath};
	__property bool UseInternalLoader = {read=FUseInternalLoader, write=FUseInternalLoader, nodefault};
	__property bool AllowOldRuntime = {read=FAllowOldRuntime, write=FAllowOldRuntime, nodefault};
	__property Uwvtypes::wvstring BrowserExecPath = {read=FBrowserExecPath, write=FBrowserExecPath};
	__property Uwvtypes::wvstring UserDataFolder = {read=FUserDataFolder, write=FUserDataFolder};
	__property Uwvtypes::wvstring AdditionalBrowserArguments = {read=FAdditionalBrowserArguments, write=FAdditionalBrowserArguments};
	__property Uwvtypes::wvstring Language = {read=FLanguage, write=FLanguage};
	__property Uwvtypes::wvstring TargetCompatibleBrowserVersion = {read=FTargetCompatibleBrowserVersion, write=FTargetCompatibleBrowserVersion};
	__property bool AllowSingleSignOnUsingOSPrimaryAccount = {read=FAllowSingleSignOnUsingOSPrimaryAccount, write=FAllowSingleSignOnUsingOSPrimaryAccount, nodefault};
	__property bool ExclusiveUserDataFolderAccess = {read=FExclusiveUserDataFolderAccess, write=FExclusiveUserDataFolderAccess, nodefault};
	__property bool CustomCrashReportingEnabled = {read=FCustomCrashReportingEnabled, write=FCustomCrashReportingEnabled, nodefault};
	__property bool EnableTrackingPrevention = {read=FEnableTrackingPrevention, write=FEnableTrackingPrevention, nodefault};
	__property bool AreBrowserExtensionsEnabled = {read=FAreBrowserExtensionsEnabled, write=FAreBrowserExtensionsEnabled, nodefault};
	__property Uwvtypes::TWVChannelSearchKind ChannelSearchKind = {read=FChannelSearchKind, write=FChannelSearchKind, nodefault};
	__property Uwvtypes::TWVReleaseChannels ReleaseChannels = {read=FReleaseChannels, write=FReleaseChannels, nodefault};
	__property Uwvtypes::TWVScrollBarStyle ScrollBarStyle = {read=FScrollBarStyle, write=FScrollBarStyle, nodefault};
	__property bool EnableGPU = {read=FEnableGPU, write=FEnableGPU, nodefault};
	__property Uwvtypes::wvstring EnableFeatures = {read=FEnableFeatures, write=FEnableFeatures};
	__property Uwvtypes::wvstring DisableFeatures = {read=FDisableFeatures, write=FDisableFeatures};
	__property Uwvtypes::wvstring EnableBlinkFeatures = {read=FEnableBlinkFeatures, write=FEnableBlinkFeatures};
	__property Uwvtypes::wvstring DisableBlinkFeatures = {read=FDisableBlinkFeatures, write=FDisableBlinkFeatures};
	__property Uwvtypes::wvstring BlinkSettings = {read=FBlinkSettings, write=FBlinkSettings};
	__property Uwvtypes::wvstring ForceFieldTrials = {read=FForceFieldTrials, write=FForceFieldTrials};
	__property Uwvtypes::wvstring ForceFieldTrialParams = {read=FForceFieldTrialParams, write=FForceFieldTrialParams};
	__property bool SmartScreenProtectionEnabled = {read=FSmartScreenProtectionEnabled, write=FSmartScreenProtectionEnabled, nodefault};
	__property bool AllowInsecureLocalhost = {read=FAllowInsecureLocalhost, write=FAllowInsecureLocalhost, nodefault};
	__property bool DisableWebSecurity = {read=FDisableWebSecurity, write=FDisableWebSecurity, nodefault};
	__property Uwvtypes::TWVState TouchEvents = {read=FTouchEvents, write=FTouchEvents, nodefault};
	__property bool HyperlinkAuditing = {read=FHyperlinkAuditing, write=FHyperlinkAuditing, nodefault};
	__property Uwvtypes::TWVAutoplayPolicy AutoplayPolicy = {read=FAutoplayPolicy, write=FAutoplayPolicy, nodefault};
	__property bool MuteAudio = {read=FMuteAudio, write=FMuteAudio, nodefault};
	__property Uwvtypes::wvstring DefaultEncoding = {read=FDefaultEncoding, write=FDefaultEncoding};
	__property bool KioskPrinting = {read=FKioskPrinting, write=FKioskPrinting, nodefault};
	__property TWVProxySettings* ProxySettings = {read=FProxySettings};
	__property bool AllowFileAccessFromFiles = {read=FAllowFileAccessFromFiles, write=FAllowFileAccessFromFiles, nodefault};
	__property bool AllowRunningInsecureContent = {read=FAllowRunningInsecureContent, write=FAllowRunningInsecureContent, nodefault};
	__property bool DisableBackgroundNetworking = {read=FDisableBackgroundNetworking, write=FDisableBackgroundNetworking, nodefault};
	__property float ForcedDeviceScaleFactor = {read=FForcedDeviceScaleFactor, write=FForcedDeviceScaleFactor};
	__property int RemoteDebuggingPort = {read=FRemoteDebuggingPort, write=FRemoteDebuggingPort, nodefault};
	__property Uwvtypes::wvstring RemoteAllowOrigins = {read=FRemoteAllowOrigins, write=FRemoteAllowOrigins};
	__property Uwvtypes::TWV2DebugLog DebugLog = {read=FDebugLog, write=FDebugLog, nodefault};
	__property Uwvtypes::TWV2DebugLogLevel DebugLogLevel = {read=FDebugLogLevel, write=FDebugLogLevel, nodefault};
	__property Uwvtypes::wvstring JavaScriptFlags = {read=FJavaScriptFlags, write=FJavaScriptFlags};
	__property bool DisableEdgePitchNotification = {read=FDisableEdgePitchNotification, write=FDisableEdgePitchNotification, nodefault};
	__property Uwvtypes::wvstring TreatInsecureOriginAsSecure = {read=FTreatInsecureOriginAsSecure, write=FTreatInsecureOriginAsSecure};
	__property bool OpenOfficeDocumentsInWebViewer = {read=FOpenOfficeDocumentsInWebViewer, write=FOpenOfficeDocumentsInWebViewer, nodefault};
	__property bool MicrosoftSignIn = {read=FMicrosoftSignIn, write=FMicrosoftSignIn, nodefault};
	__property Uwvtypes::TWVState TLS13HybridizedKyberSupport = {read=FPostQuantumKyber, write=FPostQuantumKyber, nodefault};
	__property Uwvtypes::wvstring UserAgent = {read=FUserAgent, write=FUserAgent};
	__property bool AutoAcceptCamAndMicCapture = {read=FAutoAcceptCamAndMicCapture, write=FAutoAcceptCamAndMicCapture, nodefault};
	__property bool SupportsCompositionController = {read=GetSupportsCompositionController, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ProcessInfoCollection ProcessInfos = {read=GetProcessInfos};
	__property bool SupportsControllerOptions = {read=GetSupportsControllerOptions, nodefault};
	__property Uwvtypes::wvstring FailureReportFolderPath = {read=GetFailureReportFolderPath};
	__property Uwvevents::_di_TLoaderNotifyEvent OnEnvironmentCreated = {read=FOnEnvironmentCreated, write=FOnEnvironmentCreated};
	__property Uwvevents::_di_TLoaderNotifyEvent OnInitializationError = {read=FOnInitializationError, write=FOnInitializationError};
	__property Uwvevents::_di_TLoaderGetCustomSchemesEvent OnGetCustomSchemes = {read=FOnGetCustomSchemes, write=FOnGetCustomSchemes};
	__property Uwvevents::_di_TLoaderNewBrowserVersionAvailableEvent OnNewBrowserVersionAvailable = {read=FOnNewBrowserVersionAvailable, write=FOnNewBrowserVersionAvailable};
	__property Uwvevents::_di_TLoaderBrowserProcessExitedEvent OnBrowserProcessExited = {read=FOnBrowserProcessExited, write=FOnBrowserProcessExited};
	__property Uwvevents::_di_TLoaderProcessInfosChangedEvent OnProcessInfosChanged = {read=FOnProcessInfosChanged, write=FOnProcessInfosChanged};
private:
	void *__IWVLoaderEvents;	// Uwvinterfaces::IWVLoaderEvents 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {5B91E1BB-CA98-476E-A2F0-10BDED27A916}
	operator Uwvinterfaces::_di_IWVLoaderEvents()
	{
		Uwvinterfaces::_di_IWVLoaderEvents intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvinterfaces::IWVLoaderEvents*(void) { return (Uwvinterfaces::IWVLoaderEvents*)&__IWVLoaderEvents; }
	#endif
	
};


#pragma pack(push,4)
class PASCALIMPLEMENTATION TWVProxySettings : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	bool FNoProxyServer;
	bool FAutoDetect;
	Uwvtypes::wvstring FByPassList;
	Uwvtypes::wvstring FPacUrl;
	Uwvtypes::wvstring FServer;
	
public:
	__fastcall TWVProxySettings();
	__property bool NoProxyServer = {read=FNoProxyServer, write=FNoProxyServer, nodefault};
	__property bool AutoDetect = {read=FAutoDetect, write=FAutoDetect, nodefault};
	__property Uwvtypes::wvstring ByPassList = {read=FByPassList, write=FByPassList};
	__property Uwvtypes::wvstring PacUrl = {read=FPacUrl, write=FPacUrl};
	__property Uwvtypes::wvstring Server = {read=FServer, write=FServer};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TWVProxySettings() { }
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE TWVLoader* GlobalWebView2Loader;
extern DELPHI_PACKAGE void __fastcall DestroyGlobalWebView2Loader(void);
}	/* namespace Uwvloader */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVLOADER)
using namespace Uwvloader;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvloaderHPP
