﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Settings.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2settingsHPP
#define Uwvcorewebview2settingsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2settings
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Settings;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2Settings : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Settings FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2Settings2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2Settings3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2Settings4 FBaseIntf4;
	Uwvtypelibrary::_di_ICoreWebView2Settings5 FBaseIntf5;
	Uwvtypelibrary::_di_ICoreWebView2Settings6 FBaseIntf6;
	Uwvtypelibrary::_di_ICoreWebView2Settings7 FBaseIntf7;
	Uwvtypelibrary::_di_ICoreWebView2Settings8 FBaseIntf8;
	Uwvtypelibrary::_di_ICoreWebView2Settings9 FBaseIntf9;
	bool __fastcall GetInitialized();
	bool __fastcall GetIsBuiltInErrorPageEnabled();
	bool __fastcall GetAreDefaultContextMenusEnabled();
	bool __fastcall GetAreDefaultScriptDialogsEnabled();
	bool __fastcall GetAreDevToolsEnabled();
	bool __fastcall GetIsScriptEnabled();
	bool __fastcall GetIsStatusBarEnabled();
	bool __fastcall GetIsWebMessageEnabled();
	bool __fastcall GetIsZoomControlEnabled();
	bool __fastcall GetAreHostObjectsAllowed();
	Uwvtypes::wvstring __fastcall GetUserAgent();
	bool __fastcall GetAreBrowserAcceleratorKeysEnabled();
	bool __fastcall GetIsPasswordAutosaveEnabled();
	bool __fastcall GetIsGeneralAutofillEnabled();
	bool __fastcall GetIsPinchZoomEnabled();
	bool __fastcall GetIsSwipeNavigationEnabled();
	Uwvtypes::TWVPDFToolbarItems __fastcall GetHiddenPdfToolbarItems();
	bool __fastcall GetIsReputationCheckingRequired();
	bool __fastcall GetIsNonClientRegionSupportEnabled();
	void __fastcall SetIsBuiltInErrorPageEnabled(bool aValue);
	void __fastcall SetAreDefaultContextMenusEnabled(bool aValue);
	void __fastcall SetAreDefaultScriptDialogsEnabled(bool aValue);
	void __fastcall SetAreDevToolsEnabled(bool aValue);
	void __fastcall SetIsScriptEnabled(bool aValue);
	void __fastcall SetIsStatusBarEnabled(bool aValue);
	void __fastcall SetIsWebMessageEnabled(bool aValue);
	void __fastcall SetIsZoomControlEnabled(bool aValue);
	void __fastcall SetAreHostObjectsAllowed(bool aValue);
	void __fastcall SetUserAgent(const Uwvtypes::wvstring aValue);
	void __fastcall SetAreBrowserAcceleratorKeysEnabled(bool aValue);
	void __fastcall SetIsPasswordAutosaveEnabled(bool aValue);
	void __fastcall SetIsGeneralAutofillEnabled(bool aValue);
	void __fastcall SetIsPinchZoomEnabled(bool aValue);
	void __fastcall SetIsSwipeNavigationEnabled(bool aValue);
	void __fastcall SetHiddenPdfToolbarItems(Uwvtypes::TWVPDFToolbarItems aValue);
	void __fastcall SetIsReputationCheckingRequired(bool aValue);
	void __fastcall SetIsNonClientRegionSupportEnabled(bool aValue);
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2Settings(const Uwvtypelibrary::_di_ICoreWebView2Settings aBaseIntf);
	__fastcall virtual ~TCoreWebView2Settings();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Settings BaseIntf = {read=FBaseIntf};
	__property bool IsBuiltInErrorPageEnabled = {read=GetIsBuiltInErrorPageEnabled, write=SetIsBuiltInErrorPageEnabled, nodefault};
	__property bool AreDefaultContextMenusEnabled = {read=GetAreDefaultContextMenusEnabled, write=SetAreDefaultContextMenusEnabled, nodefault};
	__property bool AreDefaultScriptDialogsEnabled = {read=GetAreDefaultScriptDialogsEnabled, write=SetAreDefaultScriptDialogsEnabled, nodefault};
	__property bool AreDevToolsEnabled = {read=GetAreDevToolsEnabled, write=SetAreDevToolsEnabled, nodefault};
	__property bool IsScriptEnabled = {read=GetIsScriptEnabled, write=SetIsScriptEnabled, nodefault};
	__property bool IsStatusBarEnabled = {read=GetIsStatusBarEnabled, write=SetIsStatusBarEnabled, nodefault};
	__property bool IsWebMessageEnabled = {read=GetIsWebMessageEnabled, write=SetIsWebMessageEnabled, nodefault};
	__property bool IsZoomControlEnabled = {read=GetIsZoomControlEnabled, write=SetIsZoomControlEnabled, nodefault};
	__property bool AreHostObjectsAllowed = {read=GetAreHostObjectsAllowed, write=SetAreHostObjectsAllowed, nodefault};
	__property Uwvtypes::wvstring UserAgent = {read=GetUserAgent, write=SetUserAgent};
	__property bool AreBrowserAcceleratorKeysEnabled = {read=GetAreBrowserAcceleratorKeysEnabled, write=SetAreBrowserAcceleratorKeysEnabled, nodefault};
	__property bool IsPasswordAutosaveEnabled = {read=GetIsPasswordAutosaveEnabled, write=SetIsPasswordAutosaveEnabled, nodefault};
	__property bool IsGeneralAutofillEnabled = {read=GetIsGeneralAutofillEnabled, write=SetIsGeneralAutofillEnabled, nodefault};
	__property bool IsPinchZoomEnabled = {read=GetIsPinchZoomEnabled, write=SetIsPinchZoomEnabled, nodefault};
	__property bool IsSwipeNavigationEnabled = {read=GetIsSwipeNavigationEnabled, write=SetIsSwipeNavigationEnabled, nodefault};
	__property Uwvtypes::TWVPDFToolbarItems HiddenPdfToolbarItems = {read=GetHiddenPdfToolbarItems, write=SetHiddenPdfToolbarItems, nodefault};
	__property bool IsReputationCheckingRequired = {read=GetIsReputationCheckingRequired, write=SetIsReputationCheckingRequired, nodefault};
	__property bool IsNonClientRegionSupportEnabled = {read=GetIsNonClientRegionSupportEnabled, write=SetIsNonClientRegionSupportEnabled, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2settings */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2SETTINGS)
using namespace Uwvcorewebview2settings;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2settingsHPP
