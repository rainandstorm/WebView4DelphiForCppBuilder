﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVTypes.pas' rev: 36.00 (Windows)

#ifndef UwvtypesHPP
#define UwvtypesHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <uWVTypeLibrary.hpp>
#include <Winapi.ActiveX.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvtypes
{
//-- forward type declarations -----------------------------------------------
struct TWVColor;
struct TFileVersionInfo;
struct TWVWindowFeatures;
struct TWVCustomSchemeInfo;
//-- type declarations -------------------------------------------------------
typedef System::UnicodeString wvstring;

typedef Winapi::Activex::TOleEnum TWVKeyEventKind;

typedef Winapi::Activex::TOleEnum TWVMoveFocusReason;

typedef Winapi::Activex::TOleEnum TWVWebErrorStatus;

typedef Winapi::Activex::TOleEnum TWVScriptDialogKind;

typedef Winapi::Activex::TOleEnum TWVPermissionState;

typedef Winapi::Activex::TOleEnum TWVPermissionKind;

typedef Winapi::Activex::TOleEnum TWVProcessFailedKind;

typedef Winapi::Activex::TOleEnum TWVCapturePreviewImageFormat;

typedef Winapi::Activex::TOleEnum TWVWebResourceContext;

typedef Winapi::Activex::TOleEnum TWVCookieSameSiteKind;

typedef Winapi::Activex::TOleEnum TWVHostResourceAcccessKind;

typedef Winapi::Activex::TOleEnum TWVDownloadState;

typedef Winapi::Activex::TOleEnum TWVDownloadInterruptReason;

typedef Winapi::Activex::TOleEnum TWVClientCertificateKind;

typedef Winapi::Activex::TOleEnum TWVBrowserProcessExitKind;

typedef Winapi::Activex::TOleEnum TWVMouseEventKind;

typedef Winapi::Activex::TOleEnum TWVMouseEventVirtualKeys;

typedef Winapi::Activex::TOleEnum TWVPointerEventKind;

typedef Winapi::Activex::TOleEnum TWVBoundsMode;

typedef Winapi::Activex::TOleEnum TWVProcessFailedReason;

typedef Winapi::Activex::TOleEnum TWVPrintOrientation;

#pragma pack(push,1)
struct DECLSPEC_DRECORD TWVColor
{
public:
	System::Byte A;
	System::Byte R;
	System::Byte G;
	System::Byte B;
};
#pragma pack(pop)


typedef Winapi::Activex::TOleEnum TWVDefaultDownloadDialogCornerAlignment;

typedef Winapi::Activex::TOleEnum TWVProcessKind;

typedef Winapi::Activex::TOleEnum TWVMenuItemKind;

typedef Winapi::Activex::TOleEnum TWVMenuTargetKind;

typedef Winapi::Activex::TOleEnum TWVPDFToolbarItems;

typedef Winapi::Activex::TOleEnum TWVPreferredColorScheme;

typedef Winapi::Activex::TOleEnum TWVBrowsingDataKinds;

typedef Winapi::Activex::TOleEnum TWVServerCertificateErrorAction;

typedef Winapi::Activex::TOleEnum TWVFaviconImageFormat;

typedef Winapi::Activex::TOleEnum TWVPrintCollation;

typedef Winapi::Activex::TOleEnum TWVPrintColorMode;

typedef Winapi::Activex::TOleEnum TWVPrintDuplex;

typedef Winapi::Activex::TOleEnum TWVPrintMediaSize;

typedef Winapi::Activex::TOleEnum TWVPrintStatus;

typedef Winapi::Activex::TOleEnum TWVPrintDialogKind;

typedef Winapi::Activex::TOleEnum TWVSharedBufferAccess;

typedef Winapi::Activex::TOleEnum TWVTrackingPreventionLevel;

typedef Winapi::Activex::TOleEnum TWVMemoryUsageTargetLevel;

typedef Winapi::Activex::TOleEnum TWVNavigationKind;

typedef Winapi::Activex::TOleEnum TWVFrameKind;

typedef Winapi::Activex::TOleEnum TWVWebResourceRequestSourceKind;

typedef Winapi::Activex::TOleEnum TWVNonClientRegionKind;

typedef Winapi::Activex::TOleEnum TWVChannelSearchKind;

typedef Winapi::Activex::TOleEnum TWVReleaseChannels;

typedef Winapi::Activex::TOleEnum TWVScrollBarStyle;

typedef Winapi::Activex::TOleEnum TWVFileSystemHandlePermission;

typedef Winapi::Activex::TOleEnum TWVFileSystemHandleKind;

typedef Winapi::Activex::TOleEnum TWVTextDirectionKind;

typedef Winapi::Activex::TOleEnum TWVSaveAsKind;

typedef Winapi::Activex::TOleEnum TWVSaveAsUIResult;

enum DECLSPEC_DENUM TWV2LoaderStatus : unsigned char { wvlsCreated, wvlsLoading, wvlsLoaded, wvlsImported, wvlsInitialized, wvlsError, wvlsUnloaded };

enum DECLSPEC_DENUM TWV2KeyEventType : unsigned char { ketKeyDown, ketKeyUp, ketRawKeyDown, ketChar };

enum DECLSPEC_DENUM TWV2DebugLog : unsigned char { dlDisabled, dlEnabled, dlEnabledStdOut, dlEnabledStdErr };

enum DECLSPEC_DENUM TWV2DebugLogLevel : unsigned char { dllDefault, dllInfo, dllWarning, dllError, dllFatal };

enum DECLSPEC_DENUM TWV2EditingCommand : unsigned char { ecAlignCenter, ecAlignJustified, ecAlignLeft, ecAlignRight, ecBackColor, ecBackwardDelete, ecBold, ecCopy, ecCreateLink, ecCut, ecDefaultParagraphSeparator, ecDelete, ecDeleteBackward, ecDeleteBackwardByDecomposingPreviousCharacter, ecDeleteForward, ecDeleteToBeginningOfLine, ecDeleteToBeginningOfParagraph, ecDeleteToEndOfLine, ecDeleteToEndOfParagraph, ecDeleteToMark, ecDeleteWordBackward, ecDeleteWordForward, ecFindString, ecFontName, ecFontSize, ecFontSizeDelta, ecForeColor, ecFormatBlock, ecForwardDelete, ecHiliteColor, ecIgnoreSpelling, ecIndent, ecInsertBacktab, ecInsertHorizontalRule, ecInsertHTML, ecInsertImage, ecInsertLineBreak, ecInsertNewline, ecInsertNewlineInQuotedContent, 
	ecInsertOrderedList, ecInsertParagraph, ecInsertTab, ecInsertText, ecInsertUnorderedList, ecItalic, ecJustifyCenter, ecJustifyFull, ecJustifyLeft, ecJustifyNone, ecJustifyRight, ecMakeTextWritingDirectionLeftToRight, ecMakeTextWritingDirectionNatural, ecMakeTextWritingDirectionRightToLeft, ecMoveBackward, ecMoveBackwardAndModifySelection, ecMoveDown, ecMoveDownAndModifySelection, ecMoveForward, ecMoveForwardAndModifySelection, ecMoveLeft, ecMoveLeftAndModifySelection, ecMovePageDown, ecMovePageDownAndModifySelection, ecMovePageUp, ecMovePageUpAndModifySelection, ecMoveParagraphBackward, ecMoveParagraphBackwardAndModifySelection, ecMoveParagraphForward, ecMoveParagraphForwardAndModifySelection, ecMoveRight, ecMoveRightAndModifySelection, 
	ecMoveToBeginningOfDocument, ecMoveToBeginningOfDocumentAndModifySelection, ecMoveToBeginningOfLine, ecMoveToBeginningOfLineAndModifySelection, ecMoveToBeginningOfParagraph, ecMoveToBeginningOfParagraphAndModifySelection, ecMoveToBeginningOfSentence, ecMoveToBeginningOfSentenceAndModifySelection, ecMoveToEndOfDocument, ecMoveToEndOfDocumentAndModifySelection, ecMoveToEndOfLine, ecMoveToEndOfLineAndModifySelection, ecMoveToEndOfParagraph, ecMoveToEndOfParagraphAndModifySelection, ecMoveToEndOfSentence, ecMoveToEndOfSentenceAndModifySelection, ecMoveToLeftEndOfLine, ecMoveToLeftEndOfLineAndModifySelection, ecMoveToRightEndOfLine, ecMoveToRightEndOfLineAndModifySelection, ecMoveUp, ecMoveUpAndModifySelection, ecMoveWordBackward, 
	ecMoveWordBackwardAndModifySelection, ecMoveWordForward, ecMoveWordForwardAndModifySelection, ecMoveWordLeft, ecMoveWordLeftAndModifySelection, ecMoveWordRight, ecMoveWordRightAndModifySelection, ecOutdent, ecOverWrite, ecPaste, ecPasteAndMatchStyle, ecPasteGlobalSelection, ecPrint, ecRedo, ecRemoveFormat, ecScrollLineDown, ecScrollLineUp, ecScrollPageBackward, ecScrollPageForward, ecScrollToBeginningOfDocument, ecScrollToEndOfDocument, ecSelectAll, ecSelectLine, ecSelectParagraph, ecSelectSentence, ecSelectToMark, ecSelectWord, ecSetMark, ecStrikethrough, ecStyleWithCSS, ecSubscript, ecSuperscript, ecSwapWithMark, ecToggleBold, ecToggleItalic, ecToggleUnderline, ecTranspose, ecUnderline, ecUndo, ecUnlink, ecUnscript, ecUnselect, ecUseCSS, ecYank, 
	ecYankAndSelect };

struct DECLSPEC_DRECORD TFileVersionInfo
{
public:
	System::Word MajorVer;
	System::Word MinorVer;
	System::Word Release;
	System::Word Build;
};


struct DECLSPEC_DRECORD TWVWindowFeatures
{
public:
	bool HasPosition;
	bool HasSize;
	unsigned Left;
	unsigned Top;
	unsigned Width;
	unsigned Height;
	bool ShouldDisplayMenuBar;
	bool ShouldDisplayStatus;
	bool ShouldDisplayToolbar;
	bool ShouldDisplayScrollBars;
};


enum DECLSPEC_DENUM TWVClearDataStorageTypes : unsigned char { cdstAppCache, cdstCookies, cdstFileSystems, cdstIndexeddb, cdstLocalStorage, cdstShaderCache, cdstWebsql, cdstServiceWorkers, cdstCacheStorage, cdstAll };

enum DECLSPEC_DENUM TWVState : unsigned char { STATE_DEFAULT, STATE_ENABLED, STATE_DISABLED };

enum DECLSPEC_DENUM TWVAutoplayPolicy : unsigned char { appDefault, appDocumentUserActivationRequired, appNoUserGestureRequired, appUserGestureRequired };

struct DECLSPEC_DRECORD TWVCustomSchemeInfo
{
public:
	wvstring SchemeName;
	bool TreatAsSecure;
	wvstring AllowedDomains;
	bool HasAuthorityComponent;
};


typedef System::DynamicArray<TWVCustomSchemeInfo> TWVCustomSchemeInfoArray;

typedef System::DynamicArray<Uwvtypelibrary::_di_ICoreWebView2CustomSchemeRegistration> TWVCustomSchemeRegistrationArray;

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvtypes */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVTYPES)
using namespace Uwvtypes;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvtypesHPP
