﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2WebResourceRequest.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2webresourcerequestHPP
#define Uwvcorewebview2webresourcerequestHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2webresourcerequest
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2WebResourceRequestRef;
class DELPHICLASS TCoreWebView2WebResourceRequestOwn;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2WebResourceRequestRef : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetURI();
	Uwvtypes::wvstring __fastcall GetMethod();
	_di_IStream __fastcall GetContent();
	Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders __fastcall GetHeaders();
	void __fastcall SetURI(const Uwvtypes::wvstring aValue);
	void __fastcall SetMethod(const Uwvtypes::wvstring aValue);
	void __fastcall SetContent(const _di_IStream aContent);
	
public:
	__fastcall TCoreWebView2WebResourceRequestRef(const Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest aBaseIntf);
	__fastcall virtual ~TCoreWebView2WebResourceRequestRef();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring URI = {read=GetURI, write=SetURI};
	__property Uwvtypes::wvstring Method = {read=GetMethod, write=SetMethod};
	__property _di_IStream Content = {read=GetContent, write=SetContent};
	__property Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders Headers = {read=GetHeaders};
};

#pragma pack(pop)

#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2WebResourceRequestOwn : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	Uwvtypes::wvstring FURI;
	Uwvtypes::wvstring FMethod;
	_di_IStream FContent;
	Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders FHeaders;
	HRESULT __stdcall Get_uri(/* out */ System::WideChar * &uri);
	HRESULT __stdcall Set_uri(System::WideChar * uri);
	HRESULT __stdcall Get_Method(/* out */ System::WideChar * &Method);
	HRESULT __stdcall Set_Method(System::WideChar * Method);
	HRESULT __stdcall Get_Content(/* out */ _di_IStream &Content);
	HRESULT __stdcall Set_Content(const _di_IStream Content);
	HRESULT __stdcall Get_Headers(/* out */ Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders &Headers);
	
public:
	__fastcall TCoreWebView2WebResourceRequestOwn(const Uwvtypes::wvstring aURI, const Uwvtypes::wvstring aMethod, const _di_IStream aContent, const Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders aHeaders);
	__fastcall virtual ~TCoreWebView2WebResourceRequestOwn();
private:
	void *__ICoreWebView2WebResourceRequest;	// Uwvtypelibrary::ICoreWebView2WebResourceRequest 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {97055CD4-512C-4264-8B5F-E3F446CEA6A5}
	operator Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest()
	{
		Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2WebResourceRequest*(void) { return (Uwvtypelibrary::ICoreWebView2WebResourceRequest*)&__ICoreWebView2WebResourceRequest; }
	#endif
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2webresourcerequest */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2WEBRESOURCEREQUEST)
using namespace Uwvcorewebview2webresourcerequest;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2webresourcerequestHPP
