﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVEvents.pas' rev: 36.00 (Windows)

#ifndef UwveventsHPP
#define UwveventsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.ActiveX.hpp>
#include <Winapi.Messages.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvevents
{
//-- forward type declarations -----------------------------------------------
__interface DELPHIINTERFACE TLoaderNotifyEvent;
typedef System::DelphiInterface<TLoaderNotifyEvent> _di_TLoaderNotifyEvent;
__interface DELPHIINTERFACE TLoaderBrowserProcessExitedEvent;
typedef System::DelphiInterface<TLoaderBrowserProcessExitedEvent> _di_TLoaderBrowserProcessExitedEvent;
__interface DELPHIINTERFACE TLoaderNewBrowserVersionAvailableEvent;
typedef System::DelphiInterface<TLoaderNewBrowserVersionAvailableEvent> _di_TLoaderNewBrowserVersionAvailableEvent;
__interface DELPHIINTERFACE TLoaderProcessInfosChangedEvent;
typedef System::DelphiInterface<TLoaderProcessInfosChangedEvent> _di_TLoaderProcessInfosChangedEvent;
__interface DELPHIINTERFACE TLoaderGetCustomSchemesEvent;
typedef System::DelphiInterface<TLoaderGetCustomSchemesEvent> _di_TLoaderGetCustomSchemesEvent;
//-- type declarations -------------------------------------------------------
__interface TLoaderNotifyEvent  : public System::IInterface 
{
	virtual void __fastcall Invoke(System::TObject* Sender) = 0 ;
};

__interface TLoaderBrowserProcessExitedEvent  : public System::IInterface 
{
	virtual void __fastcall Invoke(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Environment aEnvironment, const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs aArgs) = 0 ;
};

__interface TLoaderNewBrowserVersionAvailableEvent  : public System::IInterface 
{
	virtual void __fastcall Invoke(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Environment aEnvironment) = 0 ;
};

__interface TLoaderProcessInfosChangedEvent  : public System::IInterface 
{
	virtual void __fastcall Invoke(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Environment aEnvironment) = 0 ;
};

__interface TLoaderGetCustomSchemesEvent  : public System::IInterface 
{
	virtual void __fastcall Invoke(System::TObject* Sender, Uwvtypes::TWVCustomSchemeInfoArray &aCustomSchemes) = 0 ;
};

typedef void __fastcall (__closure *TOnExecuteScriptCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypes::wvstring aResultObjectAsJson, int aExecutionID);

typedef void __fastcall (__closure *TOnCapturePreviewCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode);

typedef void __fastcall (__closure *TOnWebResourceResponseViewGetContentCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const _di_IStream aResult, int aResourceID);

typedef void __fastcall (__closure *TOnGetCookiesCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypelibrary::_di_ICoreWebView2CookieList aResult);

typedef void __fastcall (__closure *TOnTrySuspendCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, bool aResult);

typedef void __fastcall (__closure *TOnPrintToPdfCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, bool aResult);

typedef void __fastcall (__closure *TOnCallDevToolsProtocolMethodCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypes::wvstring aResult, int aExecutionID);

typedef void __fastcall (__closure *TOnAddScriptToExecuteOnDocumentCreatedCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypes::wvstring aResult);

typedef void __fastcall (__closure *TOnMoveFocusRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Controller aController, const Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventArgs aArgs);

typedef void __fastcall (__closure *TOnAcceleratorKeyPressedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Controller aController, const Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventArgs aArgs);

typedef void __fastcall (__closure *TOnBrowserProcessExitedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Environment aEnvironment, const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs aArgs);

typedef void __fastcall (__closure *TOnNavigationStartingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs aArgs);

typedef void __fastcall (__closure *TOnNavigationCompletedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs aArgs);

typedef void __fastcall (__closure *TOnSourceChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventArgs aArgs);

typedef void __fastcall (__closure *TOnContentLoadingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs aArgs);

typedef void __fastcall (__closure *TOnNewWindowRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs aArgs);

typedef void __fastcall (__closure *TOnWebResourceRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventArgs aArgs);

typedef void __fastcall (__closure *TOnScriptDialogOpeningEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventArgs aArgs);

typedef void __fastcall (__closure *TOnPermissionRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs aArgs);

typedef void __fastcall (__closure *TOnProcessFailedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs aArgs);

typedef void __fastcall (__closure *TOnWebMessageReceivedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs aArgs);

typedef void __fastcall (__closure *TOnDevToolsProtocolEventReceivedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventArgs aArgs, const Uwvtypes::wvstring aEventName, int aEventID);

typedef void __fastcall (__closure *TOnWebResourceResponseReceivedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventArgs aArgs);

typedef void __fastcall (__closure *TOnDOMContentLoadedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs aArgs);

typedef void __fastcall (__closure *TOnFrameCreatedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs aArgs);

typedef void __fastcall (__closure *TOnDownloadStartingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventArgs aArgs);

typedef void __fastcall (__closure *TOnClientCertificateRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventArgs aArgs);

typedef void __fastcall (__closure *TOnBytesReceivedChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation aDownloadOperation, int aDownloadID);

typedef void __fastcall (__closure *TOnEstimatedEndTimeChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation aDownloadOperation, int aDownloadID);

typedef void __fastcall (__closure *TOnDownloadStateChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation aDownloadOperation, int aDownloadID);

typedef void __fastcall (__closure *TOnFrameNameChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, unsigned aFrameID);

typedef void __fastcall (__closure *TOnFrameDestroyedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, unsigned aFrameID);

typedef void __fastcall (__closure *TOnInitializationErrorEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypes::wvstring aErrorMessage);

typedef void __fastcall (__closure *TOnPrintCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, Uwvtypes::TWVPrintStatus aResult);

typedef void __fastcall (__closure *TOnRefreshIgnoreCacheCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypes::wvstring aResultObjectAsJson);

typedef void __fastcall (__closure *TOnRetrieveHTMLCompletedEvent)(System::TObject* Sender, bool aResult, const Uwvtypes::wvstring aHTML);

typedef void __fastcall (__closure *TOnRetrieveTextCompletedEvent)(System::TObject* Sender, bool aResult, const Uwvtypes::wvstring aText);

typedef void __fastcall (__closure *TOnRetrieveMHTMLCompletedEvent)(System::TObject* Sender, bool aResult, const Uwvtypes::wvstring aMHTML);

typedef void __fastcall (__closure *TOnClearCacheCompletedEvent)(System::TObject* Sender, bool aResult);

typedef void __fastcall (__closure *TOnClearDataForOriginCompletedEvent)(System::TObject* Sender, bool aResult);

typedef void __fastcall (__closure *TOnOfflineCompletedEvent)(System::TObject* Sender, bool aResult);

typedef void __fastcall (__closure *TOnIgnoreCertificateErrorsCompletedEvent)(System::TObject* Sender, bool aResult);

typedef void __fastcall (__closure *TOnSimulateKeyEventCompletedEvent)(System::TObject* Sender, bool aResult);

typedef void __fastcall (__closure *TOnIsMutedChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView);

typedef void __fastcall (__closure *TOnIsDocumentPlayingAudioChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView);

typedef void __fastcall (__closure *TOnIsDefaultDownloadDialogOpenChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView);

typedef void __fastcall (__closure *TOnProcessInfosChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Environment aEnvironment);

typedef void __fastcall (__closure *TOnFrameNavigationStartingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnFrameNavigationCompletedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnFrameContentLoadingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnFrameDOMContentLoadedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnFrameWebMessageReceivedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnBasicAuthenticationRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventArgs aArgs);

typedef void __fastcall (__closure *TOnContextMenuRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventArgs aArgs);

typedef void __fastcall (__closure *TOnCustomItemSelectedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2ContextMenuItem aMenuItem);

typedef void __fastcall (__closure *TOnStatusBarTextChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView);

typedef void __fastcall (__closure *TOnFramePermissionRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs2 aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnClearBrowsingDataCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode);

typedef void __fastcall (__closure *TOnServerCertificateErrorActionsCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode);

typedef void __fastcall (__closure *TOnServerCertificateErrorDetectedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventArgs aArgs);

typedef void __fastcall (__closure *TOnFaviconChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const System::_di_IInterface aArgs);

typedef void __fastcall (__closure *TOnGetFaviconCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const _di_IStream aResult);

typedef void __fastcall (__closure *TOnPrintToPdfStreamCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const _di_IStream aResult);

typedef void __fastcall (__closure *TOnGetCustomSchemesEvent)(System::TObject* Sender, Uwvtypes::TWVCustomSchemeInfoArray &aCustomSchemes);

typedef void __fastcall (__closure *TOnGetNonDefaultPermissionSettingsCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypelibrary::_di_ICoreWebView2PermissionSettingCollectionView aResult);

typedef void __fastcall (__closure *TOnSetPermissionStateCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode);

typedef void __fastcall (__closure *TOnLaunchingExternalUriSchemeEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventArgs aArgs);

typedef void __fastcall (__closure *TOnGetProcessExtendedInfosCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypelibrary::_di_ICoreWebView2ProcessExtendedInfoCollection aResult);

typedef void __fastcall (__closure *TOnBrowserExtensionRemoveCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypes::wvstring aExtensionID);

typedef void __fastcall (__closure *TOnBrowserExtensionEnableCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypes::wvstring aExtensionID);

typedef void __fastcall (__closure *TOnProfileAddBrowserExtensionCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypelibrary::_di_ICoreWebView2BrowserExtension aResult);

typedef void __fastcall (__closure *TOnProfileGetBrowserExtensionsCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, const Uwvtypelibrary::_di_ICoreWebView2BrowserExtensionList aResult);

typedef void __fastcall (__closure *TOnProfileDeletedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Profile aProfile);

typedef void __fastcall (__closure *TOnExecuteScriptWithResultCompletedEvent)(System::TObject* Sender, HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptResult aResult, int aExecutionID);

typedef void __fastcall (__closure *TOnNonClientRegionChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2CompositionController aController, const Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventArgs aArgs);

typedef void __fastcall (__closure *TOnNotificationReceivedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventArgs aArgs);

typedef void __fastcall (__closure *TOnNotificationCloseRequestedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Notification aNotification, const System::_di_IInterface aArgs);

typedef void __fastcall (__closure *TOnSaveAsUIShowingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventArgs aArgs);

typedef void __fastcall (__closure *TOnShowSaveAsUICompletedEvent)(System::TObject* Sender, HRESULT aErrorCode, Uwvtypes::TWVSaveAsUIResult aResult);

typedef void __fastcall (__closure *TOnSaveFileSecurityCheckStartingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventArgs aArgs);

typedef void __fastcall (__closure *TOnScreenCaptureStartingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2 aWebView, const Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs aArgs);

typedef void __fastcall (__closure *TOnFrameScreenCaptureStartingEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnFrameChildFrameCreatedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Frame aFrame, const Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs aArgs, unsigned aFrameID);

typedef void __fastcall (__closure *TOnFindActiveMatchIndexChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Find aFindSession, const System::_di_IInterface aArgs);

typedef void __fastcall (__closure *TOnFindMatchCountChangedEvent)(System::TObject* Sender, const Uwvtypelibrary::_di_ICoreWebView2Find aFindSession, const System::_di_IInterface aArgs);

typedef void __fastcall (__closure *TOnFindStartCompletedEvent)(System::TObject* Sender, HRESULT aErrorCode);

typedef void __fastcall (__closure *TOnCompMsgEvent)(System::TObject* Sender, Winapi::Messages::TMessage &aMessage, bool &aHandled);

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvevents */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVEVENTS)
using namespace Uwvevents;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwveventsHPP
