﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2BrowserExtension.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2browserextensionHPP
#define Uwvcorewebview2browserextensionHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2browserextension
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2BrowserExtension;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2BrowserExtension : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2BrowserExtension FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetID();
	Uwvtypes::wvstring __fastcall GetName();
	bool __fastcall GetIsEnabled();
	
public:
	__fastcall TCoreWebView2BrowserExtension(const Uwvtypelibrary::_di_ICoreWebView2BrowserExtension aBaseIntf);
	__fastcall virtual ~TCoreWebView2BrowserExtension();
	bool __fastcall Remove(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall Enable(bool aIsEnabled, System::Classes::TComponent* const aBrowserComponent);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2BrowserExtension BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring ID = {read=GetID};
	__property Uwvtypes::wvstring Name = {read=GetName};
	__property bool IsEnabled = {read=GetIsEnabled, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2browserextension */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2BROWSEREXTENSION)
using namespace Uwvcorewebview2browserextension;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2browserextensionHPP
