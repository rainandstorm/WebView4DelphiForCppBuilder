﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Profile.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2profileHPP
#define Uwvcorewebview2profileHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2profile
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Profile;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2Profile : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Profile FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2Profile2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2Profile3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2Profile4 FBaseIntf4;
	Uwvtypelibrary::_di_ICoreWebView2Profile5 FBaseIntf5;
	Uwvtypelibrary::_di_ICoreWebView2Profile6 FBaseIntf6;
	Uwvtypelibrary::_di_ICoreWebView2Profile7 FBaseIntf7;
	Uwvtypelibrary::_di_ICoreWebView2Profile8 FBaseIntf8;
	Uwvtypelibrary::EventRegistrationToken FProfileDeletedToken;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetProfileName();
	bool __fastcall GetIsInPrivateModeEnabled();
	Uwvtypes::wvstring __fastcall GetProfilePath();
	Uwvtypes::wvstring __fastcall GetDefaultDownloadFolderPath();
	Uwvtypes::TWVPreferredColorScheme __fastcall GetPreferredColorScheme();
	Uwvtypes::TWVTrackingPreventionLevel __fastcall GetPreferredTrackingPreventionLevel();
	Uwvtypelibrary::_di_ICoreWebView2CookieManager __fastcall GetCookieManager();
	bool __fastcall GetIsPasswordAutosaveEnabled();
	bool __fastcall GetIsGeneralAutofillEnabled();
	void __fastcall SetDefaultDownloadFolderPath(const Uwvtypes::wvstring aValue);
	void __fastcall SetPreferredColorScheme(Uwvtypes::TWVPreferredColorScheme aValue);
	void __fastcall SetPreferredTrackingPreventionLevel(Uwvtypes::TWVTrackingPreventionLevel aValue);
	void __fastcall SetIsPasswordAutosaveEnabled(bool aValue);
	void __fastcall SetIsGeneralAutofillEnabled(bool aValue);
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddProfileDeletedEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2Profile(const Uwvtypelibrary::_di_ICoreWebView2Profile aBaseIntf);
	__fastcall virtual ~TCoreWebView2Profile();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall ClearBrowsingData(Uwvtypes::TWVBrowsingDataKinds dataKinds, const Uwvtypelibrary::_di_ICoreWebView2ClearBrowsingDataCompletedHandler handler);
	bool __fastcall ClearBrowsingDataInTimeRange(Uwvtypes::TWVBrowsingDataKinds dataKinds, const System::TDateTime startTime, const System::TDateTime endTime, const Uwvtypelibrary::_di_ICoreWebView2ClearBrowsingDataCompletedHandler handler);
	bool __fastcall ClearBrowsingDataAll(const Uwvtypelibrary::_di_ICoreWebView2ClearBrowsingDataCompletedHandler handler);
	bool __fastcall SetPermissionState(Uwvtypes::TWVPermissionKind PermissionKind, const Uwvtypes::wvstring origin, Uwvtypes::TWVPermissionState State, const Uwvtypelibrary::_di_ICoreWebView2SetPermissionStateCompletedHandler completedHandler);
	bool __fastcall GetNonDefaultPermissionSettings(const Uwvtypelibrary::_di_ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler completedHandler);
	bool __fastcall AddBrowserExtension(const Uwvtypes::wvstring extensionFolderPath, const Uwvtypelibrary::_di_ICoreWebView2ProfileAddBrowserExtensionCompletedHandler completedHandler);
	bool __fastcall GetBrowserExtensions(const Uwvtypelibrary::_di_ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler completedHandler);
	bool __fastcall Delete();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Profile BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring ProfileName = {read=GetProfileName};
	__property bool IsInPrivateModeEnabled = {read=GetIsInPrivateModeEnabled, nodefault};
	__property Uwvtypes::wvstring ProfilePath = {read=GetProfilePath};
	__property Uwvtypes::wvstring DefaultDownloadFolderPath = {read=GetDefaultDownloadFolderPath, write=SetDefaultDownloadFolderPath};
	__property Uwvtypes::TWVPreferredColorScheme PreferredColorScheme = {read=GetPreferredColorScheme, write=SetPreferredColorScheme, nodefault};
	__property Uwvtypes::TWVTrackingPreventionLevel PreferredTrackingPreventionLevel = {read=GetPreferredTrackingPreventionLevel, write=SetPreferredTrackingPreventionLevel, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2CookieManager CookieManager = {read=GetCookieManager};
	__property bool IsPasswordAutosaveEnabled = {read=GetIsPasswordAutosaveEnabled, write=SetIsPasswordAutosaveEnabled, nodefault};
	__property bool IsGeneralAutofillEnabled = {read=GetIsGeneralAutofillEnabled, write=SetIsGeneralAutofillEnabled, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2profile */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2PROFILE)
using namespace Uwvcorewebview2profile;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2profileHPP
