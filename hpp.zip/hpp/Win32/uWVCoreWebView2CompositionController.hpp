﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2CompositionController.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2compositioncontrollerHPP
#define Uwvcorewebview2compositioncontrollerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2compositioncontroller
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2CompositionController;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2CompositionController : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2CompositionController FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2CompositionController2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2CompositionController3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2CompositionController4 FBaseIntf4;
	Uwvtypelibrary::EventRegistrationToken FCursorChangedToken;
	Uwvtypelibrary::EventRegistrationToken FNonClientRegionChanged;
	bool __fastcall GetInitialized();
	System::_di_IInterface __fastcall GetRootVisualTarget();
	HICON __fastcall GetCursor();
	unsigned __fastcall GetSystemCursorID();
	System::_di_IInterface __fastcall GetAutomationProvider();
	void __fastcall SetRootVisualTarget(const System::_di_IInterface aValue);
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddCursorChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddNonClientRegionChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2CompositionController(const Uwvtypelibrary::_di_ICoreWebView2CompositionController aBaseIntf);
	__fastcall virtual ~TCoreWebView2CompositionController();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall SendMouseInput(Uwvtypes::TWVMouseEventKind aEventKind, Uwvtypes::TWVMouseEventVirtualKeys aVirtualKeys, unsigned aMouseData, const Winapi::Windows::TPoint &aPoint);
	bool __fastcall SendPointerInput(Uwvtypes::TWVPointerEventKind aEventKind, const Uwvtypelibrary::_di_ICoreWebView2PointerInfo aPointerInfo);
	HRESULT __fastcall DragEnter(const _di_IDataObject dataObject, System::LongWord keyState, const Winapi::Windows::tagPoint &point, /* out */ System::LongWord &effect);
	HRESULT __fastcall DragLeave();
	HRESULT __fastcall DragOver(System::LongWord keyState, const Winapi::Windows::tagPoint &point, /* out */ System::LongWord &effect);
	HRESULT __fastcall Drop(const _di_IDataObject dataObject, System::LongWord keyState, const Winapi::Windows::tagPoint &point, /* out */ System::LongWord &effect);
	Uwvtypes::TWVNonClientRegionKind __fastcall GetNonClientRegionAtPoint(const Winapi::Windows::TPoint &point);
	Uwvtypelibrary::_di_ICoreWebView2RegionRectCollectionView __fastcall QueryNonClientRegion(Uwvtypes::TWVNonClientRegionKind Kind);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2CompositionController BaseIntf = {read=FBaseIntf};
	__property System::_di_IInterface RootVisualTarget = {read=GetRootVisualTarget, write=SetRootVisualTarget};
	__property HICON Cursor = {read=GetCursor, nodefault};
	__property unsigned SystemCursorID = {read=GetSystemCursorID, nodefault};
	__property System::_di_IInterface AutomationProvider = {read=GetAutomationProvider};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2compositioncontroller */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2COMPOSITIONCONTROLLER)
using namespace Uwvcorewebview2compositioncontroller;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2compositioncontrollerHPP
