﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Cookie.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2cookieHPP
#define Uwvcorewebview2cookieHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2cookie
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Cookie;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2Cookie : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Cookie FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetName();
	Uwvtypes::wvstring __fastcall GetValue();
	Uwvtypes::wvstring __fastcall GetDomain();
	Uwvtypes::wvstring __fastcall GetPath();
	double __fastcall GetExpires();
	System::TDateTime __fastcall GetExpiresDate();
	bool __fastcall GetIsHttpOnly();
	Uwvtypes::TWVCookieSameSiteKind __fastcall GetSameSite();
	bool __fastcall GetIsSecure();
	bool __fastcall GetIsSession();
	void __fastcall SetValue(const Uwvtypes::wvstring aValue);
	void __fastcall SetExpires(const double aValue);
	void __fastcall SetExpiresDate(const System::TDateTime aValue);
	void __fastcall SetIsHttpOnly(bool aValue);
	void __fastcall SetSameSite(Uwvtypes::TWVCookieSameSiteKind aValue);
	void __fastcall SetIsSecure(bool aValue);
	
public:
	__fastcall TCoreWebView2Cookie(const Uwvtypelibrary::_di_ICoreWebView2Cookie aBaseIntf);
	__fastcall virtual ~TCoreWebView2Cookie();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Cookie BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring Name = {read=GetName};
	__property Uwvtypes::wvstring Value = {read=GetValue, write=SetValue};
	__property Uwvtypes::wvstring Domain = {read=GetDomain};
	__property Uwvtypes::wvstring Path = {read=GetPath};
	__property double Expires = {read=GetExpires, write=SetExpires};
	__property System::TDateTime ExpiresDate = {read=GetExpiresDate, write=SetExpiresDate};
	__property bool IsHttpOnly = {read=GetIsHttpOnly, write=SetIsHttpOnly, nodefault};
	__property Uwvtypes::TWVCookieSameSiteKind SameSite = {read=GetSameSite, write=SetSameSite, nodefault};
	__property bool IsSecure = {read=GetIsSecure, write=SetIsSecure, nodefault};
	__property bool IsSession = {read=GetIsSession, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2cookie */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2COOKIE)
using namespace Uwvcorewebview2cookie;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2cookieHPP
