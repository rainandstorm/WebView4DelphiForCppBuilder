﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVMiscFunctions.pas' rev: 36.00 (Windows)

#ifndef UwvmiscfunctionsHPP
#define UwvmiscfunctionsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <System.Classes.hpp>
#include <System.UITypes.hpp>
#include <Winapi.ActiveX.hpp>
#include <System.SysUtils.hpp>
#include <System.Math.hpp>
#include <System.StrUtils.hpp>
#include <uWVConstants.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvmiscfunctions
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
#define SHLWAPIDLL L"shlwapi.dll"
extern "C" System::LongBool __stdcall PathIsRelativeAnsi(char * pszPath);
extern "C" System::LongBool __stdcall PathIsRelativeUnicode(System::WideChar * pszPath);
extern "C" System::LongBool __stdcall PathCanonicalizeAnsi(char * pszBuf, char * pszPath);
extern "C" System::LongBool __stdcall PathCanonicalizeUnicode(System::WideChar * pszBuf, System::WideChar * pszPath);
extern "C" System::LongBool __stdcall PathIsUNCAnsi(char * pszPath);
extern "C" System::LongBool __stdcall PathIsUNCUnicode(System::WideChar * pszPath);
extern "C" System::LongBool __stdcall PathIsURLAnsi(char * pszPath);
extern "C" System::LongBool __stdcall PathIsURLUnicode(System::WideChar * pszPath);
extern DELPHI_PACKAGE System::WideChar * __fastcall AllocCoTaskMemStr(const Uwvtypes::wvstring aString);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall LowestChromiumVersion(void);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall LowestLoaderDLLVersion(void);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall EnvironmentCreationErrorToString(HRESULT aErrorCode);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall ControllerCreationErrorToString(HRESULT aErrorCode);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall ControllerOptionsCreationErrorToString(HRESULT aErrorCode);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall CompositionControllerCreationErrorToString(HRESULT aErrorCode);
extern DELPHI_PACKAGE System::Uitypes::TColor __fastcall CoreWebViewColorToDelphiColor(const Uwvtypelibrary::COREWEBVIEW2_COLOR aColor);
extern DELPHI_PACKAGE Uwvtypelibrary::COREWEBVIEW2_COLOR __fastcall DelphiColorToCoreWebViewColor(const System::Uitypes::TColor aColor);
extern DELPHI_PACKAGE int __fastcall GetScreenDPI(void);
extern DELPHI_PACKAGE float __fastcall GetDeviceScaleFactor(void);
extern DELPHI_PACKAGE void __fastcall OutputDebugMessage(const System::UnicodeString aMessage);
extern DELPHI_PACKAGE bool __fastcall CustomExceptionHandler(const System::UnicodeString aFunctionName, System::Sysutils::Exception* const aException);
extern DELPHI_PACKAGE void __fastcall LogMouseEvent(Uwvtypes::TWVMouseEventKind aEventKind, Uwvtypes::TWVMouseEventVirtualKeys aVirtualKeys, unsigned aMouseData, const Winapi::Windows::TPoint &aPoint);
extern DELPHI_PACKAGE bool __fastcall TryIso8601BasicToDate(const System::UnicodeString Str, /* out */ System::TDateTime &Date);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall JSONUnescape(const Uwvtypes::wvstring Source);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall JSONEscape(const Uwvtypes::wvstring Source);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall EditingCommandToString(Uwvtypes::TWV2EditingCommand aEditingCommand);
extern DELPHI_PACKAGE bool __fastcall DeleteDirContents(const System::UnicodeString aDirectory, System::Classes::TStringList* const aExcludeFiles = (System::Classes::TStringList*)(0x0));
extern DELPHI_PACKAGE System::Uitypes::TCursor __fastcall SystemCursorIDToDelphiCursor(unsigned aSystemCursorID);
extern DELPHI_PACKAGE bool __fastcall LoggedQueryInterface(const System::_di_IInterface aBaseIntf, const GUID &aGUID, /* out */ void *Obj);
extern DELPHI_PACKAGE bool __fastcall CustomPathIsRelative(const Uwvtypes::wvstring aPath);
extern DELPHI_PACKAGE bool __fastcall CustomPathIsURL(const Uwvtypes::wvstring aPath);
extern DELPHI_PACKAGE bool __fastcall CustomPathIsUNC(const Uwvtypes::wvstring aPath);
extern DELPHI_PACKAGE bool __fastcall CustomPathCanonicalize(const Uwvtypes::wvstring aOriginalPath, Uwvtypes::wvstring &aCanonicalPath);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall CustomAbsolutePath(const Uwvtypes::wvstring aPath, bool aMustExist = false);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall GetModulePath(void);
extern DELPHI_PACKAGE Uwvtypes::wvstring __fastcall EscapeCommandLineParameter(const Uwvtypes::wvstring aParameter);
extern DELPHI_PACKAGE System::AnsiString __fastcall CustomURLDecode(const Uwvtypes::wvstring aEncodedStr);
}	/* namespace Uwvmiscfunctions */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVMISCFUNCTIONS)
using namespace Uwvmiscfunctions;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvmiscfunctionsHPP
