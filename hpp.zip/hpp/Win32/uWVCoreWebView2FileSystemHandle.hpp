﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2FileSystemHandle.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2filesystemhandleHPP
#define Uwvcorewebview2filesystemhandleHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2filesystemhandle
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2FileSystemHandle;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2FileSystemHandle : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2FileSystemHandle FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVFileSystemHandleKind __fastcall GetKind();
	Uwvtypes::wvstring __fastcall GetPath();
	Uwvtypes::TWVFileSystemHandlePermission __fastcall GetPermission();
	
public:
	__fastcall TCoreWebView2FileSystemHandle(const Uwvtypelibrary::_di_ICoreWebView2FileSystemHandle aBaseIntf);
	__fastcall virtual ~TCoreWebView2FileSystemHandle();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2FileSystemHandle BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVFileSystemHandleKind Kind = {read=GetKind, nodefault};
	__property Uwvtypes::wvstring Path = {read=GetPath};
	__property Uwvtypes::TWVFileSystemHandlePermission Permission = {read=GetPermission, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2filesystemhandle */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2FILESYSTEMHANDLE)
using namespace Uwvcorewebview2filesystemhandle;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2filesystemhandleHPP
