﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2CustomSchemeRegistration.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2customschemeregistrationHPP
#define Uwvcorewebview2customschemeregistrationHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.SysUtils.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2customschemeregistration
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2CustomSchemeRegistration;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2CustomSchemeRegistration : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	Uwvtypes::TWVCustomSchemeInfo FCustomSchemeInfo;
	HRESULT __stdcall Get_SchemeName(/* out */ System::WideChar * &SchemeName);
	HRESULT __stdcall Get_TreatAsSecure(/* out */ int &TreatAsSecure);
	HRESULT __stdcall Set_TreatAsSecure(int TreatAsSecure);
	HRESULT __stdcall GetAllowedOrigins(/* out */ unsigned &allowedOriginsCount, /* out */ System::PPWideChar &allowedOrigins);
	HRESULT __stdcall SetAllowedOrigins(unsigned allowedOriginsCount, System::PPWideChar allowedOrigins);
	HRESULT __stdcall Get_HasAuthorityComponent(/* out */ int &HasAuthorityComponent);
	HRESULT __stdcall Set_HasAuthorityComponent(int HasAuthorityComponent);
	
public:
	__fastcall TCoreWebView2CustomSchemeRegistration(const Uwvtypes::TWVCustomSchemeInfo &aCustomSchemeInfo)/* overload */;
	__fastcall TCoreWebView2CustomSchemeRegistration(const Uwvtypes::wvstring aSchemeName, const Uwvtypes::wvstring aAllowedDomains, bool aTreatAsSecure, bool aHasAuthorityComponent)/* overload */;
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TCoreWebView2CustomSchemeRegistration() { }
	
private:
	void *__ICoreWebView2CustomSchemeRegistration;	// Uwvtypelibrary::ICoreWebView2CustomSchemeRegistration 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {D60AC92C-37A6-4B26-A39E-95CFE59047BB}
	operator Uwvtypelibrary::_di_ICoreWebView2CustomSchemeRegistration()
	{
		Uwvtypelibrary::_di_ICoreWebView2CustomSchemeRegistration intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CustomSchemeRegistration*(void) { return (Uwvtypelibrary::ICoreWebView2CustomSchemeRegistration*)&__ICoreWebView2CustomSchemeRegistration; }
	#endif
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2customschemeregistration */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2CUSTOMSCHEMEREGISTRATION)
using namespace Uwvcorewebview2customschemeregistration;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2customschemeregistrationHPP
