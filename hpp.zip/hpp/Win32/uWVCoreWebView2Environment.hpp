﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Environment.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2environmentHPP
#define Uwvcorewebview2environmentHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <Winapi.ActiveX.hpp>
#include <System.SysUtils.hpp>
#include <uWVInterfaces.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2environment
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Environment;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2Environment : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Environment FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2Environment2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2Environment3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2Environment4 FBaseIntf4;
	Uwvtypelibrary::_di_ICoreWebView2Environment5 FBaseIntf5;
	Uwvtypelibrary::_di_ICoreWebView2Environment6 FBaseIntf6;
	Uwvtypelibrary::_di_ICoreWebView2Environment7 FBaseIntf7;
	Uwvtypelibrary::_di_ICoreWebView2Environment8 FBaseIntf8;
	Uwvtypelibrary::_di_ICoreWebView2Environment9 FBaseIntf9;
	Uwvtypelibrary::_di_ICoreWebView2Environment10 FBaseIntf10;
	Uwvtypelibrary::_di_ICoreWebView2Environment11 FBaseIntf11;
	Uwvtypelibrary::_di_ICoreWebView2Environment12 FBaseIntf12;
	Uwvtypelibrary::_di_ICoreWebView2Environment13 FBaseIntf13;
	Uwvtypelibrary::_di_ICoreWebView2Environment14 FBaseIntf14;
	Uwvtypelibrary::_di_ICoreWebView2Environment15 FBaseIntf15;
	Uwvtypelibrary::EventRegistrationToken FNewBrowserVersionAvailableEventToken;
	Uwvtypelibrary::EventRegistrationToken FBrowserProcessExitedEventToken;
	Uwvtypelibrary::EventRegistrationToken FProcessInfosChangedEventToken;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetBrowserVersionInfo();
	bool __fastcall GetSupportsCompositionController();
	bool __fastcall GetSupportsControllerOptions();
	Uwvtypes::wvstring __fastcall GetUserDataFolder();
	Uwvtypelibrary::_di_ICoreWebView2ProcessInfoCollection __fastcall GetProcessInfos();
	Uwvtypes::wvstring __fastcall GetFailureReportFolderPath();
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddNewBrowserVersionAvailableEvent(System::Classes::TComponent* const aLoaderComponent);
	bool __fastcall AddBrowserProcessExitedLoaderEvent(System::Classes::TComponent* const aLoaderComponent);
	bool __fastcall AddBrowserProcessExitedBrowserEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddProcessInfosChangedLoaderEvent(System::Classes::TComponent* const aLoaderComponent);
	bool __fastcall AddProcessInfosChangedBrowserEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2Environment(const Uwvtypelibrary::_di_ICoreWebView2Environment aBaseIntf);
	__fastcall virtual ~TCoreWebView2Environment();
	bool __fastcall AddAllLoaderEvents(System::Classes::TComponent* const aLoaderComponent);
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall CreateCoreWebView2Controller(Winapi::Windows::THandle aParentWindow, const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents, HRESULT &aResult);
	bool __fastcall CreateWebResourceResponse(const _di_IStream aContent, int aStatusCode, Uwvtypes::wvstring aReasonPhrase, Uwvtypes::wvstring aHeaders, Uwvtypelibrary::_di_ICoreWebView2WebResourceResponse &aResponse);
	bool __fastcall CreateWebResourceRequest(const Uwvtypes::wvstring aURI, const Uwvtypes::wvstring aMethod, const _di_IStream aPostData, const Uwvtypes::wvstring aHeaders, Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest &aRequest);
	bool __fastcall CreateCoreWebView2CompositionController(Winapi::Windows::THandle aParentWindow, const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents, HRESULT &aResult);
	bool __fastcall CreateCoreWebView2PointerInfo(Uwvtypelibrary::_di_ICoreWebView2PointerInfo &aPointerInfo);
	bool __fastcall GetAutomationProviderForWindow(Winapi::Windows::THandle aHandle, System::_di_IInterface &aProvider);
	bool __fastcall CreatePrintSettings(Uwvtypelibrary::_di_ICoreWebView2PrintSettings &aPrintSettings);
	bool __fastcall CreateContextMenuItem(const Uwvtypes::wvstring aLabel, const _di_IStream aIconStream, Uwvtypes::TWVMenuItemKind aKind, Uwvtypelibrary::_di_ICoreWebView2ContextMenuItem &aMenuItem);
	bool __fastcall CreateCoreWebView2ControllerOptions(Uwvtypelibrary::_di_ICoreWebView2ControllerOptions &aOptions, HRESULT &aResult);
	bool __fastcall CreateCoreWebView2ControllerWithOptions(HWND aParentWindow, const Uwvtypelibrary::_di_ICoreWebView2ControllerOptions aOptions, const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents, HRESULT &aResult);
	bool __fastcall CreateCoreWebView2CompositionControllerWithOptions(HWND aParentWindow, const Uwvtypelibrary::_di_ICoreWebView2ControllerOptions aOptions, const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents, HRESULT &aResult);
	bool __fastcall CreateSharedBuffer(unsigned __int64 aSize, Uwvtypelibrary::_di_ICoreWebView2SharedBuffer &aSharedBuffer);
	bool __fastcall GetProcessExtendedInfos(const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents);
	bool __fastcall CreateWebFileSystemFileHandle(const Uwvtypes::wvstring aPath, Uwvtypes::TWVFileSystemHandlePermission aPermission, Uwvtypelibrary::_di_ICoreWebView2FileSystemHandle &aValue);
	bool __fastcall CreateWebFileSystemDirectoryHandle(const Uwvtypes::wvstring aPath, Uwvtypes::TWVFileSystemHandlePermission aPermission, Uwvtypelibrary::_di_ICoreWebView2FileSystemHandle &aValue);
	bool __fastcall CreateObjectCollection(unsigned aLength, System::_di_IInterface &aItems, Uwvtypelibrary::_di_ICoreWebView2ObjectCollection &aObjectCollection);
	bool __fastcall CreateFindOptions(Uwvtypelibrary::_di_ICoreWebView2FindOptions &aFindOptions);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Environment BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring BrowserVersionInfo = {read=GetBrowserVersionInfo};
	__property bool SupportsCompositionController = {read=GetSupportsCompositionController, nodefault};
	__property bool SupportsControllerOptions = {read=GetSupportsControllerOptions, nodefault};
	__property Uwvtypes::wvstring UserDataFolder = {read=GetUserDataFolder};
	__property Uwvtypelibrary::_di_ICoreWebView2ProcessInfoCollection ProcessInfos = {read=GetProcessInfos};
	__property Uwvtypes::wvstring FailureReportFolderPath = {read=GetFailureReportFolderPath};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2environment */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2ENVIRONMENT)
using namespace Uwvcorewebview2environment;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2environmentHPP
