﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2FrameInfoCollectionIterator.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2frameinfocollectioniteratorHPP
#define Uwvcorewebview2frameinfocollectioniteratorHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2frameinfocollectioniterator
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2FrameInfoCollectionIterator;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2FrameInfoCollectionIterator : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2FrameInfoCollectionIterator FBaseIntf;
	bool __fastcall GetInitialized();
	bool __fastcall GetHasCurrent();
	Uwvtypelibrary::_di_ICoreWebView2FrameInfo __fastcall GetCurrent();
	
public:
	__fastcall TCoreWebView2FrameInfoCollectionIterator(const Uwvtypelibrary::_di_ICoreWebView2FrameInfoCollectionIterator aBaseIntf);
	__fastcall virtual ~TCoreWebView2FrameInfoCollectionIterator();
	bool __fastcall MoveNext();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameInfoCollectionIterator BaseIntf = {read=FBaseIntf};
	__property bool HasCurrent = {read=GetHasCurrent, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameInfo Current = {read=GetCurrent};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2frameinfocollectioniterator */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2FRAMEINFOCOLLECTIONITERATOR)
using namespace Uwvcorewebview2frameinfocollectioniterator;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2frameinfocollectioniteratorHPP
