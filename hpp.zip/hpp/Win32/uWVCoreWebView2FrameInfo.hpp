﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2FrameInfo.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2frameinfoHPP
#define Uwvcorewebview2frameinfoHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2frameinfo
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2FrameInfo;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2FrameInfo : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2FrameInfo FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2FrameInfo2 FBaseIntf2;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetName();
	Uwvtypes::wvstring __fastcall GetSource();
	Uwvtypelibrary::_di_ICoreWebView2FrameInfo __fastcall GetParentFrameInfo();
	unsigned __fastcall GetFrameId();
	Uwvtypes::TWVFrameKind __fastcall GetFrameKind();
	Uwvtypes::wvstring __fastcall GetFrameKindStr();
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2FrameInfo(const Uwvtypelibrary::_di_ICoreWebView2FrameInfo aBaseIntf);
	__fastcall virtual ~TCoreWebView2FrameInfo();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameInfo BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring Name = {read=GetName};
	__property Uwvtypes::wvstring Source = {read=GetSource};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameInfo ParentFrameInfo = {read=GetParentFrameInfo};
	__property unsigned FrameId = {read=GetFrameId, nodefault};
	__property Uwvtypes::TWVFrameKind FrameKind = {read=GetFrameKind, nodefault};
	__property Uwvtypes::wvstring FrameKindStr = {read=GetFrameKindStr};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2frameinfo */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2FRAMEINFO)
using namespace Uwvcorewebview2frameinfo;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2frameinfoHPP
