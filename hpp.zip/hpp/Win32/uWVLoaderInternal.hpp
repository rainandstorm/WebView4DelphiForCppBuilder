﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVLoaderInternal.pas' rev: 36.00 (Windows)

#ifndef UwvloaderinternalHPP
#define UwvloaderinternalHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.ShlObj.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvloaderinternal
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE HRESULT __stdcall Internal_CreateCoreWebView2EnvironmentWithOptions(System::WideChar * browserExecutableFolder, System::WideChar * userDataFolder, const Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions environmentOptions, const Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler environment_created_handler);
extern DELPHI_PACKAGE HRESULT __stdcall Internal_CreateCoreWebView2Environment(const Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler environment_created_handler);
extern DELPHI_PACKAGE HRESULT __stdcall Internal_GetAvailableCoreWebView2BrowserVersionString(System::WideChar * browserExecutableFolder, Winapi::Windows::PLPWSTR pVersionInfo);
extern DELPHI_PACKAGE HRESULT __stdcall Internal_GetAvailableCoreWebView2BrowserVersionStringWithOptions(System::WideChar * browserExecutableFolder, const Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions environmentOptions, Winapi::Windows::PLPWSTR pVersionInfo);
extern DELPHI_PACKAGE HRESULT __stdcall Internal_CompareBrowserVersions(System::WideChar * version1, System::WideChar * version2, System::PInteger pRet);
}	/* namespace Uwvloaderinternal */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVLOADERINTERNAL)
using namespace Uwvloaderinternal;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvloaderinternalHPP
