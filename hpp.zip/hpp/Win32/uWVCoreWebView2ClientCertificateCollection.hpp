﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ClientCertificateCollection.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2clientcertificatecollectionHPP
#define Uwvcorewebview2clientcertificatecollectionHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2clientcertificatecollection
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ClientCertificateCollection;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ClientCertificateCollection : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ClientCertificateCollection FBaseIntf;
	bool __fastcall GetInitialized();
	unsigned __fastcall GetCount();
	Uwvtypelibrary::_di_ICoreWebView2ClientCertificate __fastcall GetValueAtIndex(unsigned index);
	
public:
	__fastcall TCoreWebView2ClientCertificateCollection(const Uwvtypelibrary::_di_ICoreWebView2ClientCertificateCollection aBaseIntf);
	__fastcall virtual ~TCoreWebView2ClientCertificateCollection();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ClientCertificateCollection BaseIntf = {read=FBaseIntf};
	__property unsigned Count = {read=GetCount, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ClientCertificate Items[unsigned idx] = {read=GetValueAtIndex};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2clientcertificatecollection */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2CLIENTCERTIFICATECOLLECTION)
using namespace Uwvcorewebview2clientcertificatecollection;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2clientcertificatecollectionHPP
