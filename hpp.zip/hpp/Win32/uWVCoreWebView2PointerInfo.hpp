﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2PointerInfo.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2pointerinfoHPP
#define Uwvcorewebview2pointerinfoHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2pointerinfo
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2PointerInfo;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2PointerInfo : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2PointerInfo FBaseIntf;
	bool __fastcall GetInitialized();
	unsigned __fastcall GetPointerKind();
	unsigned __fastcall GetPointerId();
	unsigned __fastcall GetFrameId();
	unsigned __fastcall GetPointerFlags();
	System::Types::TRect __fastcall GetPointerDeviceRect();
	System::Types::TRect __fastcall GetDisplayRect();
	System::Types::TPoint __fastcall GetPixelLocation();
	System::Types::TPoint __fastcall GetHimetricLocation();
	System::Types::TPoint __fastcall GetPixelLocationRaw();
	System::Types::TPoint __fastcall GetHimetricLocationRaw();
	unsigned __fastcall GetTime();
	unsigned __fastcall GetHistoryCount();
	int __fastcall GetInputData();
	unsigned __fastcall GetKeyStates();
	unsigned __int64 __fastcall GetPerformanceCount();
	int __fastcall GetButtonChangeKind();
	unsigned __fastcall GetPenFlags();
	unsigned __fastcall GetPenMask();
	unsigned __fastcall GetPenPressure();
	unsigned __fastcall GetPenRotation();
	int __fastcall GetPenTiltX();
	int __fastcall GetPenTiltY();
	unsigned __fastcall GetTouchFlags();
	unsigned __fastcall GetTouchMask();
	System::Types::TRect __fastcall GetTouchContact();
	System::Types::TRect __fastcall GetTouchContactRaw();
	unsigned __fastcall GetTouchOrientation();
	unsigned __fastcall GetTouchPressure();
	void __fastcall SetPointerKind(unsigned aValue);
	void __fastcall SetPointerId(unsigned aValue);
	void __fastcall SetFrameId(unsigned aValue);
	void __fastcall SetPointerFlags(unsigned aValue);
	void __fastcall SetPointerDeviceRect(const System::Types::TRect &aValue);
	void __fastcall SetDisplayRect(const System::Types::TRect &aValue);
	void __fastcall SetPixelLocation(const System::Types::TPoint &aValue);
	void __fastcall SetHimetricLocation(const System::Types::TPoint &aValue);
	void __fastcall SetPixelLocationRaw(const System::Types::TPoint &aValue);
	void __fastcall SetHimetricLocationRaw(const System::Types::TPoint &aValue);
	void __fastcall SetTime(unsigned aValue);
	void __fastcall SetHistoryCount(unsigned aValue);
	void __fastcall SetInputData(int aValue);
	void __fastcall SetKeyStates(unsigned aValue);
	void __fastcall SetPerformanceCount(unsigned __int64 aValue);
	void __fastcall SetButtonChangeKind(int aValue);
	void __fastcall SetPenFlags(unsigned aValue);
	void __fastcall SetPenMask(unsigned aValue);
	void __fastcall SetPenPressure(unsigned aValue);
	void __fastcall SetPenRotation(unsigned aValue);
	void __fastcall SetPenTiltX(int aValue);
	void __fastcall SetPenTiltY(int aValue);
	void __fastcall SetTouchFlags(unsigned aValue);
	void __fastcall SetTouchMask(unsigned aValue);
	void __fastcall SetTouchContact(const System::Types::TRect &aValue);
	void __fastcall SetTouchContactRaw(const System::Types::TRect &aValue);
	void __fastcall SetTouchOrientation(unsigned aValue);
	void __fastcall SetTouchPressure(unsigned aValue);
	
public:
	__fastcall TCoreWebView2PointerInfo(const Uwvtypelibrary::_di_ICoreWebView2PointerInfo aBaseIntf);
	__fastcall virtual ~TCoreWebView2PointerInfo();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2PointerInfo BaseIntf = {read=FBaseIntf};
	__property unsigned PointerKind = {read=GetPointerKind, write=SetPointerKind, nodefault};
	__property unsigned PointerId = {read=GetPointerId, write=SetPointerId, nodefault};
	__property unsigned FrameId = {read=GetFrameId, write=SetFrameId, nodefault};
	__property unsigned PointerFlags = {read=GetPointerFlags, write=SetPointerFlags, nodefault};
	__property System::Types::TRect PointerDeviceRect = {read=GetPointerDeviceRect, write=SetPointerDeviceRect};
	__property System::Types::TRect DisplayRect = {read=GetDisplayRect, write=SetDisplayRect};
	__property System::Types::TPoint PixelLocation = {read=GetPixelLocation, write=SetPixelLocation};
	__property System::Types::TPoint HimetricLocation = {read=GetHimetricLocation, write=SetHimetricLocation};
	__property System::Types::TPoint PixelLocationRaw = {read=GetPixelLocationRaw, write=SetPixelLocationRaw};
	__property System::Types::TPoint HimetricLocationRaw = {read=GetHimetricLocationRaw, write=SetHimetricLocationRaw};
	__property unsigned Time = {read=GetTime, write=SetTime, nodefault};
	__property unsigned HistoryCount = {read=GetHistoryCount, write=SetHistoryCount, nodefault};
	__property int InputData = {read=GetInputData, write=SetInputData, nodefault};
	__property unsigned KeyStates = {read=GetKeyStates, write=SetKeyStates, nodefault};
	__property unsigned __int64 PerformanceCount = {read=GetPerformanceCount, write=SetPerformanceCount};
	__property int ButtonChangeKind = {read=GetButtonChangeKind, write=SetButtonChangeKind, nodefault};
	__property unsigned PenFlags = {read=GetPenFlags, write=SetPenFlags, nodefault};
	__property unsigned PenMask = {read=GetPenMask, write=SetPenMask, nodefault};
	__property unsigned PenPressure = {read=GetPenPressure, write=SetPenPressure, nodefault};
	__property unsigned PenRotation = {read=GetPenRotation, write=SetPenRotation, nodefault};
	__property int PenTiltX = {read=GetPenTiltX, write=SetPenTiltX, nodefault};
	__property int PenTiltY = {read=GetPenTiltY, write=SetPenTiltY, nodefault};
	__property unsigned TouchFlags = {read=GetTouchFlags, write=SetTouchFlags, nodefault};
	__property unsigned TouchMask = {read=GetTouchMask, write=SetTouchMask, nodefault};
	__property System::Types::TRect TouchContact = {read=GetTouchContact, write=SetTouchContact};
	__property System::Types::TRect TouchContactRaw = {read=GetTouchContactRaw, write=SetTouchContactRaw};
	__property unsigned TouchOrientation = {read=GetTouchOrientation, write=SetTouchOrientation, nodefault};
	__property unsigned TouchPressure = {read=GetTouchPressure, write=SetTouchPressure, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2pointerinfo */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2POINTERINFO)
using namespace Uwvcorewebview2pointerinfo;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2pointerinfoHPP
