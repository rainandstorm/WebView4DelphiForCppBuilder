﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ExecuteScriptResult.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2executescriptresultHPP
#define Uwvcorewebview2executescriptresultHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2executescriptresult
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ExecuteScriptResult;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ExecuteScriptResult : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptResult FBaseIntf;
	bool __fastcall GetInitialized();
	bool __fastcall GetSucceeded();
	Uwvtypes::wvstring __fastcall GetResultAsJson();
	Uwvtypelibrary::_di_ICoreWebView2ScriptException __fastcall GetException();
	
public:
	__fastcall TCoreWebView2ExecuteScriptResult(const Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptResult aBaseIntf);
	__fastcall virtual ~TCoreWebView2ExecuteScriptResult();
	bool __fastcall TryGetResultAsString(Uwvtypes::wvstring &stringResult, bool &value);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptResult BaseIntf = {read=FBaseIntf};
	__property bool Succeeded_ = {read=GetSucceeded, nodefault};
	__property Uwvtypes::wvstring ResultAsJson = {read=GetResultAsJson};
	__property Uwvtypelibrary::_di_ICoreWebView2ScriptException Exception = {read=GetException};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2executescriptresult */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2EXECUTESCRIPTRESULT)
using namespace Uwvcorewebview2executescriptresult;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2executescriptresultHPP
