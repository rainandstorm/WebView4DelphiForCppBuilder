﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ObjectCollection.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2objectcollectionHPP
#define Uwvcorewebview2objectcollectionHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVCoreWebView2ObjectCollectionView.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2objectcollection
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ObjectCollection;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ObjectCollection : public Uwvcorewebview2objectcollectionview::TCoreWebView2ObjectCollectionView
{
	typedef Uwvcorewebview2objectcollectionview::TCoreWebView2ObjectCollectionView inherited;
	
public:
	bool __fastcall RemoveValueAtIndex(unsigned index);
	bool __fastcall InsertValueAtIndex(unsigned index, const System::_di_IInterface value);
public:
	/* TCoreWebView2ObjectCollectionView.Create */ inline __fastcall TCoreWebView2ObjectCollection(const Uwvtypelibrary::_di_ICoreWebView2ObjectCollectionView aBaseIntf) : Uwvcorewebview2objectcollectionview::TCoreWebView2ObjectCollectionView(aBaseIntf) { }
	/* TCoreWebView2ObjectCollectionView.Destroy */ inline __fastcall virtual ~TCoreWebView2ObjectCollection() { }
	
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2objectcollection */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2OBJECTCOLLECTION)
using namespace Uwvcorewebview2objectcollection;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2objectcollectionHPP
