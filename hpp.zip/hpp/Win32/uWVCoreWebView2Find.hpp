﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Find.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2findHPP
#define Uwvcorewebview2findHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <System.UITypes.hpp>
#include <Winapi.Windows.hpp>
#include <System.SysUtils.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2find
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Find;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2Find : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Find FBaseIntf;
	Uwvtypelibrary::EventRegistrationToken FActiveMatchIndexChangedToken;
	Uwvtypelibrary::EventRegistrationToken FMatchCountChangedToken;
	bool __fastcall GetInitialized();
	int __fastcall GetActiveMatchIndex();
	int __fastcall GetMatchCount();
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddActiveMatchIndexChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddMatchCountChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2Find(const Uwvtypelibrary::_di_ICoreWebView2Find aBaseIntf);
	__fastcall virtual ~TCoreWebView2Find();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall Start(const Uwvtypelibrary::_di_ICoreWebView2FindOptions options, const Uwvtypelibrary::_di_ICoreWebView2FindStartCompletedHandler handler);
	bool __fastcall FindNext();
	bool __fastcall FindPrevious();
	bool __fastcall Stop();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Find BaseIntf = {read=FBaseIntf};
	__property int ActiveMatchIndex = {read=GetActiveMatchIndex, nodefault};
	__property int MatchCount = {read=GetMatchCount, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2find */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2FIND)
using namespace Uwvcorewebview2find;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2findHPP
