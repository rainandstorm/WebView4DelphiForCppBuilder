﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2PermissionSetting.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2permissionsettingHPP
#define Uwvcorewebview2permissionsettingHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2permissionsetting
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2PermissionSetting;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2PermissionSetting : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2PermissionSetting FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVPermissionKind __fastcall GetPermissionKind();
	Uwvtypes::wvstring __fastcall GetPermissionOrigin();
	Uwvtypes::TWVPermissionState __fastcall GetPermissionState();
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2PermissionSetting(const Uwvtypelibrary::_di_ICoreWebView2PermissionSetting aBaseIntf);
	__fastcall virtual ~TCoreWebView2PermissionSetting();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2PermissionSetting BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVPermissionKind PermissionKind = {read=GetPermissionKind, nodefault};
	__property Uwvtypes::wvstring PermissionOrigin = {read=GetPermissionOrigin};
	__property Uwvtypes::TWVPermissionState PermissionState = {read=GetPermissionState, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2permissionsetting */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2PERMISSIONSETTING)
using namespace Uwvcorewebview2permissionsetting;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2permissionsettingHPP
