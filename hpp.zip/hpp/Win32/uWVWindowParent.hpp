﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVWindowParent.pas' rev: 36.00 (Windows)

#ifndef UwvwindowparentHPP
#define UwvwindowparentHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Winapi.Messages.hpp>
#include <uWVWinControl.hpp>
#include <uWVBrowserBase.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvwindowparent
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWVWindowParent;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWVWindowParent : public Uwvwincontrol::TWVWinControl
{
	typedef Uwvwincontrol::TWVWinControl inherited;
	
protected:
	Uwvbrowserbase::TWVBrowserBase* FBrowser;
	Uwvbrowserbase::TWVBrowserBase* __fastcall GetBrowser();
	void __fastcall SetBrowser(Uwvbrowserbase::TWVBrowserBase* const aValue);
	virtual void __fastcall WndProc(Winapi::Messages::TMessage &aMessage);
	virtual void __fastcall Notification(System::Classes::TComponent* AComponent, System::Classes::TOperation Operation);
	DYNAMIC void __fastcall Resize();
	
public:
	__fastcall virtual TWVWindowParent(System::Classes::TComponent* AOwner);
	virtual void __fastcall UpdateSize();
	virtual void __fastcall SetFocus();
	
__published:
	__property Uwvbrowserbase::TWVBrowserBase* Browser = {read=GetBrowser, write=SetBrowser};
public:
	/* TWinControl.CreateParented */ inline __fastcall TWVWindowParent(HWND ParentWindow) : Uwvwincontrol::TWVWinControl(ParentWindow) { }
	/* TWinControl.Destroy */ inline __fastcall virtual ~TWVWindowParent() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvwindowparent */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVWINDOWPARENT)
using namespace Uwvwindowparent;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvwindowparentHPP
