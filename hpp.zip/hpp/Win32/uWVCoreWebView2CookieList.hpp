﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2CookieList.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2cookielistHPP
#define Uwvcorewebview2cookielistHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2cookielist
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2CookieList;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2CookieList : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2CookieList FBaseIntf;
	bool __fastcall GetInitialized();
	unsigned __fastcall GetCount();
	Uwvtypelibrary::_di_ICoreWebView2Cookie __fastcall GetValueAtIndex(unsigned index);
	
public:
	__fastcall TCoreWebView2CookieList(const Uwvtypelibrary::_di_ICoreWebView2CookieList aBaseIntf);
	__fastcall virtual ~TCoreWebView2CookieList();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2CookieList BaseIntf = {read=FBaseIntf};
	__property unsigned Count = {read=GetCount, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Cookie Items[unsigned idx] = {read=GetValueAtIndex};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2cookielist */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2COOKIELIST)
using namespace Uwvcorewebview2cookielist;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2cookielistHPP
