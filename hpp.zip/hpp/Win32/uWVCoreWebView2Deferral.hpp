﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Deferral.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2deferralHPP
#define Uwvcorewebview2deferralHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2deferral
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Deferral;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2Deferral : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Deferral FBaseIntf;
	bool __fastcall GetInitialized();
	
public:
	__fastcall TCoreWebView2Deferral(const Uwvtypelibrary::_di_ICoreWebView2Deferral aBaseIntf);
	__fastcall virtual ~TCoreWebView2Deferral();
	bool __fastcall Complete();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral BaseIntf = {read=FBaseIntf};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2deferral */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2DEFERRAL)
using namespace Uwvcorewebview2deferral;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2deferralHPP
