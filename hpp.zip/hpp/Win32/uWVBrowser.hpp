﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVBrowser.pas' rev: 36.00 (Windows)

#ifndef UwvbrowserHPP
#define UwvbrowserHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <Vcl.Forms.hpp>
#include <System.Math.hpp>
#include <uWVBrowserBase.hpp>
#include <uWVTypes.hpp>
#include <uWVEvents.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvbrowser
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWVBrowser;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWVBrowser : public Uwvbrowserbase::TWVBrowserBase
{
	typedef Uwvbrowserbase::TWVBrowserBase inherited;
	
protected:
	Vcl::Forms::TCustomForm* __fastcall GetParentForm();
	
public:
	virtual void __fastcall MoveFormTo(const int x, const int y);
	virtual void __fastcall MoveFormBy(const int x, const int y);
	virtual void __fastcall ResizeFormWidthTo(const int x);
	virtual void __fastcall ResizeFormHeightTo(const int y);
	virtual void __fastcall SetFormLeftTo(const int x);
	virtual void __fastcall SetFormTopTo(const int y);
	
__published:
	__property BrowserExecPath = {default=0};
	__property UserDataFolder = {default=0};
	__property DefaultURL = {default=0};
	__property AdditionalBrowserArguments = {default=0};
	__property Language = {default=0};
	__property TargetCompatibleBrowserVersion = {default=0};
	__property AllowSingleSignOnUsingOSPrimaryAccount;
	__property OnInitializationError;
	__property OnEnvironmentCompleted;
	__property OnControllerCompleted;
	__property OnAfterCreated;
	__property OnExecuteScriptCompleted;
	__property OnCapturePreviewCompleted;
	__property OnNavigationStarting;
	__property OnNavigationCompleted;
	__property OnFrameNavigationStarting;
	__property OnFrameNavigationCompleted;
	__property OnSourceChanged;
	__property OnHistoryChanged;
	__property OnContentLoading;
	__property OnDocumentTitleChanged;
	__property OnNewWindowRequested;
	__property OnWebResourceRequested;
	__property OnScriptDialogOpening;
	__property OnPermissionRequested;
	__property OnProcessFailed;
	__property OnWebMessageReceived;
	__property OnContainsFullScreenElementChanged;
	__property OnWindowCloseRequested;
	__property OnDevToolsProtocolEventReceived;
	__property OnZoomFactorChanged;
	__property OnMoveFocusRequested;
	__property OnAcceleratorKeyPressed;
	__property OnGotFocus;
	__property OnLostFocus;
	__property OnCursorChanged;
	__property OnBrowserProcessExited;
	__property OnRasterizationScaleChanged;
	__property OnWebResourceResponseReceived;
	__property OnDOMContentLoaded;
	__property OnWebResourceResponseViewGetContentCompleted;
	__property OnGetCookiesCompleted;
	__property OnTrySuspendCompleted;
	__property OnFrameCreated;
	__property OnDownloadStarting;
	__property OnClientCertificateRequested;
	__property OnPrintToPdfCompleted;
	__property OnBytesReceivedChanged;
	__property OnEstimatedEndTimeChanged;
	__property OnDownloadStateChanged;
	__property OnFrameNameChanged;
	__property OnFrameDestroyed;
	__property OnCompositionControllerCompleted;
	__property OnCallDevToolsProtocolMethodCompleted;
	__property OnAddScriptToExecuteOnDocumentCreatedCompleted;
	__property OnWidget0CompMsg;
	__property OnWidget1CompMsg;
	__property OnRenderCompMsg;
	__property OnD3DWindowCompMsg;
	__property OnPrintCompleted;
	__property OnRetrieveHTMLCompleted;
	__property OnRetrieveTextCompleted;
	__property OnRetrieveMHTMLCompleted;
	__property OnClearCacheCompleted;
	__property OnClearDataForOriginCompleted;
	__property OnOfflineCompleted;
	__property OnIgnoreCertificateErrorsCompleted;
	__property OnRefreshIgnoreCacheCompleted;
	__property OnSimulateKeyEventCompleted;
	__property OnIsMutedChanged;
	__property OnIsDocumentPlayingAudioChanged;
	__property OnIsDefaultDownloadDialogOpenChanged;
	__property OnProcessInfosChanged;
	__property OnFrameNavigationStarting2;
	__property OnFrameNavigationCompleted2;
	__property OnFrameContentLoading;
	__property OnFrameDOMContentLoaded;
	__property OnFrameWebMessageReceived;
	__property OnBasicAuthenticationRequested;
	__property OnContextMenuRequested;
	__property OnCustomItemSelected;
	__property OnStatusBarTextChanged;
	__property OnFramePermissionRequested;
	__property OnClearBrowsingDataCompleted;
	__property OnServerCertificateErrorActionsCompleted;
	__property OnServerCertificateErrorDetected;
	__property OnFaviconChanged;
	__property OnGetFaviconCompleted;
	__property OnPrintToPdfStreamCompleted;
	__property OnGetCustomSchemes;
	__property OnGetNonDefaultPermissionSettingsCompleted;
	__property OnSetPermissionStateCompleted;
	__property OnLaunchingExternalUriScheme;
	__property OnGetProcessExtendedInfosCompleted;
	__property OnBrowserExtensionRemoveCompleted;
	__property OnBrowserExtensionEnableCompleted;
	__property OnProfileAddBrowserExtensionCompleted;
	__property OnProfileGetBrowserExtensionsCompleted;
	__property OnProfileDeleted;
	__property OnExecuteScriptWithResultCompleted;
	__property OnNonClientRegionChanged;
	__property OnNotificationReceived;
	__property OnNotificationCloseRequested;
	__property OnSaveAsUIShowing;
	__property OnShowSaveAsUICompleted;
	__property OnSaveFileSecurityCheckStarting;
	__property OnScreenCaptureStarting;
	__property OnFrameScreenCaptureStarting;
	__property OnFrameChildFrameCreated;
	__property OnFindActiveMatchIndexChanged;
	__property OnFindMatchCountChanged;
	__property OnFindStartCompleted;
public:
	/* TWVBrowserBase.Create */ inline __fastcall virtual TWVBrowser(System::Classes::TComponent* AOwner) : Uwvbrowserbase::TWVBrowserBase(AOwner) { }
	/* TWVBrowserBase.Destroy */ inline __fastcall virtual ~TWVBrowser() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvbrowser */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVBROWSER)
using namespace Uwvbrowser;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvbrowserHPP
