﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2CookieManager.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2cookiemanagerHPP
#define Uwvcorewebview2cookiemanagerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2cookiemanager
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2CookieManager;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2CookieManager : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2CookieManager FBaseIntf;
	bool __fastcall GetInitialized();
	
public:
	__fastcall TCoreWebView2CookieManager(const Uwvtypelibrary::_di_ICoreWebView2CookieManager aBaseIntf);
	__fastcall virtual ~TCoreWebView2CookieManager();
	Uwvtypelibrary::_di_ICoreWebView2Cookie __fastcall CreateCookie(const Uwvtypes::wvstring aName, const Uwvtypes::wvstring aValue, const Uwvtypes::wvstring aDomain, const Uwvtypes::wvstring aPath);
	Uwvtypelibrary::_di_ICoreWebView2Cookie __fastcall CopyCookie(const Uwvtypelibrary::_di_ICoreWebView2Cookie aCookie);
	bool __fastcall GetCookies(const Uwvtypes::wvstring aURI, const Uwvtypelibrary::_di_ICoreWebView2GetCookiesCompletedHandler aHandler);
	bool __fastcall AddOrUpdateCookie(const Uwvtypelibrary::_di_ICoreWebView2Cookie aCookie);
	bool __fastcall DeleteCookie(const Uwvtypelibrary::_di_ICoreWebView2Cookie aCookie);
	bool __fastcall DeleteCookies(const Uwvtypes::wvstring aName, const Uwvtypes::wvstring aURI);
	bool __fastcall DeleteCookiesWithDomainAndPath(const Uwvtypes::wvstring aName, const Uwvtypes::wvstring aDomain, const Uwvtypes::wvstring aPath);
	bool __fastcall DeleteAllCookies();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2CookieManager BaseIntf = {read=FBaseIntf};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2cookiemanager */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2COOKIEMANAGER)
using namespace Uwvcorewebview2cookiemanager;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2cookiemanagerHPP
