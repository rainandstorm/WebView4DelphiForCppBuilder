﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ControllerOptions.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2controlleroptionsHPP
#define Uwvcorewebview2controlleroptionsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <System.UITypes.hpp>
#include <Winapi.Windows.hpp>
#include <System.SysUtils.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2controlleroptions
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ControllerOptions;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ControllerOptions : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ControllerOptions FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2ControllerOptions2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2ControllerOptions3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2ControllerOptions4 FBaseIntf4;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetProfileName();
	bool __fastcall GetIsInPrivateModeEnabled();
	Uwvtypes::wvstring __fastcall GetScriptLocale();
	System::Uitypes::TColor __fastcall GetDefaultBackgroundColor();
	bool __fastcall GetAllowHostInputProcessing();
	void __fastcall SetProfileName(const Uwvtypes::wvstring aValue);
	void __fastcall SetIsInPrivateModeEnabled(bool aValue);
	void __fastcall SetScriptLocale(const Uwvtypes::wvstring aValue);
	void __fastcall SetDefaultBackgroundColor(const System::Uitypes::TColor aValue);
	void __fastcall SetAllowHostInputProcessing(bool aValue);
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2ControllerOptions(const Uwvtypelibrary::_di_ICoreWebView2ControllerOptions aBaseIntf);
	__fastcall virtual ~TCoreWebView2ControllerOptions();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ControllerOptions BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring ProfileName = {read=GetProfileName, write=SetProfileName};
	__property bool IsInPrivateModeEnabled = {read=GetIsInPrivateModeEnabled, write=SetIsInPrivateModeEnabled, nodefault};
	__property Uwvtypes::wvstring ScriptLocale = {read=GetScriptLocale, write=SetScriptLocale};
	__property System::Uitypes::TColor DefaultBackgroundColor = {read=GetDefaultBackgroundColor, write=SetDefaultBackgroundColor, nodefault};
	__property bool AllowHostInputProcessing = {read=GetAllowHostInputProcessing, write=SetAllowHostInputProcessing, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2controlleroptions */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2CONTROLLEROPTIONS)
using namespace Uwvcorewebview2controlleroptions;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2controlleroptionsHPP
