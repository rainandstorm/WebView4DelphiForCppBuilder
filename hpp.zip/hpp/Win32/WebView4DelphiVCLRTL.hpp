﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'WebView4DelphiVCLRTL.dpk' rev: 36.00 (Windows)

#ifndef Webview4delphivclrtlHPP
#define Webview4delphivclrtlHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>	// (rtl)
#include <SysInit.hpp>
#include <uWVConstants.hpp>
#include <uWVLibFunctions.hpp>
#include <uWVLoader.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>
#include <uWVInterfaces.hpp>
#include <uWVCoreWebView2.hpp>
#include <uWVCoreWebView2Controller.hpp>
#include <uWVCoreWebView2Settings.hpp>
#include <uWVCoreWebView2Environment.hpp>
#include <uWVWinControl.hpp>
#include <uWVWindowParent.hpp>
#include <uWVBrowser.hpp>
#include <uWVMiscFunctions.hpp>
#include <uWVCoreWebView2HttpRequestHeaders.hpp>
#include <uWVCoreWebView2HttpHeadersCollectionIterator.hpp>
#include <uWVCoreWebView2EnvironmentOptions.hpp>
#include <uWVCoreWebView2Delegates.hpp>
#include <uWVCoreWebView2Args.hpp>
#include <uWVCoreWebView2WebResourceRequest.hpp>
#include <uWVCoreWebView2WebResourceResponse.hpp>
#include <uWVCoreWebView2Deferral.hpp>
#include <uWVCoreWebView2PointerInfo.hpp>
#include <uWVCoreWebView2CompositionController.hpp>
#include <uWVEvents.hpp>
#include <uWVCoreWebView2PrintSettings.hpp>
#include <uWVCoreWebView2WebResourceResponseView.hpp>
#include <uWVCoreWebView2FrameInfoCollection.hpp>
#include <uWVCoreWebView2FrameInfoCollectionIterator.hpp>
#include <uWVCoreWebView2FrameInfo.hpp>
#include <uWVCoreWebView2CookieManager.hpp>
#include <uWVCoreWebView2Cookie.hpp>
#include <uWVCoreWebView2CookieList.hpp>
#include <uWVCoreWebView2ClientCertificateCollection.hpp>
#include <uWVCoreWebView2ClientCertificate.hpp>
#include <uWVCoreWebView2StringCollection.hpp>
#include <uWVCoreWebView2WindowFeatures.hpp>
#include <uWVCoreWebView2DownloadOperation.hpp>
#include <uWVCoreWebView2Frame.hpp>
#include <uWVCoreWebView2HttpResponseHeaders.hpp>
#include <uWVBrowserBase.hpp>
#include <uWVCoreWebView2ProcessInfoCollection.hpp>
#include <uWVCoreWebView2ProcessInfo.hpp>
#include <uWVCoreWebView2BasicAuthenticationResponse.hpp>
#include <uWVCoreWebView2ContextMenuItemCollection.hpp>
#include <uWVCoreWebView2ContextMenuItem.hpp>
#include <uWVCoreWebView2ContextMenuTarget.hpp>
#include <uWVCoreWebView2Profile.hpp>
#include <uWVCoreWebView2ControllerOptions.hpp>
#include <uWVLoaderInternal.hpp>
#include <uWVCoreWebView2Certificate.hpp>
#include <uWVCoreWebView2CustomSchemeRegistration.hpp>
#include <uWVCoreWebView2PermissionSettingCollectionView.hpp>
#include <uWVCoreWebView2PermissionSetting.hpp>
#include <uWVCoreWebView2SharedBuffer.hpp>
#include <uWVCoreWebView2ObjectCollectionView.hpp>
#include <uWVCoreWebView2File.hpp>
#include <uWVCoreWebView2ProcessExtendedInfo.hpp>
#include <uWVCoreWebView2ProcessExtendedInfoCollection.hpp>
#include <uWVCoreWebView2BrowserExtension.hpp>
#include <uWVCoreWebView2BrowserExtensionList.hpp>
#include <uWVCoreWebView2ScriptException.hpp>
#include <uWVCoreWebView2ExecuteScriptResult.hpp>
#include <uWVCoreWebView2RegionRectCollectionView.hpp>
#include <uWVCoreWebView2ObjectCollection.hpp>
#include <uWVCoreWebView2FileSystemHandle.hpp>
#include <uWVCoreWebView2Notification.hpp>
#include <uWVCoreWebView2FindOptions.hpp>
#include <uWVCoreWebView2Find.hpp>
#include <System.UITypes.hpp>	// (rtl)
#include <Winapi.Windows.PkgHelper.hpp>	// (rtl)
#include <Winapi.PsAPI.hpp>	// (rtl)
#include <System.Character.hpp>	// (rtl)
#include <System.Internal.ExcUtils.hpp>	// (rtl)
#include <System.SysUtils.hpp>	// (rtl)
#include <System.VarUtils.hpp>	// (rtl)
#include <System.Variants.hpp>	// (rtl)
#include <System.TypInfo.hpp>	// (rtl)
#include <System.Math.hpp>	// (rtl)
#include <System.Generics.Defaults.hpp>	// (rtl)
#include <System.TimeSpan.hpp>	// (rtl)
#include <System.SyncObjs.hpp>	// (rtl)
#include <System.Rtti.hpp>	// (rtl)
#include <System.Classes.hpp>	// (rtl)
#include <System.DateUtils.hpp>	// (rtl)
#include <System.IOUtils.hpp>	// (rtl)
#include <System.IniFiles.hpp>	// (rtl)
#include <System.Win.Registry.hpp>	// (rtl)
#include <System.UIConsts.hpp>	// (rtl)
#include <Vcl.Graphics.hpp>	// (vcl)
#include <System.AnsiStrings.hpp>	// (rtl)
#include <System.Win.ComObj.hpp>	// (rtl)
#include <System.JSON.hpp>	// (rtl)
#include <System.NetEncoding.hpp>	// (rtl)
#include <System.Messaging.hpp>	// (rtl)
#include <System.Actions.hpp>	// (rtl)
#include <Vcl.ActnList.hpp>	// (vcl)
#include <System.HelpIntfs.hpp>	// (rtl)
#include <Winapi.UxTheme.hpp>	// (rtl)
#include <Vcl.GraphUtil.hpp>	// (vcl)
#include <Vcl.StdCtrls.hpp>	// (vcl)
#include <Vcl.Clipbrd.hpp>	// (vcl)
#include <Vcl.Printers.hpp>	// (vcl)
#include <Vcl.ComCtrls.hpp>	// (vcl)
#include <Vcl.Dialogs.hpp>	// (vcl)
#include <Vcl.ExtCtrls.hpp>	// (vcl)
#include <Vcl.Themes.hpp>	// (vcl)
#include <Winapi.FlatSB.hpp>	// (rtl)
#include <Vcl.Forms.hpp>	// (vcl)
#include <Vcl.Menus.hpp>	// (vcl)
#include <Winapi.MsCTF.PkgHelper.hpp>	// (rtl)
#include <Vcl.Controls.hpp>	// (vcl)
// PRG_EXT: .bpl
// BPI_DIR: C:\Users\Public\Documents\Embarcadero\Studio\23.0\Dcp
// OBJ_DIR: C:\Users\Public\Documents\Embarcadero\Studio\23.0\Dcp
// OBJ_EXT: .obj

//-- user supplied -----------------------------------------------------------

namespace Webview4delphivclrtl
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
}	/* namespace Webview4delphivclrtl */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_WEBVIEW4DELPHIVCLRTL)
using namespace Webview4delphivclrtl;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Webview4delphivclrtlHPP
