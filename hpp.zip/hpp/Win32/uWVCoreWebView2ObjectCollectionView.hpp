﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ObjectCollectionView.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2objectcollectionviewHPP
#define Uwvcorewebview2objectcollectionviewHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2objectcollectionview
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ObjectCollectionView;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ObjectCollectionView : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ObjectCollectionView FBaseIntf;
	bool __fastcall GetInitialized();
	unsigned __fastcall GetCount();
	System::_di_IInterface __fastcall GetValueAtIndex(unsigned index);
	
public:
	__fastcall TCoreWebView2ObjectCollectionView(const Uwvtypelibrary::_di_ICoreWebView2ObjectCollectionView aBaseIntf);
	__fastcall virtual ~TCoreWebView2ObjectCollectionView();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ObjectCollectionView BaseIntf = {read=FBaseIntf};
	__property unsigned Count = {read=GetCount, nodefault};
	__property System::_di_IInterface Items[unsigned idx] = {read=GetValueAtIndex};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2objectcollectionview */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2OBJECTCOLLECTIONVIEW)
using namespace Uwvcorewebview2objectcollectionview;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2objectcollectionviewHPP
