﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ContextMenuItem.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2contextmenuitemHPP
#define Uwvcorewebview2contextmenuitemHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2contextmenuitem
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ContextMenuItem;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ContextMenuItem : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ContextMenuItem FBaseIntf;
	Uwvtypelibrary::EventRegistrationToken FCustomItemSelectedToken;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetName();
	Uwvtypes::wvstring __fastcall GetLabel();
	int __fastcall GetCommandId();
	Uwvtypes::wvstring __fastcall GetShortcutKeyDescription();
	_di_IStream __fastcall GetIcon();
	Uwvtypes::TWVMenuItemKind __fastcall GetKind();
	bool __fastcall GetIsEnabled();
	bool __fastcall GetIsChecked();
	Uwvtypelibrary::_di_ICoreWebView2ContextMenuItemCollection __fastcall GetChildren();
	void __fastcall SetIsEnabled(bool aValue);
	void __fastcall SetIsChecked(bool aValue);
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddCustomItemSelectedEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2ContextMenuItem(const Uwvtypelibrary::_di_ICoreWebView2ContextMenuItem aBaseIntf);
	__fastcall virtual ~TCoreWebView2ContextMenuItem();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ContextMenuItem BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring Name = {read=GetName};
	__property Uwvtypes::wvstring Label_ = {read=GetLabel};
	__property int CommandId = {read=GetCommandId, nodefault};
	__property Uwvtypes::wvstring ShortcutKeyDescription = {read=GetShortcutKeyDescription};
	__property _di_IStream Icon = {read=GetIcon};
	__property Uwvtypes::TWVMenuItemKind Kind = {read=GetKind, nodefault};
	__property bool IsEnabled = {read=GetIsEnabled, write=SetIsEnabled, nodefault};
	__property bool IsChecked = {read=GetIsChecked, write=SetIsChecked, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ContextMenuItemCollection Children = {read=GetChildren};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2contextmenuitem */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2CONTEXTMENUITEM)
using namespace Uwvcorewebview2contextmenuitem;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2contextmenuitemHPP
