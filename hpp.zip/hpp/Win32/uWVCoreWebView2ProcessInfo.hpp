﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ProcessInfo.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2processinfoHPP
#define Uwvcorewebview2processinfoHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2processinfo
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ProcessInfo;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2ProcessInfo : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ProcessInfo FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVProcessKind __fastcall GetKind();
	Uwvtypes::wvstring __fastcall GetKindStr();
	int __fastcall GetProcessId();
	
public:
	__fastcall TCoreWebView2ProcessInfo(const Uwvtypelibrary::_di_ICoreWebView2ProcessInfo aBaseIntf);
	__fastcall virtual ~TCoreWebView2ProcessInfo();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ProcessInfo BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::TWVProcessKind Kind = {read=GetKind, nodefault};
	__property Uwvtypes::wvstring KindStr = {read=GetKindStr};
	__property int ProcessId = {read=GetProcessId, nodefault};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2processinfo */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2PROCESSINFO)
using namespace Uwvcorewebview2processinfo;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2processinfoHPP
