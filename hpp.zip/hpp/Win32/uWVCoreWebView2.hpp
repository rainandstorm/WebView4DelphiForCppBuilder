﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2HPP
#define Uwvcorewebview2HPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.ActiveX.hpp>
#include <System.SysUtils.hpp>
#include <System.Types.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2;
//-- type declarations -------------------------------------------------------
#pragma pack(push,4)
class PASCALIMPLEMENTATION TCoreWebView2 : public System::TObject
{
	typedef System::TObject inherited;
	
	
private:
	typedef System::DynamicArray<Uwvtypelibrary::EventRegistrationToken> _TCoreWebView2__1;
	
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2 FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2_2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2_3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2_4 FBaseIntf4;
	Uwvtypelibrary::_di_ICoreWebView2_5 FBaseIntf5;
	Uwvtypelibrary::_di_ICoreWebView2_6 FBaseIntf6;
	Uwvtypelibrary::_di_ICoreWebView2_7 FBaseIntf7;
	Uwvtypelibrary::_di_ICoreWebView2_8 FBaseIntf8;
	Uwvtypelibrary::_di_ICoreWebView2_9 FBaseIntf9;
	Uwvtypelibrary::_di_ICoreWebView2_10 FBaseIntf10;
	Uwvtypelibrary::_di_ICoreWebView2_11 FBaseIntf11;
	Uwvtypelibrary::_di_ICoreWebView2_12 FBaseIntf12;
	Uwvtypelibrary::_di_ICoreWebView2_13 FBaseIntf13;
	Uwvtypelibrary::_di_ICoreWebView2_14 FBaseIntf14;
	Uwvtypelibrary::_di_ICoreWebView2_15 FBaseIntf15;
	Uwvtypelibrary::_di_ICoreWebView2_16 FBaseIntf16;
	Uwvtypelibrary::_di_ICoreWebView2_17 FBaseIntf17;
	Uwvtypelibrary::_di_ICoreWebView2_18 FBaseIntf18;
	Uwvtypelibrary::_di_ICoreWebView2_19 FBaseIntf19;
	Uwvtypelibrary::_di_ICoreWebView2_20 FBaseIntf20;
	Uwvtypelibrary::_di_ICoreWebView2_21 FBaseIntf21;
	Uwvtypelibrary::_di_ICoreWebView2_22 FBaseIntf22;
	Uwvtypelibrary::_di_ICoreWebView2_23 FBaseIntf23;
	Uwvtypelibrary::_di_ICoreWebView2_24 FBaseIntf24;
	Uwvtypelibrary::_di_ICoreWebView2_25 FBaseIntf25;
	Uwvtypelibrary::_di_ICoreWebView2_26 FBaseIntf26;
	Uwvtypelibrary::_di_ICoreWebView2_27 FBaseIntf27;
	Uwvtypelibrary::_di_ICoreWebView2_28 FBaseIntf28;
	Uwvtypelibrary::EventRegistrationToken FContainsFullScreenElementChangedToken;
	Uwvtypelibrary::EventRegistrationToken FContentLoadingToken;
	Uwvtypelibrary::EventRegistrationToken FDocumentTitleChangedToken;
	Uwvtypelibrary::EventRegistrationToken FFrameNavigationStartingToken;
	Uwvtypelibrary::EventRegistrationToken FFrameNavigationCompletedToken;
	Uwvtypelibrary::EventRegistrationToken FHistoryChangedToken;
	Uwvtypelibrary::EventRegistrationToken FNavigationStartingToken;
	Uwvtypelibrary::EventRegistrationToken FNavigationCompletedToken;
	Uwvtypelibrary::EventRegistrationToken FNewWindowRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FPermissionRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FProcessFailedToken;
	Uwvtypelibrary::EventRegistrationToken FScriptDialogOpeningToken;
	Uwvtypelibrary::EventRegistrationToken FSourceChangedToken;
	Uwvtypelibrary::EventRegistrationToken FWebResourceRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FWebMessageReceivedToken;
	Uwvtypelibrary::EventRegistrationToken FWindowCloseRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FWebResourceResponseReceivedToken;
	Uwvtypelibrary::EventRegistrationToken FDOMContentLoadedToken;
	Uwvtypelibrary::EventRegistrationToken FFrameCreatedToken;
	Uwvtypelibrary::EventRegistrationToken FDownloadStartingToken;
	Uwvtypelibrary::EventRegistrationToken FClientCertificateRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FIsMutedChangedToken;
	Uwvtypelibrary::EventRegistrationToken FIsDocumentPlayingAudioChangedToken;
	Uwvtypelibrary::EventRegistrationToken FIsDefaultDownloadDialogOpenChangedToken;
	Uwvtypelibrary::EventRegistrationToken FBasicAuthenticationRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FContextMenuRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FStatusBarTextChangedToken;
	Uwvtypelibrary::EventRegistrationToken FServerCertificateErrorDetectedToken;
	Uwvtypelibrary::EventRegistrationToken FFaviconChangedToken;
	Uwvtypelibrary::EventRegistrationToken FLaunchingExternalUriSchemeToken;
	Uwvtypelibrary::EventRegistrationToken FNotificationReceivedToken;
	Uwvtypelibrary::EventRegistrationToken FSaveAsUIShowingToken;
	Uwvtypelibrary::EventRegistrationToken FSaveFileSecurityCheckStartingToken;
	Uwvtypelibrary::EventRegistrationToken FScreenCaptureStartingToken;
	unsigned FFrameIDCopy;
	System::Classes::TStringList* FDevToolsEventNames;
	_TCoreWebView2__1 FDevToolsEventTokens;
	bool __fastcall GetInitialized();
	unsigned __fastcall GetBrowserProcessID();
	bool __fastcall GetCanGoBack();
	bool __fastcall GetCanGoForward();
	bool __fastcall GetContainsFullScreenElement();
	Uwvtypes::wvstring __fastcall GetDocumentTitle();
	Uwvtypes::wvstring __fastcall GetSource();
	Uwvtypelibrary::_di_ICoreWebView2CookieManager __fastcall GetCookieManager();
	Uwvtypelibrary::_di_ICoreWebView2Environment __fastcall GetEnvironment();
	bool __fastcall GetIsSuspended();
	Uwvtypelibrary::_di_ICoreWebView2Settings __fastcall GetSettings();
	bool __fastcall GetIsMuted();
	bool __fastcall GetIsDocumentPlayingAudio();
	bool __fastcall GetIsDefaultDownloadDialogOpen();
	Uwvtypes::TWVDefaultDownloadDialogCornerAlignment __fastcall GetDefaultDownloadDialogCornerAlignment();
	System::Types::TPoint __fastcall GetDefaultDownloadDialogMargin();
	Uwvtypes::wvstring __fastcall GetStatusBarText();
	Uwvtypelibrary::_di_ICoreWebView2Profile __fastcall GetProfile();
	Uwvtypes::wvstring __fastcall GetFaviconURI();
	Uwvtypes::TWVMemoryUsageTargetLevel __fastcall GetMemoryUsageTargetLevel();
	unsigned __fastcall GetFrameID();
	Uwvtypelibrary::_di_ICoreWebView2Find __fastcall GetFind();
	void __fastcall SetIsMuted(bool aValue);
	void __fastcall SetDefaultDownloadDialogCornerAlignment(Uwvtypes::TWVDefaultDownloadDialogCornerAlignment aValue);
	void __fastcall SetDefaultDownloadDialogMargin(const System::Types::TPoint &aValue);
	void __fastcall SetMemoryUsageTargetLevel(Uwvtypes::TWVMemoryUsageTargetLevel aValue);
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall UnsubscribeAllDevToolsProtocolEvents();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddNavigationStartingEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddNavigationCompletedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddSourceChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddHistoryChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddContentLoadingEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddDocumentTitleChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddNewWindowRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameNavigationStartingEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameNavigationCompletedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddWebResourceRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddScriptDialogOpeningEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddPermissionRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddProcessFailedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddWebMessageReceivedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddContainsFullScreenElementChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddWindowCloseRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddWebResourceResponseReceivedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddDOMContentLoadedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameCreatedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddDownloadStartingEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddClientCertificateRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddIsMutedChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddIsDocumentPlayingAudioChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddIsDefaultDownloadDialogOpenChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddBasicAuthenticationRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddContextMenuRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddStatusBarTextChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddServerCertificateErrorDetectedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFaviconChanged(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddLaunchingExternalUriScheme(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddNotificationReceived(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddSaveAsUIShowing(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddSaveFileSecurityCheckStarting(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddScreenCaptureStarting(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2(const Uwvtypelibrary::_di_ICoreWebView2 aBaseIntf);
	__fastcall virtual ~TCoreWebView2();
	virtual void __fastcall AfterConstruction();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall SubscribeToDevToolsProtocolEvent(const Uwvtypes::wvstring aEventName, int aEventID, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall CapturePreview(Uwvtypes::TWVCapturePreviewImageFormat aImageFormat, const _di_IStream aImageStream, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall ExecuteScript(const Uwvtypes::wvstring JavaScript, int aExecutionID, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall GoBack();
	bool __fastcall GoForward();
	bool __fastcall Navigate(const Uwvtypes::wvstring aURI);
	bool __fastcall NavigateToString(const Uwvtypes::wvstring aHTMLContent);
	bool __fastcall NavigateWithWebResourceRequest(const Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest aRequest);
	bool __fastcall Reload();
	bool __fastcall Stop();
	bool __fastcall TrySuspend(const Uwvtypelibrary::_di_ICoreWebView2TrySuspendCompletedHandler aHandler);
	bool __fastcall Resume();
	bool __fastcall SetVirtualHostNameToFolderMapping(const Uwvtypes::wvstring aHostName, const Uwvtypes::wvstring aFolderPath, Uwvtypes::TWVHostResourceAcccessKind aAccessKind);
	bool __fastcall ClearVirtualHostNameToFolderMapping(const Uwvtypes::wvstring aHostName);
	bool __fastcall OpenTaskManagerWindow();
	bool __fastcall PrintToPdf(const Uwvtypes::wvstring aResultFilePath, const Uwvtypelibrary::_di_ICoreWebView2PrintSettings aPrintSettings, const Uwvtypelibrary::_di_ICoreWebView2PrintToPdfCompletedHandler aHandler);
	bool __fastcall OpenDevToolsWindow();
	bool __fastcall PostWebMessageAsJson(const Uwvtypes::wvstring aWebMessageAsJson);
	bool __fastcall PostWebMessageAsString(const Uwvtypes::wvstring aWebMessageAsString);
	bool __fastcall CallDevToolsProtocolMethod(const Uwvtypes::wvstring aMethodName, const Uwvtypes::wvstring aParametersAsJson, int aExecutionID, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall CallDevToolsProtocolMethodForSession(const Uwvtypes::wvstring aSessionId, const Uwvtypes::wvstring aMethodName, const Uwvtypes::wvstring aParametersAsJson, int aExecutionID, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddWebResourceRequestedFilter(const Uwvtypes::wvstring URI, Uwvtypes::TWVWebResourceContext ResourceContext);
	bool __fastcall RemoveWebResourceRequestedFilter(const Uwvtypes::wvstring URI, Uwvtypes::TWVWebResourceContext ResourceContext);
	bool __fastcall AddHostObjectToScript(const Uwvtypes::wvstring aName, const System::OleVariant &aObject);
	bool __fastcall RemoveHostObjectFromScript(const Uwvtypes::wvstring aName);
	bool __fastcall AddScriptToExecuteOnDocumentCreated(const Uwvtypes::wvstring JavaScript, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall RemoveScriptToExecuteOnDocumentCreated(const Uwvtypes::wvstring aID);
	bool __fastcall OpenDefaultDownloadDialog();
	bool __fastcall CloseDefaultDownloadDialog();
	bool __fastcall ClearServerCertificateErrorActions(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall GetFavicon(Uwvtypes::TWVFaviconImageFormat aFormat, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall Print(const Uwvtypelibrary::_di_ICoreWebView2PrintSettings aPrintSettings, const Uwvtypelibrary::_di_ICoreWebView2PrintCompletedHandler aHandler);
	bool __fastcall ShowPrintUI(Uwvtypes::TWVPrintDialogKind aPrintDialogKind);
	bool __fastcall PrintToPdfStream(const Uwvtypelibrary::_di_ICoreWebView2PrintSettings aPrintSettings, const Uwvtypelibrary::_di_ICoreWebView2PrintToPdfStreamCompletedHandler aHandler);
	bool __fastcall PostSharedBufferToScript(const Uwvtypelibrary::_di_ICoreWebView2SharedBuffer aSharedBuffer, Uwvtypes::TWVSharedBufferAccess aAccess, const Uwvtypes::wvstring aAdditionalDataAsJson);
	bool __fastcall ExecuteScriptWithResult(const Uwvtypes::wvstring JavaScript, int aExecutionID, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddWebResourceRequestedFilterWithRequestSourceKinds(const Uwvtypes::wvstring uri, Uwvtypes::TWVWebResourceContext ResourceContext, Uwvtypes::TWVWebResourceRequestSourceKind requestSourceKinds);
	bool __fastcall RemoveWebResourceRequestedFilterWithRequestSourceKinds(const Uwvtypes::wvstring uri, Uwvtypes::TWVWebResourceContext ResourceContext, Uwvtypes::TWVWebResourceRequestSourceKind requestSourceKinds);
	bool __fastcall PostWebMessageAsJsonWithAdditionalObjects(const Uwvtypes::wvstring webMessageAsJson, const Uwvtypelibrary::_di_ICoreWebView2ObjectCollectionView additionalObjects);
	bool __fastcall ShowSaveAsUI(System::Classes::TComponent* const aBrowserComponent);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2 BaseIntf = {read=FBaseIntf};
	__property Uwvtypelibrary::_di_ICoreWebView2Settings Settings = {read=GetSettings};
	__property unsigned BrowserProcessID = {read=GetBrowserProcessID, nodefault};
	__property bool CanGoBack = {read=GetCanGoBack, nodefault};
	__property bool CanGoForward = {read=GetCanGoForward, nodefault};
	__property bool ContainsFullScreenElement = {read=GetContainsFullScreenElement, nodefault};
	__property Uwvtypes::wvstring DocumentTitle = {read=GetDocumentTitle};
	__property Uwvtypes::wvstring Source = {read=GetSource};
	__property Uwvtypelibrary::_di_ICoreWebView2CookieManager CookieManager = {read=GetCookieManager};
	__property Uwvtypelibrary::_di_ICoreWebView2Environment Environment = {read=GetEnvironment};
	__property bool IsSuspended = {read=GetIsSuspended, nodefault};
	__property bool IsMuted = {read=GetIsMuted, write=SetIsMuted, nodefault};
	__property bool IsDocumentPlayingAudio = {read=GetIsDocumentPlayingAudio, nodefault};
	__property bool IsDefaultDownloadDialogOpen = {read=GetIsDefaultDownloadDialogOpen, nodefault};
	__property Uwvtypes::TWVDefaultDownloadDialogCornerAlignment DefaultDownloadDialogCornerAlignment = {read=GetDefaultDownloadDialogCornerAlignment, write=SetDefaultDownloadDialogCornerAlignment, nodefault};
	__property System::Types::TPoint DefaultDownloadDialogMargin = {read=GetDefaultDownloadDialogMargin, write=SetDefaultDownloadDialogMargin};
	__property Uwvtypes::wvstring StatusBarText = {read=GetStatusBarText};
	__property Uwvtypelibrary::_di_ICoreWebView2Profile Profile = {read=GetProfile};
	__property Uwvtypes::wvstring FaviconURI = {read=GetFaviconURI};
	__property Uwvtypes::TWVMemoryUsageTargetLevel MemoryUsageTargetLevel = {read=GetMemoryUsageTargetLevel, write=SetMemoryUsageTargetLevel, nodefault};
	__property unsigned FrameId = {read=GetFrameID, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Find Find = {read=GetFind};
};

#pragma pack(pop)

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2 */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2)
using namespace Uwvcorewebview2;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2HPP
