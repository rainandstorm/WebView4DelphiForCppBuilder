﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.MultiTouch.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Multitouch_WinHPP
#define Fmx_Multitouch_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <System.Classes.hpp>
#include <FMX.MultiTouch.hpp>
#include <FMX.Types.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Multitouch
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TMultiTouchManagerWin;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TMultiTouchManagerWin : public Fmx::Multitouch::TMultiTouchManager
{
	typedef Fmx::Multitouch::TMultiTouchManager inherited;
	
private:
	bool FDblTapFirstTouchUp;
	bool FPressAndTapPossible;
	bool FPressAndTapSecondTouchDown;
	Fmx::Types::TFmxHandle FDoubleTapTimer;
	Fmx::Types::TFmxHandle FLongTapTimer;
	Fmx::Types::_di_IFMXTimerService FTimerService;
	void __fastcall StandardGesturesDown(const System::Types::TPointF &ALocalPoint);
	void __fastcall StandardGesturesUp(const System::Types::TPointF &ALocalPoint);
	void __fastcall StandardGesturesMove(const System::Types::TPointF &ALocalPoint);
	void __fastcall CreateDoubleTapTimer();
	void __fastcall DestroyDoubleTapTimer();
	void __fastcall DoubleTapTimerHandler();
	void __fastcall CreateLongTapTimer();
	void __fastcall DestroyLongTapTimer();
	void __fastcall LongTapTimerHandler();
	
protected:
	virtual void __fastcall TouchDown();
	virtual void __fastcall TouchUp();
	virtual void __fastcall TouchMove();
	virtual void __fastcall TouchCancel();
	
public:
	__fastcall virtual TMultiTouchManagerWin(System::Classes::TComponent* const AParent);
	__fastcall virtual ~TMultiTouchManagerWin();
	virtual void __fastcall HandleTouches(const Fmx::Types::TTouches ATouches, const Fmx::Types::TTouchAction Action, const Fmx::Types::_di_IControl Control);
	void __fastcall HandleMouseGestures(const System::Types::TPointF &ALocalPoint, const Fmx::Types::TTouchAction Action, const Fmx::Types::_di_IControl Control);
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Win */
}	/* namespace Multitouch */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_MULTITOUCH_WIN)
using namespace Fmx::Multitouch::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_MULTITOUCH)
using namespace Fmx::Multitouch;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Multitouch_WinHPP
