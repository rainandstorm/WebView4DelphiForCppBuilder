﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Delegates.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2delegatesHPP
#define Uwvcorewebview2delegatesHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVInterfaces.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2delegates
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2AcceleratorKeyPressedEventHandler;
class DELPHICLASS TCoreWebView2CapturePreviewCompletedHandler;
class DELPHICLASS TCoreWebView2ContainsFullScreenElementChangedEventHandler;
class DELPHICLASS TCoreWebView2ContentLoadingEventHandler;
class DELPHICLASS TCoreWebView2CreateCoreWebView2ControllerCompletedHandler;
class DELPHICLASS TCoreWebView2DevToolsProtocolEventReceivedEventHandler;
class DELPHICLASS TCoreWebView2DocumentTitleChangedEventHandler;
class DELPHICLASS TCoreWebView2EnvironmentCompletedHandler;
class DELPHICLASS TCoreWebView2ExecuteScriptCompletedHandler;
class DELPHICLASS TCoreWebView2FrameNavigationCompletedEventHandler;
class DELPHICLASS TCoreWebView2FrameNavigationStartingEventHandler;
class DELPHICLASS TCoreWebView2GotFocusEventHandler;
class DELPHICLASS TCoreWebView2HistoryChangedEventHandler;
class DELPHICLASS TCoreWebView2LostFocusEventHandler;
class DELPHICLASS TCoreWebView2MoveFocusRequestedEventHandler;
class DELPHICLASS TCoreWebView2NavigationCompletedEventHandler;
class DELPHICLASS TCoreWebView2NavigationStartingEventHandler;
class DELPHICLASS TCoreWebView2NewBrowserVersionAvailableEventHandler;
class DELPHICLASS TCoreWebView2NewWindowRequestedEventHandler;
class DELPHICLASS TCoreWebView2PermissionRequestedEventHandler;
class DELPHICLASS TCoreWebView2ProcessFailedEventHandler;
class DELPHICLASS TCoreWebView2ScriptDialogOpeningEventHandler;
class DELPHICLASS TCoreWebView2SourceChangedEventHandler;
class DELPHICLASS TCoreWebView2WebMessageReceivedEventHandler;
class DELPHICLASS TCoreWebView2WebResourceRequestedEventHandler;
class DELPHICLASS TCoreWebView2WindowCloseRequestedEventHandler;
class DELPHICLASS TCoreWebView2ZoomFactorChangedEventHandler;
class DELPHICLASS TCoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler;
class DELPHICLASS TCoreWebView2CursorChangedEventHandler;
class DELPHICLASS TCoreWebView2BrowserProcessExitedEventHandler;
class DELPHICLASS TCoreWebView2RasterizationScaleChangedEventHandler;
class DELPHICLASS TCoreWebView2WebResourceResponseReceivedEventHandler;
class DELPHICLASS TCoreWebView2DOMContentLoadedEventHandler;
class DELPHICLASS TCoreWebView2WebResourceResponseViewGetContentCompletedHandler;
class DELPHICLASS TCoreWebView2GetCookiesCompletedHandler;
class DELPHICLASS TCoreWebView2TrySuspendCompletedHandler;
class DELPHICLASS TCoreWebView2FrameCreatedEventHandler;
class DELPHICLASS TCoreWebView2DownloadStartingEventHandler;
class DELPHICLASS TCoreWebView2ClientCertificateRequestedEventHandler;
class DELPHICLASS TCoreWebView2PrintToPdfCompletedHandler;
class DELPHICLASS TCoreWebView2BytesReceivedChangedEventHandler;
class DELPHICLASS TCoreWebView2EstimatedEndTimeChangedEventHandler;
class DELPHICLASS TCoreWebView2StateChangedEventHandler;
class DELPHICLASS TCoreWebView2FrameNameChangedEventHandler;
class DELPHICLASS TCoreWebView2FrameDestroyedEventHandler;
class DELPHICLASS TCoreWebView2CallDevToolsProtocolMethodCompletedHandler;
class DELPHICLASS TCoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler;
class DELPHICLASS TCoreWebView2IsMutedChangedEventHandler;
class DELPHICLASS TCoreWebView2IsDocumentPlayingAudioChangedEventHandler;
class DELPHICLASS TCoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler;
class DELPHICLASS TCoreWebView2ProcessInfosChangedEventHandler;
class DELPHICLASS TCoreWebView2FrameNavigationCompletedEventHandler2;
class DELPHICLASS TCoreWebView2FrameNavigationStartingEventHandler2;
class DELPHICLASS TCoreWebView2FrameContentLoadingEventHandler;
class DELPHICLASS TCoreWebView2FrameDOMContentLoadedEventHandler;
class DELPHICLASS TCoreWebView2FrameWebMessageReceivedEventHandler;
class DELPHICLASS TCoreWebView2BasicAuthenticationRequestedEventHandler;
class DELPHICLASS TCoreWebView2ContextMenuRequestedEventHandler;
class DELPHICLASS TCoreWebView2CustomItemSelectedEventHandler;
class DELPHICLASS TCoreWebView2StatusBarTextChangedEventHandler;
class DELPHICLASS TCoreWebView2FramePermissionRequestedEventHandler;
class DELPHICLASS TCoreWebView2ClearBrowsingDataCompletedHandler;
class DELPHICLASS TCoreWebView2ClearServerCertificateErrorActionsCompletedHandler;
class DELPHICLASS TCoreWebView2ServerCertificateErrorDetectedEventHandler;
class DELPHICLASS TCoreWebView2FaviconChangedEventHandler;
class DELPHICLASS TCoreWebView2GetFaviconCompletedHandler;
class DELPHICLASS TCoreWebView2PrintCompletedHandler;
class DELPHICLASS TCoreWebView2PrintToPdfStreamCompletedHandler;
class DELPHICLASS TCoreWebView2GetNonDefaultPermissionSettingsCompletedHandler;
class DELPHICLASS TCoreWebView2SetPermissionStateCompletedHandler;
class DELPHICLASS TCoreWebView2LaunchingExternalUriSchemeEventHandler;
class DELPHICLASS TCoreWebView2GetProcessExtendedInfosCompletedHandler;
class DELPHICLASS TCoreWebView2BrowserExtensionRemoveCompletedHandler;
class DELPHICLASS TCoreWebView2BrowserExtensionEnableCompletedHandler;
class DELPHICLASS TCoreWebView2ProfileAddBrowserExtensionCompletedHandler;
class DELPHICLASS TCoreWebView2ProfileGetBrowserExtensionsCompletedHandler;
class DELPHICLASS TCoreWebView2ProfileDeletedEventHandler;
class DELPHICLASS TCoreWebView2ExecuteScriptWithResultCompletedHandler;
class DELPHICLASS TCoreWebView2NonClientRegionChangedEventHandler;
class DELPHICLASS TCoreWebView2NotificationReceivedEventHandler;
class DELPHICLASS TCoreWebView2NotificationCloseRequestedEventHandler;
class DELPHICLASS TCoreWebView2SaveAsUIShowingEventHandler;
class DELPHICLASS TCoreWebView2ShowSaveAsUICompletedHandler;
class DELPHICLASS TCoreWebView2SaveFileSecurityCheckStartingEventHandler;
class DELPHICLASS TCoreWebView2ScreenCaptureStartingEventHandler;
class DELPHICLASS TCoreWebView2FrameScreenCaptureStartingEventHandler;
class DELPHICLASS TCoreWebView2FrameChildFrameCreatedEventHandler;
class DELPHICLASS TCoreWebView2FindActiveMatchIndexChangedEventHandler;
class DELPHICLASS TCoreWebView2FindMatchCountChangedEventHandler;
class DELPHICLASS TCoreWebView2FindStartCompletedHandler;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2AcceleratorKeyPressedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventArgs args);
	
public:
	__fastcall TCoreWebView2AcceleratorKeyPressedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2AcceleratorKeyPressedEventHandler();
private:
	void *__ICoreWebView2AcceleratorKeyPressedEventHandler;	// Uwvtypelibrary::ICoreWebView2AcceleratorKeyPressedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {B29C7E28-FA79-41A8-8E44-65811C76DCB2}
	operator Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2AcceleratorKeyPressedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2AcceleratorKeyPressedEventHandler*)&__ICoreWebView2AcceleratorKeyPressedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2CapturePreviewCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode);
	
public:
	__fastcall TCoreWebView2CapturePreviewCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2CapturePreviewCompletedHandler();
private:
	void *__ICoreWebView2CapturePreviewCompletedHandler;	// Uwvtypelibrary::ICoreWebView2CapturePreviewCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {697E05E9-3D8F-45FA-96F4-8FFE1EDEDAF5}
	operator Uwvtypelibrary::_di_ICoreWebView2CapturePreviewCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2CapturePreviewCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CapturePreviewCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2CapturePreviewCompletedHandler*)&__ICoreWebView2CapturePreviewCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ContainsFullScreenElementChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2ContainsFullScreenElementChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ContainsFullScreenElementChangedEventHandler();
private:
	void *__ICoreWebView2ContainsFullScreenElementChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2ContainsFullScreenElementChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {E45D98B1-AFEF-45BE-8BAF-6C7728867F73}
	operator Uwvtypelibrary::_di_ICoreWebView2ContainsFullScreenElementChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ContainsFullScreenElementChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ContainsFullScreenElementChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ContainsFullScreenElementChangedEventHandler*)&__ICoreWebView2ContainsFullScreenElementChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ContentLoadingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs args);
	
public:
	__fastcall TCoreWebView2ContentLoadingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ContentLoadingEventHandler();
private:
	void *__ICoreWebView2ContentLoadingEventHandler;	// Uwvtypelibrary::ICoreWebView2ContentLoadingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {364471E7-F2BE-4910-BDBA-D72077D51C4B}
	operator Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ContentLoadingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ContentLoadingEventHandler*)&__ICoreWebView2ContentLoadingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2CreateCoreWebView2ControllerCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2Controller result_);
	
public:
	__fastcall TCoreWebView2CreateCoreWebView2ControllerCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2CreateCoreWebView2ControllerCompletedHandler();
private:
	void *__ICoreWebView2CreateCoreWebView2ControllerCompletedHandler;	// Uwvtypelibrary::ICoreWebView2CreateCoreWebView2ControllerCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {6C4819F3-C9B7-4260-8127-C9F5BDE7F68C}
	operator Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2ControllerCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2ControllerCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CreateCoreWebView2ControllerCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2CreateCoreWebView2ControllerCompletedHandler*)&__ICoreWebView2CreateCoreWebView2ControllerCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2DevToolsProtocolEventReceivedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	Uwvtypes::wvstring FEventName;
	int FEventID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventArgs args);
	
public:
	Uwvtypelibrary::EventRegistrationToken Token;
	__fastcall TCoreWebView2DevToolsProtocolEventReceivedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, const Uwvtypes::wvstring aEventName, int aEventID);
	__fastcall virtual ~TCoreWebView2DevToolsProtocolEventReceivedEventHandler();
	__property Uwvtypes::wvstring EventName = {read=FEventName};
	__property int EventID = {read=FEventID, nodefault};
private:
	void *__ICoreWebView2DevToolsProtocolEventReceivedEventHandler;	// Uwvtypelibrary::ICoreWebView2DevToolsProtocolEventReceivedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {E2FDA4BE-5456-406C-A261-3D452138362C}
	operator Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2DevToolsProtocolEventReceivedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2DevToolsProtocolEventReceivedEventHandler*)&__ICoreWebView2DevToolsProtocolEventReceivedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2DocumentTitleChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2DocumentTitleChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2DocumentTitleChangedEventHandler();
private:
	void *__ICoreWebView2DocumentTitleChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2DocumentTitleChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {F5F2B923-953E-4042-9F95-F3A118E1AFD4}
	operator Uwvtypelibrary::_di_ICoreWebView2DocumentTitleChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2DocumentTitleChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2DocumentTitleChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2DocumentTitleChangedEventHandler*)&__ICoreWebView2DocumentTitleChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2EnvironmentCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FBrowserEvents;
	void *FLoaderEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2Environment result_);
	
public:
	__fastcall TCoreWebView2EnvironmentCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents)/* overload */;
	__fastcall TCoreWebView2EnvironmentCompletedHandler(const Uwvinterfaces::_di_IWVLoaderEvents aLoaderEvents)/* overload */;
	__fastcall virtual ~TCoreWebView2EnvironmentCompletedHandler();
private:
	void *__ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler;	// Uwvtypelibrary::ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {4E8A3389-C9D8-4BD2-B6B5-124FEE6CC14D}
	operator Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler*)&__ICoreWebView2CreateCoreWebView2EnvironmentCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ExecuteScriptCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	int FID;
	HRESULT __stdcall Invoke(HRESULT errorCode, System::WideChar * result_);
	
public:
	__fastcall TCoreWebView2ExecuteScriptCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, int aExecutionID);
	__fastcall virtual ~TCoreWebView2ExecuteScriptCompletedHandler();
private:
	void *__ICoreWebView2ExecuteScriptCompletedHandler;	// Uwvtypelibrary::ICoreWebView2ExecuteScriptCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {49511172-CC67-4BCA-9923-137112F4C4CC}
	operator Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ExecuteScriptCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ExecuteScriptCompletedHandler*)&__ICoreWebView2ExecuteScriptCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameNavigationCompletedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameNavigationCompletedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2FrameNavigationCompletedEventHandler();
private:
	void *__ICoreWebView2NavigationCompletedEventHandler;	// Uwvtypelibrary::ICoreWebView2NavigationCompletedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {D33A35BF-1C49-4F98-93AB-006E0533FE1C}
	operator Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NavigationCompletedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NavigationCompletedEventHandler*)&__ICoreWebView2NavigationCompletedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameNavigationStartingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameNavigationStartingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2FrameNavigationStartingEventHandler();
private:
	void *__ICoreWebView2NavigationStartingEventHandler;	// Uwvtypelibrary::ICoreWebView2NavigationStartingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {9ADBE429-F36D-432B-9DDC-F8881FBD76E3}
	operator Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NavigationStartingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NavigationStartingEventHandler*)&__ICoreWebView2NavigationStartingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2GotFocusEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2GotFocusEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2GotFocusEventHandler();
private:
	void *__ICoreWebView2FocusChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2FocusChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {05EA24BD-6452-4926-9014-4B82B498135D}
	operator Uwvtypelibrary::_di_ICoreWebView2FocusChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FocusChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FocusChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FocusChangedEventHandler*)&__ICoreWebView2FocusChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2HistoryChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2HistoryChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2HistoryChangedEventHandler();
private:
	void *__ICoreWebView2HistoryChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2HistoryChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {C79A420C-EFD9-4058-9295-3E8B4BCAB645}
	operator Uwvtypelibrary::_di_ICoreWebView2HistoryChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2HistoryChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2HistoryChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2HistoryChangedEventHandler*)&__ICoreWebView2HistoryChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2LostFocusEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2LostFocusEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2LostFocusEventHandler();
private:
	void *__ICoreWebView2FocusChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2FocusChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {05EA24BD-6452-4926-9014-4B82B498135D}
	operator Uwvtypelibrary::_di_ICoreWebView2FocusChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FocusChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FocusChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FocusChangedEventHandler*)&__ICoreWebView2FocusChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2MoveFocusRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventArgs args);
	
public:
	__fastcall TCoreWebView2MoveFocusRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2MoveFocusRequestedEventHandler();
private:
	void *__ICoreWebView2MoveFocusRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2MoveFocusRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {69035451-6DC7-4CB8-9BCE-B2BD70AD289F}
	operator Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2MoveFocusRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2MoveFocusRequestedEventHandler*)&__ICoreWebView2MoveFocusRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2NavigationCompletedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs args);
	
public:
	__fastcall TCoreWebView2NavigationCompletedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2NavigationCompletedEventHandler();
private:
	void *__ICoreWebView2NavigationCompletedEventHandler;	// Uwvtypelibrary::ICoreWebView2NavigationCompletedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {D33A35BF-1C49-4F98-93AB-006E0533FE1C}
	operator Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NavigationCompletedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NavigationCompletedEventHandler*)&__ICoreWebView2NavigationCompletedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2NavigationStartingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs args);
	
public:
	__fastcall TCoreWebView2NavigationStartingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2NavigationStartingEventHandler();
private:
	void *__ICoreWebView2NavigationStartingEventHandler;	// Uwvtypelibrary::ICoreWebView2NavigationStartingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {9ADBE429-F36D-432B-9DDC-F8881FBD76E3}
	operator Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NavigationStartingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NavigationStartingEventHandler*)&__ICoreWebView2NavigationStartingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2NewBrowserVersionAvailableEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2NewBrowserVersionAvailableEventHandler(const Uwvinterfaces::_di_IWVLoaderEvents aEvents);
	__fastcall virtual ~TCoreWebView2NewBrowserVersionAvailableEventHandler();
private:
	void *__ICoreWebView2NewBrowserVersionAvailableEventHandler;	// Uwvtypelibrary::ICoreWebView2NewBrowserVersionAvailableEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {F9A2976E-D34E-44FC-ADEE-81B6B57CA914}
	operator Uwvtypelibrary::_di_ICoreWebView2NewBrowserVersionAvailableEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NewBrowserVersionAvailableEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NewBrowserVersionAvailableEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NewBrowserVersionAvailableEventHandler*)&__ICoreWebView2NewBrowserVersionAvailableEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2NewWindowRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs args);
	
public:
	__fastcall TCoreWebView2NewWindowRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2NewWindowRequestedEventHandler();
private:
	void *__ICoreWebView2NewWindowRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2NewWindowRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {D4C185FE-C81C-4989-97AF-2D3FA7AB5651}
	operator Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NewWindowRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NewWindowRequestedEventHandler*)&__ICoreWebView2NewWindowRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2PermissionRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs args);
	
public:
	__fastcall TCoreWebView2PermissionRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2PermissionRequestedEventHandler();
private:
	void *__ICoreWebView2PermissionRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2PermissionRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {15E1C6A3-C72A-4DF3-91D7-D097FBEC6BFD}
	operator Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2PermissionRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2PermissionRequestedEventHandler*)&__ICoreWebView2PermissionRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ProcessFailedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs args);
	
public:
	__fastcall TCoreWebView2ProcessFailedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ProcessFailedEventHandler();
private:
	void *__ICoreWebView2ProcessFailedEventHandler;	// Uwvtypelibrary::ICoreWebView2ProcessFailedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {79E0AEA4-990B-42D9-AA1D-0FCC2E5BC7F1}
	operator Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ProcessFailedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ProcessFailedEventHandler*)&__ICoreWebView2ProcessFailedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ScriptDialogOpeningEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventArgs args);
	
public:
	__fastcall TCoreWebView2ScriptDialogOpeningEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ScriptDialogOpeningEventHandler();
private:
	void *__ICoreWebView2ScriptDialogOpeningEventHandler;	// Uwvtypelibrary::ICoreWebView2ScriptDialogOpeningEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {EF381BF9-AFA8-4E37-91C4-8AC48524BDFB}
	operator Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ScriptDialogOpeningEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ScriptDialogOpeningEventHandler*)&__ICoreWebView2ScriptDialogOpeningEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2SourceChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventArgs args);
	
public:
	__fastcall TCoreWebView2SourceChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2SourceChangedEventHandler();
private:
	void *__ICoreWebView2SourceChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2SourceChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {3C067F9F-5388-4772-8B48-79F7EF1AB37C}
	operator Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2SourceChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2SourceChangedEventHandler*)&__ICoreWebView2SourceChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2WebMessageReceivedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs args);
	
public:
	__fastcall TCoreWebView2WebMessageReceivedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2WebMessageReceivedEventHandler();
private:
	void *__ICoreWebView2WebMessageReceivedEventHandler;	// Uwvtypelibrary::ICoreWebView2WebMessageReceivedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {57213F19-00E6-49FA-8E07-898EA01ECBD2}
	operator Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2WebMessageReceivedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2WebMessageReceivedEventHandler*)&__ICoreWebView2WebMessageReceivedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2WebResourceRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventArgs args);
	
public:
	__fastcall TCoreWebView2WebResourceRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2WebResourceRequestedEventHandler();
private:
	void *__ICoreWebView2WebResourceRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2WebResourceRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {AB00B74C-15F1-4646-80E8-E76341D25D71}
	operator Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2WebResourceRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2WebResourceRequestedEventHandler*)&__ICoreWebView2WebResourceRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2WindowCloseRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2WindowCloseRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2WindowCloseRequestedEventHandler();
private:
	void *__ICoreWebView2WindowCloseRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2WindowCloseRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {5C19E9E0-092F-486B-AFFA-CA8231913039}
	operator Uwvtypelibrary::_di_ICoreWebView2WindowCloseRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2WindowCloseRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2WindowCloseRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2WindowCloseRequestedEventHandler*)&__ICoreWebView2WindowCloseRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ZoomFactorChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2ZoomFactorChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ZoomFactorChangedEventHandler();
private:
	void *__ICoreWebView2ZoomFactorChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2ZoomFactorChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {B52D71D6-C4DF-4543-A90C-64A3E60F38CB}
	operator Uwvtypelibrary::_di_ICoreWebView2ZoomFactorChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ZoomFactorChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ZoomFactorChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ZoomFactorChangedEventHandler*)&__ICoreWebView2ZoomFactorChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2CompositionController result_);
	
public:
	__fastcall TCoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler();
private:
	void *__ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler;	// Uwvtypelibrary::ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {02FAB84B-1428-4FB7-AD45-1B2E64736184}
	operator Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler*)&__ICoreWebView2CreateCoreWebView2CompositionControllerCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2CursorChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2CompositionController sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2CursorChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2CursorChangedEventHandler();
private:
	void *__ICoreWebView2CursorChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2CursorChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {9DA43CCC-26E1-4DAD-B56C-D8961C94C571}
	operator Uwvtypelibrary::_di_ICoreWebView2CursorChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2CursorChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CursorChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2CursorChangedEventHandler*)&__ICoreWebView2CursorChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2BrowserProcessExitedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FBrowserEvents;
	void *FLoaderEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs args);
	
public:
	__fastcall TCoreWebView2BrowserProcessExitedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents)/* overload */;
	__fastcall TCoreWebView2BrowserProcessExitedEventHandler(const Uwvinterfaces::_di_IWVLoaderEvents aLoaderEvents)/* overload */;
	__fastcall virtual ~TCoreWebView2BrowserProcessExitedEventHandler();
private:
	void *__ICoreWebView2BrowserProcessExitedEventHandler;	// Uwvtypelibrary::ICoreWebView2BrowserProcessExitedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {FA504257-A216-4911-A860-FE8825712861}
	operator Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2BrowserProcessExitedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2BrowserProcessExitedEventHandler*)&__ICoreWebView2BrowserProcessExitedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2RasterizationScaleChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Controller sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2RasterizationScaleChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2RasterizationScaleChangedEventHandler();
private:
	void *__ICoreWebView2RasterizationScaleChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2RasterizationScaleChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {9C98C8B1-AC53-427E-A345-3049B5524BBE}
	operator Uwvtypelibrary::_di_ICoreWebView2RasterizationScaleChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2RasterizationScaleChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2RasterizationScaleChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2RasterizationScaleChangedEventHandler*)&__ICoreWebView2RasterizationScaleChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2WebResourceResponseReceivedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventArgs args);
	
public:
	__fastcall TCoreWebView2WebResourceResponseReceivedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2WebResourceResponseReceivedEventHandler();
private:
	void *__ICoreWebView2WebResourceResponseReceivedEventHandler;	// Uwvtypelibrary::ICoreWebView2WebResourceResponseReceivedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {7DE9898A-24F5-40C3-A2DE-D4F458E69828}
	operator Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2WebResourceResponseReceivedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2WebResourceResponseReceivedEventHandler*)&__ICoreWebView2WebResourceResponseReceivedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2DOMContentLoadedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs args);
	
public:
	__fastcall TCoreWebView2DOMContentLoadedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2DOMContentLoadedEventHandler();
private:
	void *__ICoreWebView2DOMContentLoadedEventHandler;	// Uwvtypelibrary::ICoreWebView2DOMContentLoadedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {4BAC7E9C-199E-49ED-87ED-249303ACF019}
	operator Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2DOMContentLoadedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2DOMContentLoadedEventHandler*)&__ICoreWebView2DOMContentLoadedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2WebResourceResponseViewGetContentCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	int FResourceID;
	HRESULT __stdcall Invoke(HRESULT errorCode, const _di_IStream result_);
	
public:
	__fastcall TCoreWebView2WebResourceResponseViewGetContentCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, int aResourceID);
	__fastcall virtual ~TCoreWebView2WebResourceResponseViewGetContentCompletedHandler();
	__property int ResourceID = {read=FResourceID, nodefault};
private:
	void *__ICoreWebView2WebResourceResponseViewGetContentCompletedHandler;	// Uwvtypelibrary::ICoreWebView2WebResourceResponseViewGetContentCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {875738E1-9FA2-40E3-8B74-2E8972DD6FE7}
	operator Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseViewGetContentCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseViewGetContentCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2WebResourceResponseViewGetContentCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2WebResourceResponseViewGetContentCompletedHandler*)&__ICoreWebView2WebResourceResponseViewGetContentCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2GetCookiesCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2CookieList result_);
	
public:
	__fastcall TCoreWebView2GetCookiesCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2GetCookiesCompletedHandler();
private:
	void *__ICoreWebView2GetCookiesCompletedHandler;	// Uwvtypelibrary::ICoreWebView2GetCookiesCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {5A4F5069-5C15-47C3-8646-F4DE1C116670}
	operator Uwvtypelibrary::_di_ICoreWebView2GetCookiesCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2GetCookiesCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2GetCookiesCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2GetCookiesCompletedHandler*)&__ICoreWebView2GetCookiesCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2TrySuspendCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, int result_);
	
public:
	__fastcall TCoreWebView2TrySuspendCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2TrySuspendCompletedHandler();
private:
	void *__ICoreWebView2TrySuspendCompletedHandler;	// Uwvtypelibrary::ICoreWebView2TrySuspendCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {00F206A7-9D17-4605-91F6-4E8E4DE192E3}
	operator Uwvtypelibrary::_di_ICoreWebView2TrySuspendCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2TrySuspendCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2TrySuspendCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2TrySuspendCompletedHandler*)&__ICoreWebView2TrySuspendCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameCreatedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameCreatedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2FrameCreatedEventHandler();
private:
	void *__ICoreWebView2FrameCreatedEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameCreatedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {38059770-9BAA-11EB-A8B3-0242AC130003}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameCreatedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameCreatedEventHandler*)&__ICoreWebView2FrameCreatedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2DownloadStartingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventArgs args);
	
public:
	__fastcall TCoreWebView2DownloadStartingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2DownloadStartingEventHandler();
private:
	void *__ICoreWebView2DownloadStartingEventHandler;	// Uwvtypelibrary::ICoreWebView2DownloadStartingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {EFEDC989-C396-41CA-83F7-07F845A55724}
	operator Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2DownloadStartingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2DownloadStartingEventHandler*)&__ICoreWebView2DownloadStartingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ClientCertificateRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventArgs args);
	
public:
	__fastcall TCoreWebView2ClientCertificateRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ClientCertificateRequestedEventHandler();
private:
	void *__ICoreWebView2ClientCertificateRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2ClientCertificateRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {D7175BA2-BCC3-11EB-8529-0242AC130003}
	operator Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ClientCertificateRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ClientCertificateRequestedEventHandler*)&__ICoreWebView2ClientCertificateRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2PrintToPdfCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, int result_);
	
public:
	__fastcall TCoreWebView2PrintToPdfCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2PrintToPdfCompletedHandler();
private:
	void *__ICoreWebView2PrintToPdfCompletedHandler;	// Uwvtypelibrary::ICoreWebView2PrintToPdfCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {CCF1EF04-FD8E-4D5F-B2DE-0983E41B8C36}
	operator Uwvtypelibrary::_di_ICoreWebView2PrintToPdfCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2PrintToPdfCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2PrintToPdfCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2PrintToPdfCompletedHandler*)&__ICoreWebView2PrintToPdfCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2BytesReceivedChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	int FDownloadID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2BytesReceivedChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, int aDownloadID);
	__fastcall virtual ~TCoreWebView2BytesReceivedChangedEventHandler();
private:
	void *__ICoreWebView2BytesReceivedChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2BytesReceivedChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {828E8AB6-D94C-4264-9CEF-5217170D6251}
	operator Uwvtypelibrary::_di_ICoreWebView2BytesReceivedChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2BytesReceivedChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2BytesReceivedChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2BytesReceivedChangedEventHandler*)&__ICoreWebView2BytesReceivedChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2EstimatedEndTimeChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	int FDownloadID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2EstimatedEndTimeChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, int aDownloadID);
	__fastcall virtual ~TCoreWebView2EstimatedEndTimeChangedEventHandler();
private:
	void *__ICoreWebView2EstimatedEndTimeChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2EstimatedEndTimeChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {28F0D425-93FE-4E63-9F8D-2AEEC6D3BA1E}
	operator Uwvtypelibrary::_di_ICoreWebView2EstimatedEndTimeChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2EstimatedEndTimeChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EstimatedEndTimeChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2EstimatedEndTimeChangedEventHandler*)&__ICoreWebView2EstimatedEndTimeChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2StateChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	int FDownloadID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2DownloadOperation sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2StateChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, int aDownloadID);
	__fastcall virtual ~TCoreWebView2StateChangedEventHandler();
private:
	void *__ICoreWebView2StateChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2StateChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {81336594-7EDE-4BA9-BF71-ACF0A95B58DD}
	operator Uwvtypelibrary::_di_ICoreWebView2StateChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2StateChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2StateChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2StateChangedEventHandler*)&__ICoreWebView2StateChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameNameChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2FrameNameChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameNameChangedEventHandler();
private:
	void *__ICoreWebView2FrameNameChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameNameChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {435C7DC8-9BAA-11EB-A8B3-0242AC130003}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameNameChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameNameChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameNameChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameNameChangedEventHandler*)&__ICoreWebView2FrameNameChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameDestroyedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2FrameDestroyedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameDestroyedEventHandler();
private:
	void *__ICoreWebView2FrameDestroyedEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameDestroyedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {59DD7B4C-9BAA-11EB-A8B3-0242AC130003}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameDestroyedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameDestroyedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameDestroyedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameDestroyedEventHandler*)&__ICoreWebView2FrameDestroyedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2CallDevToolsProtocolMethodCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	int FID;
	HRESULT __stdcall Invoke(HRESULT errorCode, System::WideChar * result_);
	
public:
	__fastcall TCoreWebView2CallDevToolsProtocolMethodCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, int aExecutionID);
	__fastcall virtual ~TCoreWebView2CallDevToolsProtocolMethodCompletedHandler();
private:
	void *__ICoreWebView2CallDevToolsProtocolMethodCompletedHandler;	// Uwvtypelibrary::ICoreWebView2CallDevToolsProtocolMethodCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {5C4889F0-5EF6-4C5A-952C-D8F1B92D0574}
	operator Uwvtypelibrary::_di_ICoreWebView2CallDevToolsProtocolMethodCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2CallDevToolsProtocolMethodCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CallDevToolsProtocolMethodCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2CallDevToolsProtocolMethodCompletedHandler*)&__ICoreWebView2CallDevToolsProtocolMethodCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, System::WideChar * result_);
	
public:
	__fastcall TCoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler();
private:
	void *__ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler;	// Uwvtypelibrary::ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {B99369F3-9B11-47B5-BC6F-8E7895FCEA17}
	operator Uwvtypelibrary::_di_ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler*)&__ICoreWebView2AddScriptToExecuteOnDocumentCreatedCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2IsMutedChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2IsMutedChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2IsMutedChangedEventHandler();
private:
	void *__ICoreWebView2IsMutedChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2IsMutedChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {57D90347-CD0E-4952-A4A2-7483A2756F08}
	operator Uwvtypelibrary::_di_ICoreWebView2IsMutedChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2IsMutedChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2IsMutedChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2IsMutedChangedEventHandler*)&__ICoreWebView2IsMutedChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2IsDocumentPlayingAudioChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2IsDocumentPlayingAudioChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2IsDocumentPlayingAudioChangedEventHandler();
private:
	void *__ICoreWebView2IsDocumentPlayingAudioChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2IsDocumentPlayingAudioChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {5DEF109A-2F4B-49FA-B7F6-11C39E513328}
	operator Uwvtypelibrary::_di_ICoreWebView2IsDocumentPlayingAudioChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2IsDocumentPlayingAudioChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2IsDocumentPlayingAudioChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2IsDocumentPlayingAudioChangedEventHandler*)&__ICoreWebView2IsDocumentPlayingAudioChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler();
private:
	void *__ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {3117DA26-AE13-438D-BD46-EDBEB2C4CE81}
	operator Uwvtypelibrary::_di_ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler*)&__ICoreWebView2IsDefaultDownloadDialogOpenChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ProcessInfosChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FBrowserEvents;
	void *FLoaderEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Environment sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2ProcessInfosChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aBrowserEvents)/* overload */;
	__fastcall TCoreWebView2ProcessInfosChangedEventHandler(const Uwvinterfaces::_di_IWVLoaderEvents aLoaderEvents)/* overload */;
	__fastcall virtual ~TCoreWebView2ProcessInfosChangedEventHandler();
private:
	void *__ICoreWebView2ProcessInfosChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2ProcessInfosChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {F4AF0C39-44B9-40E9-8B11-0484CFB9E0A1}
	operator Uwvtypelibrary::_di_ICoreWebView2ProcessInfosChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ProcessInfosChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ProcessInfosChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ProcessInfosChangedEventHandler*)&__ICoreWebView2ProcessInfosChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameNavigationCompletedEventHandler2 : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameNavigationCompletedEventHandler2(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameNavigationCompletedEventHandler2();
private:
	void *__ICoreWebView2FrameNavigationCompletedEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameNavigationCompletedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {609302AD-0E36-4F9A-A210-6A45272842A9}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameNavigationCompletedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameNavigationCompletedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameNavigationCompletedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameNavigationCompletedEventHandler*)&__ICoreWebView2FrameNavigationCompletedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameNavigationStartingEventHandler2 : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameNavigationStartingEventHandler2(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameNavigationStartingEventHandler2();
private:
	void *__ICoreWebView2FrameNavigationStartingEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameNavigationStartingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {E79908BF-2D5D-4968-83DB-263FEA2C1DA3}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameNavigationStartingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameNavigationStartingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameNavigationStartingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameNavigationStartingEventHandler*)&__ICoreWebView2FrameNavigationStartingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameContentLoadingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameContentLoadingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameContentLoadingEventHandler();
private:
	void *__ICoreWebView2FrameContentLoadingEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameContentLoadingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {0D6156F2-D332-49A7-9E03-7D8F2FEEEE54}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameContentLoadingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameContentLoadingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameContentLoadingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameContentLoadingEventHandler*)&__ICoreWebView2FrameContentLoadingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameDOMContentLoadedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameDOMContentLoadedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameDOMContentLoadedEventHandler();
private:
	void *__ICoreWebView2FrameDOMContentLoadedEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameDOMContentLoadedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {38D9520D-340F-4D1E-A775-43FCE9753683}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameDOMContentLoadedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameDOMContentLoadedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameDOMContentLoadedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameDOMContentLoadedEventHandler*)&__ICoreWebView2FrameDOMContentLoadedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameWebMessageReceivedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameWebMessageReceivedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameWebMessageReceivedEventHandler();
private:
	void *__ICoreWebView2FrameWebMessageReceivedEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameWebMessageReceivedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {E371E005-6D1D-4517-934B-A8F1629C62A5}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameWebMessageReceivedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameWebMessageReceivedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameWebMessageReceivedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameWebMessageReceivedEventHandler*)&__ICoreWebView2FrameWebMessageReceivedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2BasicAuthenticationRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventArgs args);
	
public:
	__fastcall TCoreWebView2BasicAuthenticationRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2BasicAuthenticationRequestedEventHandler();
private:
	void *__ICoreWebView2BasicAuthenticationRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2BasicAuthenticationRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {58B4D6C2-18D4-497E-B39B-9A96533FA278}
	operator Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2BasicAuthenticationRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2BasicAuthenticationRequestedEventHandler*)&__ICoreWebView2BasicAuthenticationRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ContextMenuRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventArgs args);
	
public:
	__fastcall TCoreWebView2ContextMenuRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ContextMenuRequestedEventHandler();
private:
	void *__ICoreWebView2ContextMenuRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2ContextMenuRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {04D3FE1D-AB87-42FB-A898-DA241D35B63C}
	operator Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ContextMenuRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ContextMenuRequestedEventHandler*)&__ICoreWebView2ContextMenuRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2CustomItemSelectedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2ContextMenuItem sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2CustomItemSelectedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2CustomItemSelectedEventHandler();
private:
	void *__ICoreWebView2CustomItemSelectedEventHandler;	// Uwvtypelibrary::ICoreWebView2CustomItemSelectedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {49E1D0BC-FE9E-4481-B7C2-32324AA21998}
	operator Uwvtypelibrary::_di_ICoreWebView2CustomItemSelectedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2CustomItemSelectedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2CustomItemSelectedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2CustomItemSelectedEventHandler*)&__ICoreWebView2CustomItemSelectedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2StatusBarTextChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2StatusBarTextChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2StatusBarTextChangedEventHandler();
private:
	void *__ICoreWebView2StatusBarTextChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2StatusBarTextChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {A5E3B0D0-10DF-4156-BFAD-3B43867ACAC6}
	operator Uwvtypelibrary::_di_ICoreWebView2StatusBarTextChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2StatusBarTextChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2StatusBarTextChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2StatusBarTextChangedEventHandler*)&__ICoreWebView2StatusBarTextChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FramePermissionRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs2 args);
	
public:
	__fastcall TCoreWebView2FramePermissionRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FramePermissionRequestedEventHandler();
private:
	void *__ICoreWebView2FramePermissionRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2FramePermissionRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {845D0EDD-8BD8-429B-9915-4821789F23E9}
	operator Uwvtypelibrary::_di_ICoreWebView2FramePermissionRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FramePermissionRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FramePermissionRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FramePermissionRequestedEventHandler*)&__ICoreWebView2FramePermissionRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ClearBrowsingDataCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode);
	
public:
	__fastcall TCoreWebView2ClearBrowsingDataCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ClearBrowsingDataCompletedHandler();
private:
	void *__ICoreWebView2ClearBrowsingDataCompletedHandler;	// Uwvtypelibrary::ICoreWebView2ClearBrowsingDataCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {E9710A06-1D1D-49B2-8234-226F35846AE5}
	operator Uwvtypelibrary::_di_ICoreWebView2ClearBrowsingDataCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ClearBrowsingDataCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ClearBrowsingDataCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ClearBrowsingDataCompletedHandler*)&__ICoreWebView2ClearBrowsingDataCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ClearServerCertificateErrorActionsCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode);
	
public:
	__fastcall TCoreWebView2ClearServerCertificateErrorActionsCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ClearServerCertificateErrorActionsCompletedHandler();
private:
	void *__ICoreWebView2ClearServerCertificateErrorActionsCompletedHandler;	// Uwvtypelibrary::ICoreWebView2ClearServerCertificateErrorActionsCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {3B40AAC6-ACFE-4FFD-8211-F607B96E2D5B}
	operator Uwvtypelibrary::_di_ICoreWebView2ClearServerCertificateErrorActionsCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ClearServerCertificateErrorActionsCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ClearServerCertificateErrorActionsCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ClearServerCertificateErrorActionsCompletedHandler*)&__ICoreWebView2ClearServerCertificateErrorActionsCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ServerCertificateErrorDetectedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventArgs args);
	
public:
	__fastcall TCoreWebView2ServerCertificateErrorDetectedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ServerCertificateErrorDetectedEventHandler();
private:
	void *__ICoreWebView2ServerCertificateErrorDetectedEventHandler;	// Uwvtypelibrary::ICoreWebView2ServerCertificateErrorDetectedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {969B3A26-D85E-4795-8199-FEF57344DA22}
	operator Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ServerCertificateErrorDetectedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ServerCertificateErrorDetectedEventHandler*)&__ICoreWebView2ServerCertificateErrorDetectedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FaviconChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2FaviconChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2FaviconChangedEventHandler();
private:
	void *__ICoreWebView2FaviconChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2FaviconChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {2913DA94-833D-4DE0-8DCA-900FC524A1A4}
	operator Uwvtypelibrary::_di_ICoreWebView2FaviconChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FaviconChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FaviconChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FaviconChangedEventHandler*)&__ICoreWebView2FaviconChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2GetFaviconCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const _di_IStream result_);
	
public:
	__fastcall TCoreWebView2GetFaviconCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2GetFaviconCompletedHandler();
private:
	void *__ICoreWebView2GetFaviconCompletedHandler;	// Uwvtypelibrary::ICoreWebView2GetFaviconCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {A2508329-7DA8-49D7-8C05-FA125E4AEE8D}
	operator Uwvtypelibrary::_di_ICoreWebView2GetFaviconCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2GetFaviconCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2GetFaviconCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2GetFaviconCompletedHandler*)&__ICoreWebView2GetFaviconCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2PrintCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, Uwvtypelibrary::COREWEBVIEW2_PRINT_STATUS result_);
	
public:
	__fastcall TCoreWebView2PrintCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2PrintCompletedHandler();
private:
	void *__ICoreWebView2PrintCompletedHandler;	// Uwvtypelibrary::ICoreWebView2PrintCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {8FD80075-ED08-42DB-8570-F5D14977461E}
	operator Uwvtypelibrary::_di_ICoreWebView2PrintCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2PrintCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2PrintCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2PrintCompletedHandler*)&__ICoreWebView2PrintCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2PrintToPdfStreamCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const _di_IStream result_);
	
public:
	__fastcall TCoreWebView2PrintToPdfStreamCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2PrintToPdfStreamCompletedHandler();
private:
	void *__ICoreWebView2PrintToPdfStreamCompletedHandler;	// Uwvtypelibrary::ICoreWebView2PrintToPdfStreamCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {4C9F8229-8F93-444F-A711-2C0DFD6359D5}
	operator Uwvtypelibrary::_di_ICoreWebView2PrintToPdfStreamCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2PrintToPdfStreamCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2PrintToPdfStreamCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2PrintToPdfStreamCompletedHandler*)&__ICoreWebView2PrintToPdfStreamCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2GetNonDefaultPermissionSettingsCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2PermissionSettingCollectionView result_);
	
public:
	__fastcall TCoreWebView2GetNonDefaultPermissionSettingsCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2GetNonDefaultPermissionSettingsCompletedHandler();
private:
	void *__ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler;	// Uwvtypelibrary::ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {38274481-A15C-4563-94CF-990EDC9AEB95}
	operator Uwvtypelibrary::_di_ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler*)&__ICoreWebView2GetNonDefaultPermissionSettingsCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2SetPermissionStateCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode);
	
public:
	__fastcall TCoreWebView2SetPermissionStateCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2SetPermissionStateCompletedHandler();
private:
	void *__ICoreWebView2SetPermissionStateCompletedHandler;	// Uwvtypelibrary::ICoreWebView2SetPermissionStateCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {FC77FB30-9C9E-4076-B8C7-7644A703CA1B}
	operator Uwvtypelibrary::_di_ICoreWebView2SetPermissionStateCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2SetPermissionStateCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2SetPermissionStateCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2SetPermissionStateCompletedHandler*)&__ICoreWebView2SetPermissionStateCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2LaunchingExternalUriSchemeEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventArgs args);
	
public:
	__fastcall TCoreWebView2LaunchingExternalUriSchemeEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2LaunchingExternalUriSchemeEventHandler();
private:
	void *__ICoreWebView2LaunchingExternalUriSchemeEventHandler;	// Uwvtypelibrary::ICoreWebView2LaunchingExternalUriSchemeEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {74F712E0-8165-43A9-A13F-0CCE597E75DF}
	operator Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2LaunchingExternalUriSchemeEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2LaunchingExternalUriSchemeEventHandler*)&__ICoreWebView2LaunchingExternalUriSchemeEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2GetProcessExtendedInfosCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2ProcessExtendedInfoCollection result_);
	
public:
	__fastcall TCoreWebView2GetProcessExtendedInfosCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2GetProcessExtendedInfosCompletedHandler();
private:
	void *__ICoreWebView2GetProcessExtendedInfosCompletedHandler;	// Uwvtypelibrary::ICoreWebView2GetProcessExtendedInfosCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {F45E55AA-3BC2-11EE-BE56-0242AC120002}
	operator Uwvtypelibrary::_di_ICoreWebView2GetProcessExtendedInfosCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2GetProcessExtendedInfosCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2GetProcessExtendedInfosCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2GetProcessExtendedInfosCompletedHandler*)&__ICoreWebView2GetProcessExtendedInfosCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2BrowserExtensionRemoveCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	Uwvtypes::wvstring FID;
	HRESULT __stdcall Invoke(HRESULT errorCode);
	
public:
	__fastcall TCoreWebView2BrowserExtensionRemoveCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, const Uwvtypes::wvstring aExtensionID);
	__fastcall virtual ~TCoreWebView2BrowserExtensionRemoveCompletedHandler();
private:
	void *__ICoreWebView2BrowserExtensionRemoveCompletedHandler;	// Uwvtypelibrary::ICoreWebView2BrowserExtensionRemoveCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {8E41909A-9B18-4BB1-8CDF-930F467A50BE}
	operator Uwvtypelibrary::_di_ICoreWebView2BrowserExtensionRemoveCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2BrowserExtensionRemoveCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2BrowserExtensionRemoveCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2BrowserExtensionRemoveCompletedHandler*)&__ICoreWebView2BrowserExtensionRemoveCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2BrowserExtensionEnableCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	Uwvtypes::wvstring FID;
	HRESULT __stdcall Invoke(HRESULT errorCode);
	
public:
	__fastcall TCoreWebView2BrowserExtensionEnableCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, const Uwvtypes::wvstring aExtensionID);
	__fastcall virtual ~TCoreWebView2BrowserExtensionEnableCompletedHandler();
private:
	void *__ICoreWebView2BrowserExtensionEnableCompletedHandler;	// Uwvtypelibrary::ICoreWebView2BrowserExtensionEnableCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {30C186CE-7FAD-421F-A3BC-A8EAF071DDB8}
	operator Uwvtypelibrary::_di_ICoreWebView2BrowserExtensionEnableCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2BrowserExtensionEnableCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2BrowserExtensionEnableCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2BrowserExtensionEnableCompletedHandler*)&__ICoreWebView2BrowserExtensionEnableCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ProfileAddBrowserExtensionCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2BrowserExtension result_);
	
public:
	__fastcall TCoreWebView2ProfileAddBrowserExtensionCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ProfileAddBrowserExtensionCompletedHandler();
private:
	void *__ICoreWebView2ProfileAddBrowserExtensionCompletedHandler;	// Uwvtypelibrary::ICoreWebView2ProfileAddBrowserExtensionCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {DF1AAB27-82B9-4AB6-AAE8-017A49398C14}
	operator Uwvtypelibrary::_di_ICoreWebView2ProfileAddBrowserExtensionCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ProfileAddBrowserExtensionCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ProfileAddBrowserExtensionCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ProfileAddBrowserExtensionCompletedHandler*)&__ICoreWebView2ProfileAddBrowserExtensionCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ProfileGetBrowserExtensionsCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2BrowserExtensionList result_);
	
public:
	__fastcall TCoreWebView2ProfileGetBrowserExtensionsCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ProfileGetBrowserExtensionsCompletedHandler();
private:
	void *__ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler;	// Uwvtypelibrary::ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {FCE16A1C-F107-4601-8B75-FC4940AE25D0}
	operator Uwvtypelibrary::_di_ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler*)&__ICoreWebView2ProfileGetBrowserExtensionsCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ProfileDeletedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Profile sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2ProfileDeletedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ProfileDeletedEventHandler();
private:
	void *__ICoreWebView2ProfileDeletedEventHandler;	// Uwvtypelibrary::ICoreWebView2ProfileDeletedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {DF35055D-772E-4DBE-B743-5FBF74A2B258}
	operator Uwvtypelibrary::_di_ICoreWebView2ProfileDeletedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ProfileDeletedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ProfileDeletedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ProfileDeletedEventHandler*)&__ICoreWebView2ProfileDeletedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ExecuteScriptWithResultCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	int FID;
	HRESULT __stdcall Invoke(HRESULT errorCode, const Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptResult result_);
	
public:
	__fastcall TCoreWebView2ExecuteScriptWithResultCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, int aExecutionID);
	__fastcall virtual ~TCoreWebView2ExecuteScriptWithResultCompletedHandler();
private:
	void *__ICoreWebView2ExecuteScriptWithResultCompletedHandler;	// Uwvtypelibrary::ICoreWebView2ExecuteScriptWithResultCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {1BB5317B-8238-4C67-A7FF-BAF6558F289D}
	operator Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptWithResultCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ExecuteScriptWithResultCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ExecuteScriptWithResultCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ExecuteScriptWithResultCompletedHandler*)&__ICoreWebView2ExecuteScriptWithResultCompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2NonClientRegionChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2CompositionController sender, const Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventArgs args);
	
public:
	__fastcall TCoreWebView2NonClientRegionChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2NonClientRegionChangedEventHandler();
private:
	void *__ICoreWebView2NonClientRegionChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2NonClientRegionChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {4A794E66-AA6C-46BD-93A3-382196837680}
	operator Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NonClientRegionChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NonClientRegionChangedEventHandler*)&__ICoreWebView2NonClientRegionChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2NotificationReceivedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventArgs args);
	
public:
	__fastcall TCoreWebView2NotificationReceivedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2NotificationReceivedEventHandler();
private:
	void *__ICoreWebView2NotificationReceivedEventHandler;	// Uwvtypelibrary::ICoreWebView2NotificationReceivedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {89C5D598-8788-423B-BE97-E6E01C0F9EE3}
	operator Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NotificationReceivedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NotificationReceivedEventHandler*)&__ICoreWebView2NotificationReceivedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2NotificationCloseRequestedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Notification sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2NotificationCloseRequestedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2NotificationCloseRequestedEventHandler();
private:
	void *__ICoreWebView2NotificationCloseRequestedEventHandler;	// Uwvtypelibrary::ICoreWebView2NotificationCloseRequestedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {47C32D23-1E94-4733-85F1-D9BF4ACD0974}
	operator Uwvtypelibrary::_di_ICoreWebView2NotificationCloseRequestedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2NotificationCloseRequestedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2NotificationCloseRequestedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2NotificationCloseRequestedEventHandler*)&__ICoreWebView2NotificationCloseRequestedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2SaveAsUIShowingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventArgs args);
	
public:
	__fastcall TCoreWebView2SaveAsUIShowingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2SaveAsUIShowingEventHandler();
private:
	void *__ICoreWebView2SaveAsUIShowingEventHandler;	// Uwvtypelibrary::ICoreWebView2SaveAsUIShowingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {6BAA177E-3A2E-5CCF-9A13-FAD676CD0522}
	operator Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2SaveAsUIShowingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2SaveAsUIShowingEventHandler*)&__ICoreWebView2SaveAsUIShowingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ShowSaveAsUICompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode, Uwvtypelibrary::COREWEBVIEW2_SAVE_AS_UI_RESULT result_);
	
public:
	__fastcall TCoreWebView2ShowSaveAsUICompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ShowSaveAsUICompletedHandler();
private:
	void *__ICoreWebView2ShowSaveAsUICompletedHandler;	// Uwvtypelibrary::ICoreWebView2ShowSaveAsUICompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {E24B07E3-8169-5C34-994A-7F6478946A3C}
	operator Uwvtypelibrary::_di_ICoreWebView2ShowSaveAsUICompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ShowSaveAsUICompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ShowSaveAsUICompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ShowSaveAsUICompletedHandler*)&__ICoreWebView2ShowSaveAsUICompletedHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2SaveFileSecurityCheckStartingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventArgs args);
	
public:
	__fastcall TCoreWebView2SaveFileSecurityCheckStartingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2SaveFileSecurityCheckStartingEventHandler();
private:
	void *__ICoreWebView2SaveFileSecurityCheckStartingEventHandler;	// Uwvtypelibrary::ICoreWebView2SaveFileSecurityCheckStartingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {7899576C-19E3-57C8-B7D1-55808292DE57}
	operator Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2SaveFileSecurityCheckStartingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2SaveFileSecurityCheckStartingEventHandler*)&__ICoreWebView2SaveFileSecurityCheckStartingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2ScreenCaptureStartingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2 sender, const Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs args);
	
public:
	__fastcall TCoreWebView2ScreenCaptureStartingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2ScreenCaptureStartingEventHandler();
private:
	void *__ICoreWebView2ScreenCaptureStartingEventHandler;	// Uwvtypelibrary::ICoreWebView2ScreenCaptureStartingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {E24FF05A-1DB5-59D9-89F3-3C864268DB4A}
	operator Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2ScreenCaptureStartingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2ScreenCaptureStartingEventHandler*)&__ICoreWebView2ScreenCaptureStartingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameScreenCaptureStartingEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameScreenCaptureStartingEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameScreenCaptureStartingEventHandler();
private:
	void *__ICoreWebView2FrameScreenCaptureStartingEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameScreenCaptureStartingEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {A6C1D8AD-BB80-59C5-895B-FBA1698B9309}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameScreenCaptureStartingEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameScreenCaptureStartingEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameScreenCaptureStartingEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameScreenCaptureStartingEventHandler*)&__ICoreWebView2FrameScreenCaptureStartingEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FrameChildFrameCreatedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	unsigned FFrameID;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Frame sender, const Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs args);
	
public:
	__fastcall TCoreWebView2FrameChildFrameCreatedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents, unsigned aFrameID);
	__fastcall virtual ~TCoreWebView2FrameChildFrameCreatedEventHandler();
private:
	void *__ICoreWebView2FrameChildFrameCreatedEventHandler;	// Uwvtypelibrary::ICoreWebView2FrameChildFrameCreatedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {569E40E7-46B7-563D-83AE-1073155664D7}
	operator Uwvtypelibrary::_di_ICoreWebView2FrameChildFrameCreatedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FrameChildFrameCreatedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FrameChildFrameCreatedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FrameChildFrameCreatedEventHandler*)&__ICoreWebView2FrameChildFrameCreatedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FindActiveMatchIndexChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Find sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2FindActiveMatchIndexChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2FindActiveMatchIndexChangedEventHandler();
private:
	void *__ICoreWebView2FindActiveMatchIndexChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2FindActiveMatchIndexChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {0054F514-9A8E-5876-AED5-30B37F8C86A5}
	operator Uwvtypelibrary::_di_ICoreWebView2FindActiveMatchIndexChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FindActiveMatchIndexChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FindActiveMatchIndexChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FindActiveMatchIndexChangedEventHandler*)&__ICoreWebView2FindActiveMatchIndexChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FindMatchCountChangedEventHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(const Uwvtypelibrary::_di_ICoreWebView2Find sender, const System::_di_IInterface args);
	
public:
	__fastcall TCoreWebView2FindMatchCountChangedEventHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2FindMatchCountChangedEventHandler();
private:
	void *__ICoreWebView2FindMatchCountChangedEventHandler;	// Uwvtypelibrary::ICoreWebView2FindMatchCountChangedEventHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {DA0D6827-4254-5B10-A6D9-412076AFC9F3}
	operator Uwvtypelibrary::_di_ICoreWebView2FindMatchCountChangedEventHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FindMatchCountChangedEventHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FindMatchCountChangedEventHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FindMatchCountChangedEventHandler*)&__ICoreWebView2FindMatchCountChangedEventHandler; }
	#endif
	
};


class PASCALIMPLEMENTATION TCoreWebView2FindStartCompletedHandler : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	void *FEvents;
	HRESULT __stdcall Invoke(HRESULT errorCode);
	
public:
	__fastcall TCoreWebView2FindStartCompletedHandler(const Uwvinterfaces::_di_IWVBrowserEvents aEvents);
	__fastcall virtual ~TCoreWebView2FindStartCompletedHandler();
private:
	void *__ICoreWebView2FindStartCompletedHandler;	// Uwvtypelibrary::ICoreWebView2FindStartCompletedHandler 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {6A90ECAF-44B0-5BD9-8F07-1967E17BE9FB}
	operator Uwvtypelibrary::_di_ICoreWebView2FindStartCompletedHandler()
	{
		Uwvtypelibrary::_di_ICoreWebView2FindStartCompletedHandler intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2FindStartCompletedHandler*(void) { return (Uwvtypelibrary::ICoreWebView2FindStartCompletedHandler*)&__ICoreWebView2FindStartCompletedHandler; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2delegates */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2DELEGATES)
using namespace Uwvcorewebview2delegates;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2delegatesHPP
