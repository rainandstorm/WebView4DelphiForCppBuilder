﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2WebResourceResponseView.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2webresourceresponseviewHPP
#define Uwvcorewebview2webresourceresponseviewHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2webresourceresponseview
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2WebResourceResponseView;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2WebResourceResponseView : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseView FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypelibrary::_di_ICoreWebView2HttpResponseHeaders __fastcall GetHeaders();
	int __fastcall GetStatusCode();
	Uwvtypes::wvstring __fastcall GetReasonPhrase();
	
public:
	__fastcall TCoreWebView2WebResourceResponseView(const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseView aBaseIntf);
	__fastcall virtual ~TCoreWebView2WebResourceResponseView();
	bool __fastcall GetContent(const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseViewGetContentCompletedHandler aHandler);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseView BaseIntf = {read=FBaseIntf};
	__property int StatusCode = {read=GetStatusCode, nodefault};
	__property Uwvtypes::wvstring ReasonPhrase = {read=GetReasonPhrase};
	__property Uwvtypelibrary::_di_ICoreWebView2HttpResponseHeaders Headers = {read=GetHeaders};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2webresourceresponseview */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2WEBRESOURCERESPONSEVIEW)
using namespace Uwvcorewebview2webresourceresponseview;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2webresourceresponseviewHPP
