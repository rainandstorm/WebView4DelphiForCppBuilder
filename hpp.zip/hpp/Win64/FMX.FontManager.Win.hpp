﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.FontManager.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Fontmanager_WinHPP
#define Fmx_Fontmanager_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.SysUtils.hpp>
#include <System.UITypes.hpp>
#include <System.Generics.Collections.hpp>
#include <Winapi.D2D1.hpp>
#include <Winapi.GDIPOBJ.hpp>
#include <Winapi.GDIPAPI.hpp>
#include <FMX.FontManager.hpp>
#include <System.Generics.Defaults.hpp>
#include <System.Types.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Fontmanager
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
__interface DELPHIINTERFACE IFontCollectionFactoryDW;
typedef System::DelphiInterface<IFontCollectionFactoryDW> _di_IFontCollectionFactoryDW;
__interface DELPHIINTERFACE IFontCollectionFactoryGDIP;
typedef System::DelphiInterface<IFontCollectionFactoryGDIP> _di_IFontCollectionFactoryGDIP;
class DELPHICLASS TWinFontManager;
//-- type declarations -------------------------------------------------------
__interface  INTERFACE_UUID("{6FBF9EE9-433C-4B7D-B318-CC4C74FB6725}") IFontCollectionFactoryDW  : public System::IInterface 
{
	virtual Winapi::D2d1::_di_IDWriteFontCollection __fastcall CreateCustomFontCollection() = 0 ;
};

__interface  INTERFACE_UUID("{2D230494-F32E-4946-9D07-64A1AB9F8F7C}") IFontCollectionFactoryGDIP  : public System::IInterface 
{
	virtual Winapi::Gdipobj::TGPPrivateFontCollection* __fastcall GetCustomFontCollection() = 0 ;
};

class PASCALIMPLEMENTATION TWinFontManager : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
private:
	System::Generics::Collections::TList__1<Fmx::Fontmanager::TFontInfo>* FFontInfos;
	System::Generics::Collections::TDictionary__2<System::Uitypes::TFontName,System::Uitypes::TFontName>* FFontFamilyNames;
	bool FWasDWLoadersRegistered;
	Winapi::D2d1::_di_IDWriteFontCollectionLoader FFontCollectionDWLoader;
	Winapi::D2d1::_di_IDWriteFontFileLoader FFontFileLoader;
	Winapi::Gdipobj::TGPPrivateFontCollection* FFontCollectionGDIP;
	Winapi::Gdipobj::TGPPrivateFontCollection* __fastcall GetCustomGDIPFontCollection();
	void __fastcall RefreshFontFamilyNames();
	Winapi::Gdipobj::TGPPrivateFontCollection* __fastcall GetFontCollectionGDIP();
	Winapi::D2d1::_di_IDWriteFontCollection __fastcall CreateCustomDWFontCollection();
	void __fastcall RegisterLoadersIfRequired();
	
public:
	__fastcall TWinFontManager();
	__fastcall virtual ~TWinFontManager();
	bool __fastcall AddCustomFontFromFile(const System::Sysutils::TFileName AFileName);
	bool __fastcall AddCustomFontFromResource(const System::UnicodeString AResourceName);
	bool __fastcall AddCustomFontFromStream(System::Classes::TStream* const AStream);
	bool __fastcall HasCustomFont(const System::Uitypes::TFontName AFontFamily);
	bool __fastcall HasCustomFonts();
	Fmx::Fontmanager::TFontInfo __fastcall GetCustomFontInfo(const int AIndex);
	int __fastcall GetCustomFontInfoCount();
	__property Winapi::Gdipobj::TGPPrivateFontCollection* FontCollectionGDIP = {read=GetFontCollectionGDIP};
private:
	void *__IFontCollectionFactoryGDIP;	// IFontCollectionFactoryGDIP 
	void *__IFontCollectionFactoryDW;	// IFontCollectionFactoryDW 
	void *__IFMXFontManagerService;	// Fmx::Fontmanager::IFMXFontManagerService 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {2D230494-F32E-4946-9D07-64A1AB9F8F7C}
	operator _di_IFontCollectionFactoryGDIP()
	{
		_di_IFontCollectionFactoryGDIP intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator IFontCollectionFactoryGDIP*(void) { return (IFontCollectionFactoryGDIP*)&__IFontCollectionFactoryGDIP; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {6FBF9EE9-433C-4B7D-B318-CC4C74FB6725}
	operator _di_IFontCollectionFactoryDW()
	{
		_di_IFontCollectionFactoryDW intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator IFontCollectionFactoryDW*(void) { return (IFontCollectionFactoryDW*)&__IFontCollectionFactoryDW; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {2F494059-AFEF-4652-93BB-8DE03F41D822}
	operator Fmx::Fontmanager::_di_IFMXFontManagerService()
	{
		Fmx::Fontmanager::_di_IFMXFontManagerService intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Fontmanager::IFMXFontManagerService*(void) { return (Fmx::Fontmanager::IFMXFontManagerService*)&__IFMXFontManagerService; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Win */
}	/* namespace Fontmanager */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_FONTMANAGER_WIN)
using namespace Fmx::Fontmanager::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_FONTMANAGER)
using namespace Fmx::Fontmanager;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Fontmanager_WinHPP
