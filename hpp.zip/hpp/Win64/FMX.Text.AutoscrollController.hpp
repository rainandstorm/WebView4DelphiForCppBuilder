﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.AutoscrollController.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_AutoscrollcontrollerHPP
#define Fmx_Text_AutoscrollcontrollerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <FMX.Types.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Autoscrollcontroller
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TAutoscrollController;
//-- type declarations -------------------------------------------------------
enum class DECLSPEC_DENUM TAutoscrollDirection : unsigned char { LeftToRight, RightToLeft, TopToBottom, BottomToTop, LeftTopToRightBottom, LeftBottomToRightTop, RightTopToLeftBottom, RightBottomToLeftTop };

typedef void __fastcall (__closure *TOnAutoScrollEvent)(const TAutoscrollDirection ADirection, bool &AStop);

class PASCALIMPLEMENTATION TAutoscrollController : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	static _DELPHI_CONST System::Int8 DefaultScrollStepInterval = System::Int8(0x64);
	
	static _DELPHI_CONST System::Int8 DefaultStartScrollDelay = System::Int8(0x64);
	
	
private:
	Fmx::Types::TTimer* FStartAutoScrollTimer;
	Fmx::Types::TTimer* FAutoScrollTimer;
	TAutoscrollDirection FScrollDirection;
	TOnAutoScrollEvent FOnScroll;
	void __fastcall SetStartDelay(const int Value);
	int __fastcall GetStartDelay();
	int __fastcall GetScrollInterval();
	void __fastcall SetScrollInterval(const int Value);
	void __fastcall StartAutoScrollHandler(System::TObject* Sender);
	void __fastcall AutoScrollHandler(System::TObject* Sender);
	
protected:
	virtual void __fastcall DoScroll(bool &AStop);
	
public:
	__fastcall TAutoscrollController();
	__fastcall virtual ~TAutoscrollController();
	void __fastcall Start(const TAutoscrollDirection ADirection);
	void __fastcall Stop();
	__property int StartDelay = {read=GetStartDelay, write=SetStartDelay, nodefault};
	__property int ScrollInterval = {read=GetScrollInterval, write=SetScrollInterval, nodefault};
	__property TAutoscrollDirection ScrollDirection = {read=FScrollDirection, nodefault};
	__property TOnAutoScrollEvent OnScroll = {read=FOnScroll, write=FOnScroll};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Autoscrollcontroller */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_AUTOSCROLLCONTROLLER)
using namespace Fmx::Text::Autoscrollcontroller;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_AutoscrollcontrollerHPP
