﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.SpellingManager.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_SpellingmanagerHPP
#define Fmx_Text_SpellingmanagerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Generics.Collections.hpp>
#include <System.Types.hpp>
#include <FMX.Menus.hpp>
#include <FMX.Text.LinesLayout.hpp>
#include <FMX.Text.hpp>
#include <FMX.Graphics.hpp>
#include <FMX.TextLayout.hpp>
#include <FMX.SpellChecker.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Spellingmanager
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TSpellingWord;
class DELPHICLASS TSpellingManager;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TSpellingWord : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Fmx::Text::TCaretPosition FPosition;
	int FLength;
	Fmx::Graphics::TRegion FBounds;
	System::UnicodeString FWord;
	
public:
	__fastcall TSpellingWord(const Fmx::Text::TCaretPosition &APosition, const System::UnicodeString AWord, const Fmx::Graphics::TRegion ABounds);
	bool __fastcall HasBounds();
	bool __fastcall PosAtCurrentPos(const Fmx::Text::TCaretPosition &APosition);
	void __fastcall InvalidateBounds();
	Fmx::Textlayout::TTextRange __fastcall TextRange();
	__property Fmx::Text::TCaretPosition Position = {read=FPosition, write=FPosition};
	__property int Length = {read=FLength, write=FLength, nodefault};
	__property Fmx::Graphics::TRegion Bounds = {read=FBounds, write=FBounds};
	__property System::UnicodeString Word = {read=FWord};
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TSpellingWord() { }
	
};


typedef void __fastcall (__closure *TOnReplaceWordEvent)(TSpellingWord* const ASpellingWord, const System::UnicodeString ASuggestion);

class PASCALIMPLEMENTATION TSpellingManager : public System::TNoRefCountObject
{
	typedef System::TNoRefCountObject inherited;
	
private:
	Fmx::Text::_di_ITextLinesSource FLines;
	Fmx::Spellchecker::_di_IFMXSpellCheckerService FSpellService;
	System::Generics::Collections::TObjectList__1<TSpellingWord*>* FSpellingWords;
	System::Generics::Collections::TList__1<Fmx::Menus::TMenuItem*>* FMenuItems;
	System::Types::TRectF FHighlightRect;
	Fmx::Graphics::TBrush* FFill;
	Fmx::Graphics::TStrokeBrush* FUnderlineStroke;
	TOnReplaceWordEvent FOnReplaceWord;
	void __fastcall SetFill(Fmx::Graphics::TBrush* const Value);
	void __fastcall SetStroke(Fmx::Graphics::TStrokeBrush* const Value);
	void __fastcall ClearMenuItems();
	void __fastcall SpellFixContextMenuHandler(System::TObject* Sender);
	
protected:
	virtual void __fastcall DoReplaceWord(TSpellingWord* const ASpellingWord, const System::UnicodeString ASuggestion);
	bool __fastcall FindSpellingWordByCaret(const Fmx::Text::TCaretPosition &ACaretPosition, /* out */ int &AIndex);
	
public:
	__fastcall TSpellingManager(const Fmx::Text::_di_ITextLinesSource ALines);
	__fastcall virtual ~TSpellingManager();
	void __fastcall Spell(Fmx::Text::TCaretPosition &ACaretPosition, const System::UnicodeString AWord);
	bool __fastcall IsWordWrong(const Fmx::Text::TCaretPosition &ACaretPosition);
	void __fastcall FindSpellingErrorsInLines();
	void __fastcall FindSpellingErrorsInLine(const int ALineIndex);
	void __fastcall RemoveSpellingErrorsForLine(const int ALineIndex);
	System::DynamicArray<System::UnicodeString> __fastcall GetListOfPrepositions(const Fmx::Text::TCaretPosition &ACaretPosition);
	void __fastcall AddSuggestionsToPopupMenu(Fmx::Menus::TPopupMenu* const APopupMenu, const Fmx::Text::TCaretPosition &ACaretPosition);
	void __fastcall Reset();
	void __fastcall ResetBounds();
	void __fastcall HighlightSpell(Fmx::Text::Lineslayout::TLinesLayout* const ALines, const Fmx::Text::TCaretPosition &ACaretPosition);
	void __fastcall HideHighlightSpell();
	void __fastcall UpdateHighlightRect(Fmx::Text::Lineslayout::TLinesLayout* const ALines, const System::Types::TSizeF &AViewportSize, const System::Types::TPointF &AOffset);
	void __fastcall DrawHighlightSpellingWords(Fmx::Text::Lineslayout::TLinesLayout* const ALine, const System::Types::TSizeF &AViewportSize, Fmx::Graphics::TCanvas* const ACanvas, const float AOpacity);
	__property Fmx::Graphics::TBrush* Fill = {read=FFill, write=SetFill};
	__property Fmx::Graphics::TStrokeBrush* Stroke = {read=FUnderlineStroke, write=SetStroke};
	__property System::Generics::Collections::TObjectList__1<TSpellingWord*>* SpellingWords = {read=FSpellingWords};
	__property TOnReplaceWordEvent OnReplaceWord = {read=FOnReplaceWord, write=FOnReplaceWord};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Spellingmanager */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_SPELLINGMANAGER)
using namespace Fmx::Text::Spellingmanager;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_SpellingmanagerHPP
