﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Platform.Menu.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Platform_Menu_WinHPP
#define Fmx_Platform_Menu_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Generics.Collections.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.Messages.hpp>
#include <FMX.Menus.hpp>
#include <FMX.Types.hpp>
#include <FMX.Forms.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Platform
{
namespace Menu
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWinMenuLooper;
class DELPHICLASS TWinMenuService;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWinMenuLooper : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Fmx::Menus::_di_IMenuView FView;
	bool __fastcall IsItemSelectable(Fmx::Types::TFmxObject* const Item);
	void __fastcall SelectFirstMenuItem(const Fmx::Menus::_di_IMenuView AView);
	void __fastcall SelectLastMenuItem(const Fmx::Menus::_di_IMenuView AView);
	void __fastcall SelectNextMenuItem(const Fmx::Menus::_di_IMenuView AView, const bool ABackward);
	bool __fastcall BackwardSelectNextMenuItem(const Fmx::Menus::_di_IMenuView AView, const int AStartInd, const int AEndInd);
	bool __fastcall ForwardSelectNextMenuItem(const Fmx::Menus::_di_IMenuView AView, const int AStartInd, const int AEndInd);
	
public:
	void __fastcall StartLoop(const Fmx::Menus::_di_IMenuView AView);
	void __fastcall EndLoop(const Fmx::Menus::_di_IMenuView AView);
public:
	/* TObject.Create */ inline __fastcall TWinMenuLooper() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TWinMenuLooper() { }
	
};


class PASCALIMPLEMENTATION TWinMenuService : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
	
private:
	enum class DECLSPEC_DENUM TState : unsigned char { CreatingOSMenu, DestroyingMenuItem };
	
	typedef System::Set<TState, _DELPHI_SET_ENUMERATOR(TState::CreatingOSMenu), _DELPHI_SET_ENUMERATOR(TState::DestroyingMenuItem)> TStates;
	
	typedef int TMenuId;
	struct DECLSPEC_DRECORD TWinMenuInfo
	{
	public:
		int MenuID;
		Fmx::Menus::TMenuItem* FMXMenuItem;
		__fastcall TWinMenuInfo(const int AMenuId, Fmx::Menus::TMenuItem* const AnItem);
		TWinMenuInfo() {}
	};
	
	
	
private:
	System::Generics::Collections::TDictionary__2<unsigned __int64,TWinMenuInfo>* FHMenuMap;
	System::Generics::Collections::TDictionary__2<int,unsigned __int64>* FHMenuIdMap;
	TStates FStates;
	TWinMenuLooper* FMenuLooper;
	int __fastcall GenerateMenuId();
	int __fastcall AssignNewIdToLastMenu(const HMENU AParentMenu, const HMENU AMenu);
	bool __fastcall FindMenuInfoById(const int AMenuItemId, TWinMenuInfo &AMenuInfo);
	void __fastcall DestroysAllMenuItems(const Fmx::Types::_di_IItemsContainer AMenu);
	void __fastcall RemoveMenuFromMaps(const Fmx::Types::TFmxHandle AMenuHandle);
	void __fastcall AddBitmapToMenu(const HMENU AParentMenu, const int AMenuItemId, const HBITMAP ABitmap);
	void __fastcall RemoveBitmapFromMenu(const HMENU AParentMenu, const HMENU AMenu);
	
protected:
	MESSAGE void __fastcall WMCommand(Winapi::Messages::TWMCommand &Message);
	MESSAGE void __fastcall WMInitMenuPopup(Winapi::Messages::TWMInitMenuPopup &Message);
	MESSAGE void __fastcall WMMenuSelect(Winapi::Messages::TWMMenuSelect &Message);
	
public:
	__fastcall TWinMenuService();
	__fastcall virtual ~TWinMenuService();
	void __fastcall StartMenuLoop(const Fmx::Menus::_di_IMenuView AView);
	System::UnicodeString __fastcall ShortCutToText(System::Classes::TShortCut ShortCut);
	void __fastcall ShortCutToKey(System::Classes::TShortCut ShortCut, System::Word &Key, System::Classes::TShiftState &Shift);
	int __fastcall TextToShortCut(System::UnicodeString Text);
	void __fastcall CreateOSMenu(Fmx::Forms::TCommonCustomForm* AForm, const Fmx::Types::_di_IItemsContainer AMenu);
	void __fastcall UpdateMenuItem(const Fmx::Types::_di_IItemsContainer AItem, Fmx::Types::TMenuItemChanges AChange);
	void __fastcall DestroyMenuItem(const Fmx::Types::_di_IItemsContainer AItem);
	bool __fastcall IsMenuBarOnWindowBorder();
	void __fastcall UpdateMenuBar();
private:
	void *__IFMXMenuService;	// Fmx::Menus::IFMXMenuService 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {8338685D-26BB-4421-AE54-1DC8456DC2A0}
	operator Fmx::Menus::_di_IFMXMenuService()
	{
		Fmx::Menus::_di_IFMXMenuService intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Menus::IFMXMenuService*(void) { return (Fmx::Menus::IFMXMenuService*)&__IFMXMenuService; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Win */
}	/* namespace Menu */
}	/* namespace Platform */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM_MENU_WIN)
using namespace Fmx::Platform::Menu::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM_MENU)
using namespace Fmx::Platform::Menu;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM)
using namespace Fmx::Platform;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Platform_Menu_WinHPP
