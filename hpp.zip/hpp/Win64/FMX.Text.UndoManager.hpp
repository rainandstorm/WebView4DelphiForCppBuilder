﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.UndoManager.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_UndomanagerHPP
#define Fmx_Text_UndomanagerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Generics.Collections.hpp>
#include <FMX.Text.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>
#include <System.Types.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Undomanager
{
//-- forward type declarations -----------------------------------------------
struct TFragmentInserted;
struct TFragmentDeleted;
struct TEditAction;
class DELPHICLASS TUndoManager;
//-- type declarations -------------------------------------------------------
struct DECLSPEC_DRECORD TFragmentInserted
{
public:
	int StartPos;
	System::UnicodeString Fragment;
	bool PairedWithPrev;
	bool Typed;
	__fastcall TFragmentInserted(const int AStartPos, const System::UnicodeString AFragment, const bool APairedWithPrev, const bool ATyped);
	TFragmentInserted() {}
};


struct DECLSPEC_DRECORD TFragmentDeleted
{
public:
	int StartPos;
	System::UnicodeString Fragment;
	bool Selected;
	bool CaretMoved;
	__fastcall TFragmentDeleted(const int AStartPos, const System::UnicodeString AFragment, const bool ASelected, const bool ACaretMoved);
	TFragmentDeleted() {}
};


enum class DECLSPEC_DENUM TActionType : unsigned char { Delete, Insert };

struct DECLSPEC_DRECORD TEditAction
{
public:
	TActionType ActionType;
	bool PairedWithPrev;
	int StartPosition;
	System::UnicodeString Fragment;
	bool Typed;
	bool WasSelected;
	bool CaretMoved;
};


typedef void __fastcall (__closure *TUndoEvent)(System::TObject* Sender, const TActionType AActionType, const TEditAction &AEditInfo, const Fmx::Text::TInsertOptions AOptions);

typedef void __fastcall (__closure *TRedoEvent)(System::TObject* Sender, const TActionType AActionType, const TEditAction &AEditInfo, const Fmx::Text::TDeleteOptions AOptions);

class PASCALIMPLEMENTATION TUndoManager : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	System::Generics::Collections::TList__1<TEditAction>* FActions;
	int FCurrentActionIndex;
	TUndoEvent FOnUndo;
	TRedoEvent FOnRedo;
	TEditAction __fastcall GetCurrentAction();
	
protected:
	virtual void __fastcall DoUndo(const TActionType AActionType, const TEditAction &AEditInfo, const Fmx::Text::TInsertOptions AOptions);
	virtual void __fastcall DoRedo(const TActionType AActionType, const TEditAction &AEditInfo, const Fmx::Text::TDeleteOptions AOptions);
	void __fastcall AddAction(const TEditAction &AAction);
	void __fastcall RemoveTailActions();
	__property TEditAction CurrentAction = {read=GetCurrentAction};
	
public:
	__fastcall TUndoManager();
	__fastcall virtual ~TUndoManager();
	void __fastcall FragmentInserted(const int AStartPos, const System::UnicodeString AFragment, const bool APairedWithPrev, const bool ATyped);
	void __fastcall FragmentDeleted(const int AStartPos, const System::UnicodeString AFragment, const bool ASelected, const bool ACaretMoved);
	bool __fastcall Undo();
	bool __fastcall CanUndo();
	bool __fastcall Redo();
	bool __fastcall CanRedo();
	__property TUndoEvent OnUndo = {read=FOnUndo, write=FOnUndo};
	__property TRedoEvent OnRedo = {read=FOnRedo, write=FOnRedo};
};


typedef TUndoManager TEditActionStack _DEPRECATED_ATTRIBUTE1("Use TUndoManager instead") ;

//-- var, const, procedure ---------------------------------------------------
}	/* namespace Undomanager */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_UNDOMANAGER)
using namespace Fmx::Text::Undomanager;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_UndomanagerHPP
