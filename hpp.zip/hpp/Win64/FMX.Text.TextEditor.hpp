﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.TextEditor.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_TexteditorHPP
#define Fmx_Text_TexteditorHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.UITypes.hpp>
#include <System.Types.hpp>
#include <FMX.Text.hpp>
#include <FMX.ScrollBox.Style.hpp>
#include <FMX.Text.LinesLayout.hpp>
#include <FMX.Text.UndoManager.hpp>
#include <FMX.Text.SelectionController.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Text.IMERender.hpp>
#include <FMX.Graphics.hpp>
#include <FMX.Text.SpellingManager.hpp>
#include <FMX.Menus.hpp>
#include <FMX.Types.hpp>
#include <FMX.Platform.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Texteditor
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TTextEditor;
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TCaretPositionChanged)(System::TObject* Sender, const Fmx::Text::TCaretPosition &ACaretPosition);

enum class DECLSPEC_DENUM TIMEDisplayMode : unsigned char { InlineText, OverText };

class PASCALIMPLEMENTATION TTextEditor : public System::TNoRefCountObject
{
	typedef System::TNoRefCountObject inherited;
	
public:
	static _DELPHI_CONST System::Int8 DefaultEmptySelectionWidth = System::Int8(0x5);
	
	static _DELPHI_CONST System::Int8 IMEWindowGap = System::Int8(0x2);
	
	static _DELPHI_CONST unsigned DefaultSelectionColor = unsigned(0x802a8adf);
	
	static _DELPHI_CONST TIMEDisplayMode DefaultIMEDisplayMode = (TIMEDisplayMode)(1);
	
	static _DELPHI_CONST bool DefaultShouldDrawLeftAndRightSelectionSides = false;
	
	
private:
	Fmx::Controls::TControl* FOwner;
	Fmx::Types::TCustomCaret* FCaret;
	Fmx::Text::TIMETextLineSourceProxy* FLines;
	Fmx::Text::Lineslayout::TLinesLayout* FLinesLayout;
	Fmx::Scrollbox::Style::_di_IScrollableContent FScrollableContent;
	bool FIsPassword;
	Fmx::Graphics::TBrush* FSelectionFill;
	float FOpacity;
	bool FShouldDrawLeftAndRightSelectionSides;
	Fmx::Text::TCaretPosition FCaretPosition;
	Fmx::Text::Selectioncontroller::TSelectionController* FSelectionController;
	Fmx::Controls::TControl* FContent;
	bool FNeedUpdateContentOffset;
	bool FCheckSpelling;
	Fmx::Text::Spellingmanager::TSpellingManager* FSpellingManager;
	TIMEDisplayMode FIMEDisplayMode;
	Fmx::Text::Imerender::TIMETextLayout* FIMELayout;
	Fmx::Text::TTextService* FTextService;
	Fmx::Text::_di_IIMEComposingTextDecoration FIMEComposingTextDecoration;
	Fmx::Graphics::TFillTextFlags FFillTextFlags;
	bool FIsIMEActive;
	TCaretPositionChanged FOnCaretPositionChanged;
	Fmx::Text::Selectioncontroller::TSelectionChangedEvent FOnSelectionChanged;
	void __fastcall SetCaretPosition(const Fmx::Text::TCaretPosition &Value);
	void __fastcall SetTextSettings(Fmx::Graphics::TTextSettings* const Value);
	Fmx::Graphics::TTextSettings* __fastcall GetTextSettings();
	void __fastcall SetViewportPosition(const System::Types::TPointF &Value);
	void __fastcall SetCheckSpelling(const bool Value);
	void __fastcall SetOpacity(const float Value);
	void __fastcall SetSelectionFill(Fmx::Graphics::TBrush* const Value);
	void __fastcall SetFillTextFlags(const Fmx::Graphics::TFillTextFlags Value);
	void __fastcall SetIMEMode(const Fmx::Types::TImeMode Value);
	void __fastcall SetMaxLength(const int Value);
	void __fastcall SetCharCase(const System::Uitypes::TEditCharCase Value);
	void __fastcall SetIsPassword(const bool Value);
	Fmx::Text::_di_ITextLinesSource __fastcall GetLines();
	void __fastcall SetIMEDisplayMode(const TIMEDisplayMode Value);
	void __fastcall SelectionChangedHandler(System::TObject* Sender, const int ASelStart, const int ALength);
	
protected:
	virtual void __fastcall DoCaretPositionChanged();
	virtual void __fastcall DoSelectionChanged(const int ASelStart, const int ALength);
	bool __fastcall IsSpellCheckEnabled();
	bool __fastcall IsCurrentWordWrong();
	System::DynamicArray<System::UnicodeString> __fastcall GetListOfPrepositions();
	void __fastcall HighlightSpell();
	void __fastcall HideHighlightSpell();
	void __fastcall Spell(const System::UnicodeString AWord);
	Fmx::Text::TCaretPosition __fastcall GetPositionShift(const Fmx::Text::TCaretPosition &APosition, const int ADelta);
	Fmx::Text::TCaretPosition __fastcall GetWordBegin(const Fmx::Text::TCaretPosition &APosition);
	Fmx::Text::TCaretPosition __fastcall GetNextWordBegin(const Fmx::Text::TCaretPosition &APosition);
	Fmx::Text::TCaretPosition __fastcall GetPrevWordBegin(const Fmx::Text::TCaretPosition &APosition);
	Fmx::Text::TCaretPosition __fastcall GetLeftWordBegin(const Fmx::Text::TCaretPosition &APosition);
	float __fastcall GetPageSize();
	virtual void __fastcall DrawSelection(Fmx::Graphics::TCanvas* const ACanvas);
	virtual void __fastcall DrawSelectionRegion(Fmx::Graphics::TCanvas* const ACanvas, const System::Types::TRectF &ARegion);
	virtual void __fastcall DrawMarkedText(Fmx::Graphics::TCanvas* const ACanvas);
	virtual void __fastcall DrawComposingText(Fmx::Graphics::TCanvas* const ACanvas);
	void __fastcall NormalizeCaretPosition()/* overload */;
	Fmx::Text::TCaretPosition __fastcall NormalizeCaretPosition(const Fmx::Text::TCaretPosition &Value)/* overload */;
	virtual Fmx::Text::Lineslayout::TLinesLayout* __fastcall CreateLinesLayout();
	virtual Fmx::Text::Imerender::TIMETextLayout* __fastcall CreateIMETextLayout();
	virtual Fmx::Text::Spellingmanager::TSpellingManager* __fastcall CreateSpellingManager();
	virtual Fmx::Text::Selectioncontroller::TSelectionController* __fastcall CreateSelectionController();
	
public:
	__fastcall TTextEditor(Fmx::Controls::TControl* const AOwner, Fmx::Controls::TControl* const AContent, const Fmx::Text::_di_ITextLinesSource ATextLineSource, const Fmx::Scrollbox::Style::_di_IScrollableContent AScrollableContent, const bool AIsMultiLine);
	__fastcall virtual ~TTextEditor();
	Fmx::Graphics::TRegion __fastcall GetSelectionRegion();
	Fmx::Graphics::TRegion __fastcall GetVisibleSelectionRegion();
	void __fastcall SelectText(const int AStart, const int ALength);
	System::UnicodeString __fastcall SelectedText();
	void __fastcall BeginUpdate();
	void __fastcall EndUpdate();
	bool __fastcall IsUpdating();
	void __fastcall PutCaretTo(const float X, const float Y, const bool APositionByWord = false);
	void __fastcall GoToTextBegin();
	void __fastcall GoToTextEnd();
	void __fastcall GoToLineBegin();
	void __fastcall GoToLineEnd();
	void __fastcall MoveCaretVertical(const int ALineDelta);
	void __fastcall MoveCaretHorizontal(const int ADelta);
	void __fastcall MoveCaretPageUp();
	void __fastcall MoveCaretPageDown();
	void __fastcall MoveCaretLeft(const bool AIsCtrlOrCmd);
	void __fastcall MoveCaretRight(const bool AIsCtrlOrCmd);
	void __fastcall MoveCaretLeftRTL(const bool AIsCtrlOrCmd);
	void __fastcall MoveCaretRightRTL(const bool AIsCtrlOrCmd);
	Fmx::Text::TCaretPosition __fastcall CalculateTextBegin();
	Fmx::Text::TCaretPosition __fastcall CalculateTextEnd();
	Fmx::Text::TCaretPosition __fastcall CalculateLineBegin(const Fmx::Text::TCaretPosition &ACaretPosition);
	Fmx::Text::TCaretPosition __fastcall CalculateLineEnd(const Fmx::Text::TCaretPosition &ACaretPosition);
	Fmx::Text::TCaretPosition __fastcall CalculateCaretVertical(const Fmx::Text::TCaretPosition &ACaretPosition, const int ALineDelta);
	Fmx::Text::TCaretPosition __fastcall CalculateCaretHorizontal(const Fmx::Text::TCaretPosition &ACaretPosition, const int ADelta);
	System::Types::TPointF __fastcall GetCaretPositionPoint(const Fmx::Text::TCaretPosition &ACaretPos);
	Fmx::Text::TCaretPosition __fastcall GetCaretPositionByPoint(const System::Types::TPointF &AHitPoint, const bool RoundToWord = false);
	void __fastcall Render(Fmx::Graphics::TCanvas* const ACanvas, const System::Types::TRectF &ADestRect, const bool ANeedShowSelection);
	void __fastcall Repaint();
	void __fastcall InsertLine(const int AIndex, const System::UnicodeString ALine);
	void __fastcall DeleteLine(const int AIndex);
	void __fastcall ReplaceLine(const int AIndex, const System::UnicodeString ALine);
	void __fastcall ExchangeLines(const int AOldIndex, const int ANewIndex);
	void __fastcall Clear();
	void __fastcall UpdateContentOffset();
	void __fastcall UpdateCaretPoint();
	System::Types::TPointF __fastcall GetCaretPoint();
	System::Types::TSizeF __fastcall GetCaretSize();
	void __fastcall InvalidateContentSize();
	void __fastcall ChangeViewportPosition(const System::Types::TPointF &OldViewportPosition, const System::Types::TPointF &NewViewportPosition, const bool ContentSizeChanged);
	bool __fastcall HasIMEMarkedText();
	bool __fastcall HasIMEComposingText();
	void __fastcall UpdateTextInTextService();
	void __fastcall UpdateTextService();
	virtual bool __fastcall NeedHideCaretInIME();
	Fmx::Text::TTextService* __fastcall GetTextService();
	System::Types::TPointF __fastcall GetTargetClausePointF();
	void __fastcall StartIMEInput();
	void __fastcall IMEStateUpdated();
	void __fastcall EndIMEInput();
	System::Types::TRectF __fastcall GetSelectionRect(const bool ANeedShowSelection = true);
	System::Types::TRect __fastcall GetSelectionBounds();
	System::Types::TSizeF __fastcall GetSelectionPointSize();
	bool __fastcall HasText();
	__property Fmx::Text::TCaretPosition CaretPosition = {read=FCaretPosition, write=SetCaretPosition};
	__property System::Types::TPointF CaretPoint = {read=GetCaretPoint};
	__property Fmx::Text::Selectioncontroller::TSelectionController* SelectionController = {read=FSelectionController};
	__property Fmx::Text::_di_ITextLinesSource Lines = {read=GetLines};
	__property Fmx::Text::Lineslayout::TLinesLayout* LinesLayout = {read=FLinesLayout};
	__property Fmx::Scrollbox::Style::_di_IScrollableContent ScrollableContent = {read=FScrollableContent};
	__property Fmx::Types::TCustomCaret* Caret = {read=FCaret, write=FCaret};
	__property bool CheckSpelling = {read=FCheckSpelling, write=SetCheckSpelling, nodefault};
	__property Fmx::Text::Spellingmanager::TSpellingManager* SpellingManager = {read=FSpellingManager};
	__property bool IsPassword = {read=FIsPassword, write=SetIsPassword, nodefault};
	__property Fmx::Controls::TControl* Content = {read=FContent, write=FContent};
	__property System::Types::TPointF ViewportPosition = {write=SetViewportPosition};
	__property TIMEDisplayMode IMEDisplayMode = {read=FIMEDisplayMode, write=SetIMEDisplayMode, nodefault};
	__property Fmx::Types::TImeMode IMEMode = {write=SetIMEMode, nodefault};
	__property System::Uitypes::TEditCharCase CharCase = {write=SetCharCase, nodefault};
	__property Fmx::Text::TTextService* TextService = {read=FTextService};
	__property int MaxLength = {write=SetMaxLength, nodefault};
	__property Fmx::Graphics::TFillTextFlags FillTextFlags = {read=FFillTextFlags, write=SetFillTextFlags, nodefault};
	__property bool IsIMEActive = {read=FIsIMEActive, nodefault};
	__property Fmx::Text::Imerender::TIMETextLayout* IMELayout = {read=FIMELayout};
	__property Fmx::Graphics::TBrush* SelectionFill = {read=FSelectionFill, write=SetSelectionFill};
	__property Fmx::Graphics::TTextSettings* TextSettings = {read=GetTextSettings, write=SetTextSettings};
	__property float Opacity = {read=FOpacity, write=SetOpacity};
	__property TCaretPositionChanged OnCaretPositionChanged = {read=FOnCaretPositionChanged, write=FOnCaretPositionChanged};
	__property Fmx::Text::Selectioncontroller::TSelectionChangedEvent OnSelectionChanged = {read=FOnSelectionChanged, write=FOnSelectionChanged};
private:
	void *__ITextSpellCheckActions;	// Fmx::Text::ITextSpellCheckActions 
	void *__ITextSpellCheck;	// Fmx::Text::ITextSpellCheck 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {82A33171-C825-4B7F-B0C4-A56DDD4FF85C}
	operator Fmx::Text::_di_ITextSpellCheckActions()
	{
		Fmx::Text::_di_ITextSpellCheckActions intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Text::ITextSpellCheckActions*(void) { return (Fmx::Text::ITextSpellCheckActions*)&__ITextSpellCheckActions; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {30AA8C32-5ADA-456C-AAC5-B9F0309AE3A8}
	operator Fmx::Text::_di_ITextSpellCheck()
	{
		Fmx::Text::_di_ITextSpellCheck intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Text::ITextSpellCheck*(void) { return (Fmx::Text::ITextSpellCheck*)&__ITextSpellCheck; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Texteditor */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_TEXTEDITOR)
using namespace Fmx::Text::Texteditor;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_TexteditorHPP
