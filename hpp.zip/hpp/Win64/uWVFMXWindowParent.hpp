﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVFMXWindowParent.pas' rev: 36.00 (Windows)

#ifndef UwvfmxwindowparentHPP
#define UwvfmxwindowparentHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <System.UITypes.hpp>
#include <Winapi.Windows.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Types.hpp>
#include <FMX.Forms.hpp>
#include <uWVWinControl.hpp>
#include <uWVBrowserBase.hpp>
#include <uWVConstants.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvfmxwindowparent
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWVFMXWindowParent;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWVFMXWindowParent : public Fmx::Forms::TCommonCustomForm
{
	typedef Fmx::Forms::TCommonCustomForm inherited;
	
protected:
	Uwvbrowserbase::TWVBrowserBase* FBrowser;
	Uwvbrowserbase::TWVBrowserBase* __fastcall GetBrowser();
	HWND __fastcall GetChildWindowHandle();
	void __fastcall SetBrowser(Uwvbrowserbase::TWVBrowserBase* const aValue);
	virtual void __fastcall Notification(System::Classes::TComponent* AComponent, System::Classes::TOperation Operation);
	virtual void __fastcall Resize();
	virtual void __fastcall DoFocusChanged();
	
public:
	__fastcall virtual TWVFMXWindowParent(System::Classes::TComponent* AOwner, System::NativeInt Dummy);
	void __fastcall Reparent(Fmx::Types::TWindowHandle* const aNewParentHandle);
	virtual void __fastcall UpdateSize();
	__property HWND ChildWindowHandle = {read=GetChildWindowHandle};
	__property Uwvbrowserbase::TWVBrowserBase* Browser = {read=GetBrowser, write=SetBrowser};
	
__published:
	__property Visible = {default=0};
	__property Height;
	__property Width;
	__property Touch;
	__property OnGesture;
public:
	/* TCommonCustomForm.Create */ inline __fastcall virtual TWVFMXWindowParent(System::Classes::TComponent* AOwner) : Fmx::Forms::TCommonCustomForm(AOwner) { }
	/* TCommonCustomForm.Destroy */ inline __fastcall virtual ~TWVFMXWindowParent() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvfmxwindowparent */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVFMXWINDOWPARENT)
using namespace Uwvfmxwindowparent;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// UwvfmxwindowparentHPP
