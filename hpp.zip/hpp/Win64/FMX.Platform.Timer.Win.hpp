﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Platform.Timer.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Platform_Timer_WinHPP
#define Fmx_Platform_Timer_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Generics.Collections.hpp>
#include <System.Messaging.hpp>
#include <Winapi.Windows.hpp>
#include <FMX.Types.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>
#include <System.Types.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Platform
{
namespace Timer
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWinTimerService;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWinTimerService : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
	
private:
	struct DECLSPEC_DRECORD TTimerInfo
	{
	public:
		System::UIntPtr ID;
		Fmx::Types::TFmxHandle Handle;
		Fmx::Types::TTimerProc Func;
	};
	
	
	
private:
	static TWinTimerService* FSingleton;
	Fmx::Types::TFmxHandle FHandleCounter;
	System::Generics::Collections::TList__1<TTimerInfo>* FTimers;
	__int64 FPerformanceFrequency;
	bool FTerminating;
	void __fastcall DestroyTimers();
	static void __stdcall TimerCallback(HWND window_hwnd, System::LongInt Msg, unsigned idEvent, System::LongInt dwTime);
	void __fastcall ApplicationTerminatingHandler(System::TObject* const Sender, System::Messaging::TMessageBase* const Msg);
	
public:
	__fastcall TWinTimerService();
	__fastcall virtual ~TWinTimerService();
	Fmx::Types::TFmxHandle __fastcall CreateTimer(int AInterval, Fmx::Types::TTimerProc ATimerFunc);
	bool __fastcall DestroyTimer(Fmx::Types::TFmxHandle Timer);
	double __fastcall GetTick();
private:
	void *__IFMXTimerService;	// Fmx::Types::IFMXTimerService 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {856E938B-FF7B-4E13-85D4-3414A6A9FF2F}
	operator Fmx::Types::_di_IFMXTimerService()
	{
		Fmx::Types::_di_IFMXTimerService intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Types::IFMXTimerService*(void) { return (Fmx::Types::IFMXTimerService*)&__IFMXTimerService; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Win */
}	/* namespace Timer */
}	/* namespace Platform */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM_TIMER_WIN)
using namespace Fmx::Platform::Timer::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM_TIMER)
using namespace Fmx::Platform::Timer;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM)
using namespace Fmx::Platform;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Platform_Timer_WinHPP
