﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Edit.Style.New.pas' rev: 36.00 (Windows)

#ifndef Fmx_Edit_Style_NewHPP
#define Fmx_Edit_Style_NewHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <System.UITypes.hpp>
#include <System.Classes.hpp>
#include <FMX.Presentation.Messages.hpp>
#include <FMX.Presentation.Style.hpp>
#include <FMX.Controls.Presentation.hpp>
#include <FMX.Edit.hpp>
#include <FMX.Text.hpp>
#include <FMX.Text.LinesLayout.hpp>
#include <FMX.Text.UndoManager.hpp>
#include <FMX.Text.SelectionController.hpp>
#include <FMX.Text.AutoscrollController.hpp>
#include <FMX.Text.SpellingManager.hpp>
#include <FMX.Text.IMERender.hpp>
#include <FMX.Menus.hpp>
#include <FMX.Graphics.hpp>
#include <FMX.Types.hpp>
#include <FMX.Controls.Model.hpp>
#include <FMX.Controls.hpp>
#include <FMX.ScrollBox.Style.hpp>
#include <FMX.Text.TextEditor.hpp>
#include <FMX.Text.InteractiveSelectors.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Edit
{
namespace Style
{
namespace New
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TEditUndoManager;
class DELPHICLASS TStyledEditContent;
class DELPHICLASS TContextMenuItem;
class DELPHICLASS TStyledEdit;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TEditUndoManager : public Fmx::Text::Undomanager::TUndoManager
{
	typedef Fmx::Text::Undomanager::TUndoManager inherited;
	
private:
	Fmx::Edit::TCustomEditModel* FModel;
	
protected:
	virtual void __fastcall DoUndo(const Fmx::Text::Undomanager::TActionType AActionType, const Fmx::Text::Undomanager::TEditAction &AEditInfo, const Fmx::Text::TInsertOptions AOptions);
	virtual void __fastcall DoRedo(const Fmx::Text::Undomanager::TActionType AActionType, const Fmx::Text::Undomanager::TEditAction &AEditInfo, const Fmx::Text::TDeleteOptions AOptions);
	
public:
	__fastcall TEditUndoManager(Fmx::Edit::TCustomEditModel* const AModel);
	__property Fmx::Edit::TCustomEditModel* Model = {read=FModel};
public:
	/* TUndoManager.Destroy */ inline __fastcall virtual ~TEditUndoManager() { }
	
};


typedef void __fastcall (__closure *TOnContentBoundsEvent)(System::TObject* Sender, System::Types::TRectF &ContentBounds);

class PASCALIMPLEMENTATION TStyledEditContent : public Fmx::Controls::TContent
{
	typedef Fmx::Controls::TContent inherited;
	
private:
	TStyledEdit* FEdit;
	TOnContentBoundsEvent FOnGetClipRect;
	
protected:
	virtual System::Types::TRectF __fastcall GetClipRect();
	virtual Fmx::Types::_di_IControl __fastcall ObjectAtPoint(const System::Types::TPointF &P);
	virtual System::Types::TRectF __fastcall DoGetUpdateRect();
	
public:
	__fastcall virtual TStyledEditContent(System::Classes::TComponent* AOwner);
	virtual bool __fastcall PointInObjectLocal(float X, float Y);
	__property TOnContentBoundsEvent OnGetClipRect = {read=FOnGetClipRect, write=FOnGetClipRect};
public:
	/* TControl.Destroy */ inline __fastcall virtual ~TStyledEditContent() { }
	
};


enum class DECLSPEC_DENUM TContextAction : unsigned char { Cut, Copy, Paste, Delete, Undo, Redo, SelectAll };

class PASCALIMPLEMENTATION TContextMenuItem : public Fmx::Menus::TMenuItem
{
	typedef Fmx::Menus::TMenuItem inherited;
	
private:
	TContextAction FContextAction;
	
public:
	__property TContextAction ContextAction = {read=FContextAction, write=FContextAction, nodefault};
public:
	/* TMenuItem.Create */ inline __fastcall virtual TContextMenuItem(System::Classes::TComponent* AOwner)/* overload */ : Fmx::Menus::TMenuItem(AOwner) { }
	/* TMenuItem.Destroy */ inline __fastcall virtual ~TContextMenuItem() { }
	
};


class PASCALIMPLEMENTATION TStyledEdit : public Fmx::Presentation::Style::TStyledPresentation
{
	typedef Fmx::Presentation::Style::TStyledPresentation inherited;
	
	
protected:
	enum class DECLSPEC_DENUM TSelectionMethod : unsigned char { Keyboard, Mouse, LeftSelector, RightSelector, LongTapGesture };
	
	typedef System::Set<TSelectionMethod, _DELPHI_SET_ENUMERATOR(TSelectionMethod::Keyboard), _DELPHI_SET_ENUMERATOR(TSelectionMethod::LongTapGesture)> TSelectionMethods;
	
	enum class DECLSPEC_DENUM TSelectionOption : unsigned char { SelectWords };
	
	typedef System::Set<TSelectionOption, _DELPHI_SET_ENUMERATOR(TSelectionOption::SelectWords), _DELPHI_SET_ENUMERATOR(TSelectionOption::SelectWords)> TSelectionOptions;
	
	enum class DECLSPEC_DENUM TScrollDirection : unsigned char { Up, Down };
	
	
public:
	static _DELPHI_CONST System::Int8 DefaultEmptySelectionWidth = System::Int8(0x5);
	
	static _DELPHI_CONST System::Int8 IMEWindowGap = System::Int8(0x2);
	
	#define TStyledEdit_MarkedTextBackgroundOpacity  (9.000000E-01)
	
	
private:
	Fmx::Text::Texteditor::TTextEditor* FEditor;
	Fmx::Menus::TPopupMenu* FPopupMenu;
	Fmx::Text::Undomanager::TUndoManager* FUndoManager;
	System::UnicodeString FCharsBuffer;
	bool FSetFocusOnUp;
	TStyledEditContent* FContent;
	System::Types::TPointF FViewportPosition;
	Fmx::Text::Autoscrollcontroller::TAutoscrollController* FAutoscrollController;
	TSelectionMethods FSelectionMethods;
	TSelectionOptions FSelectionOptions;
	Fmx::Text::Interactiveselectors::TInteractiveTextSelectors* FTextSelectors;
	Fmx::Controls::TControl* FLeftLayout;
	Fmx::Controls::TControl* FButtonsLayout;
	Fmx::Controls::TControl* FPrompt;
	Fmx::Controls::TControl* FContentLayout;
	bool FDisableCaretInsideWords;
	bool FUseLongTapForWordSelection;
	HIDESBASE Fmx::Edit::TCustomEditModel* __fastcall GetModel();
	Fmx::Edit::TCustomEdit* __fastcall GetEdit();
	void __fastcall SetCaretPosition(const int Value);
	int __fastcall GetCaretPosition();
	void __fastcall UpdatePromptTextSettings();
	void __fastcall ReplaceWordHandler(Fmx::Text::Spellingmanager::TSpellingWord* const ASpellingWord, const System::UnicodeString ASuggestion);
	void __fastcall CaretPositionChanged(System::TObject* Sender, const Fmx::Text::TCaretPosition &ACaretPosition);
	void __fastcall SelectionChangedHandler(System::TObject* Sender, const int ASelStart, const int ALength);
	void __fastcall ContextMenuItemClick(System::TObject* Sender);
	void __fastcall AutoScrollHandler(const Fmx::Text::Autoscrollcontroller::TAutoscrollDirection ADirection, bool &AStop);
	void __fastcall ContentGetClipRectHandler(System::TObject* Sender, System::Types::TRectF &AClipRect);
	void __fastcall SelectorPositionChangedHandler(System::TObject* Sender, const Fmx::Text::Interactiveselectors::TTextSelectorType ASelector, const System::Types::TPointF &AContentPoint);
	void __fastcall BeginInteractiveSelectionHandler(System::TObject* Sender, const Fmx::Text::Interactiveselectors::TTextSelectorType AInitiator);
	void __fastcall EndInteractiveSelectionHandler(System::TObject* Sender, const Fmx::Text::Interactiveselectors::TTextSelectorType AInitiator);
	System::Types::TPointF __fastcall GetViewportPosition();
	void __fastcall SetViewportPosition(const System::Types::TPointF &Value);
	System::Types::TSizeF __fastcall GetViewportSize();
	void __fastcall SetContentSize(const System::Types::TSizeF &ASize);
	System::Types::TSizeF __fastcall GetContentSize();
	__property System::Types::TPointF ViewportPosition = {read=GetViewportPosition, write=SetViewportPosition};
	__property System::Types::TSizeF ViewportSize = {read=GetViewportSize};
	
protected:
	virtual Fmx::Controls::Model::TDataModelClass __fastcall DefineModelClass();
	virtual void __fastcall DoTyping();
	virtual void __fastcall DoResized();
	virtual void __fastcall RealignContent();
	virtual void __fastcall RealignButtonsContainer();
	MESSAGE void __fastcall MMCharCaseChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<System::Uitypes::TEditCharCase> &Message);
	MESSAGE void __fastcall MMCheckSpellingChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<bool> &Message);
	MESSAGE void __fastcall MMHideSelectionOnExitChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<bool> &Message);
	MESSAGE void __fastcall MMPasswordChanged(System::TDispatchMessage &AMessage);
	MESSAGE void __fastcall MMReadOnlyChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<bool> &Message);
	MESSAGE void __fastcall MMImeModeChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<Fmx::Types::TImeMode> &Message);
	MESSAGE void __fastcall MMSetSelStart(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<int> &Message);
	MESSAGE void __fastcall MMSelLengthChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<int> &Message);
	MESSAGE void __fastcall MMTextSettingsChanged(System::TDispatchMessage &Message);
	MESSAGE void __fastcall MMTextChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<System::UnicodeString> &AMessage);
	MESSAGE void __fastcall MMTextChanging(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<System::UnicodeString> &AMessage);
	MESSAGE void __fastcall MMEditButtonsChanged(System::TDispatchMessage &Message);
	MESSAGE void __fastcall MMPromptTextChanged(System::TDispatchMessage &Message);
	MESSAGE void __fastcall MMFilterCharChanged(System::TDispatchMessage &Message);
	MESSAGE void __fastcall MMSetCaretPosition(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<int> &Message);
	MESSAGE void __fastcall MMCanSetFocus(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<bool> &Message);
	MESSAGE void __fastcall MMMaxLengthChanged(System::TDispatchMessage &Message);
	MESSAGE void __fastcall MMGetCaretPositionByPoint(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<Fmx::Edit::TCustomEditModel::TGetCaretPositionInfo> &Message);
	MESSAGE void __fastcall PMFragmentInserted(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<Fmx::Text::Undomanager::TFragmentInserted> &Message);
	MESSAGE void __fastcall PMFragmentDeleted(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<Fmx::Text::Undomanager::TFragmentDeleted> &Message);
	MESSAGE void __fastcall PMUndo(System::TDispatchMessage &Message);
	MESSAGE void __fastcall PMRootChanged(Fmx::Presentation::Messages::TDispatchMessageWithValue__1<Fmx::Types::_di_IRoot> &Message);
	MESSAGE void __fastcall PMInit(System::TDispatchMessage &Message);
	Fmx::Text::TTextService* __fastcall GetTextService();
	System::Types::TPointF __fastcall GetTargetClausePointF();
	void __fastcall StartIMEInput();
	void __fastcall EndIMEInput();
	void __fastcall IMEStateUpdated();
	System::UnicodeString __fastcall GetSelection();
	System::Types::TRectF __fastcall GetSelectionRect();
	System::Types::TRect __fastcall GetSelectionBounds();
	System::Types::TSizeF __fastcall GetSelectionPointSize();
	bool __fastcall HasText();
	void __fastcall SetSelection(const Fmx::Text::TCaretPosition &AStart, const int ALength);
	void __fastcall ContentPaint(System::TObject* Sender, Fmx::Graphics::TCanvas* ACanvas, const System::Types::TRectF &ARect);
	bool __fastcall IsSelecting();
	virtual bool __fastcall NeedShowSelection();
	void __fastcall StartAutoScroll(const System::Types::TPointF &ALocalPoint);
	virtual void __fastcall ExecuteContextAction(const TContextAction AAction);
	virtual void __fastcall FillPopupMenu(Fmx::Menus::TPopupMenu* const AMenu);
	virtual void __fastcall UpdatePopupMenuItems(Fmx::Menus::TPopupMenu* const AMenu);
	virtual void __fastcall MouseDown(System::Uitypes::TMouseButton Button, System::Classes::TShiftState Shift, float X, float Y);
	virtual void __fastcall MouseMove(System::Classes::TShiftState Shift, float X, float Y);
	virtual void __fastcall MouseUp(System::Uitypes::TMouseButton Button, System::Classes::TShiftState Shift, float X, float Y);
	virtual void __fastcall CMGesture(Fmx::Types::TGestureEventInfo &EventInfo);
	virtual void __fastcall DoGesture(const Fmx::Types::TGestureEventInfo &EventInfo, bool &Handled);
	void __fastcall LongTap(const System::Types::TPointF &ALocalPoint, const Fmx::Types::TInteractiveGestureFlags AFlags);
	void __fastcall DblTap();
	virtual bool __fastcall ShowContextMenu(const System::Types::TPointF &ScreenPosition);
	void __fastcall ChangeViewportPosition(const System::Types::TPointF &OldViewportPosition, const System::Types::TPointF &NewViewportPosition, const bool ContentSizeChanged);
	virtual void __fastcall KeyDown(System::Word &Key, System::WideChar &KeyChar, System::Classes::TShiftState Shift);
	virtual void __fastcall KeyUp(System::Word &Key, System::WideChar &KeyChar, System::Classes::TShiftState Shift);
	virtual void __fastcall DoEnter();
	virtual void __fastcall DoExit();
	virtual void __fastcall DoBeginUpdate();
	virtual void __fastcall DoEndUpdate();
	virtual void __fastcall ApplyStyle();
	virtual void __fastcall FreeStyle();
	virtual void __fastcall Resize();
	virtual void __fastcall DoChange();
	virtual void __fastcall DoRealign();
	virtual void __fastcall FreeNotification(System::TObject* AObject);
	virtual Fmx::Text::Texteditor::TTextEditor* __fastcall CreateEditor();
	virtual Fmx::Text::Interactiveselectors::TInteractiveTextSelectors* __fastcall CreateTextSelectors();
	
public:
	__fastcall virtual TStyledEdit(System::Classes::TComponent* AOwner)/* overload */;
	__fastcall virtual ~TStyledEdit();
	virtual HRESULT __stdcall QueryInterface(const GUID &IID, /* out */ void *Obj);
	virtual void __fastcall RecalcOpacity();
	void __fastcall Undo();
	void __fastcall Redo();
	void __fastcall RepaintContent();
	void __fastcall PutCaretTo(const float X, const float Y, const bool APositionByWord = false);
	System::Types::TRectF __fastcall ContentLayoutRect();
	__property Fmx::Edit::TCustomEditModel* Model = {read=GetModel};
	__property Fmx::Edit::TCustomEdit* Edit = {read=GetEdit};
	__property Fmx::Text::Autoscrollcontroller::TAutoscrollController* AutoscrollController = {read=FAutoscrollController};
	__property int CaretPosition = {read=GetCaretPosition, write=SetCaretPosition, nodefault};
	__property TStyledEditContent* Content = {read=FContent};
	__property bool DisableCaretInsideWords = {read=FDisableCaretInsideWords, write=FDisableCaretInsideWords, nodefault};
	__property bool UseLongTapForWordSelection = {read=FUseLongTapForWordSelection, write=FUseLongTapForWordSelection, nodefault};
	__property Fmx::Text::Texteditor::TTextEditor* Editor = {read=FEditor};
	__property Fmx::Text::Undomanager::TUndoManager* UndoManager = {read=FUndoManager};
	__property Fmx::Text::Interactiveselectors::TInteractiveTextSelectors* TextSelectors = {read=FTextSelectors};
	__property Fmx::Controls::TControl* ButtonsLayout = {read=FButtonsLayout};
	__property Fmx::Controls::TControl* LeftLayout = {read=FLeftLayout};
public:
	/* TStyledPresentation.Create */ inline __fastcall virtual TStyledEdit(System::Classes::TComponent* AOwner, Fmx::Controls::Model::TDataModel* const AModel, Fmx::Controls::TControl* const AControl)/* overload */ : Fmx::Presentation::Style::TStyledPresentation(AOwner, AModel, AControl) { }
	
private:
	void *__IScrollableContent;	// Fmx::Scrollbox::Style::IScrollableContent 
	void *__ITextSelection;	// Fmx::Text::ITextSelection 
	void *__ITextInput;	// Fmx::Text::ITextInput 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {0A13B84A-9E97-43B4-8A15-02E5AB22823B}
	operator Fmx::Scrollbox::Style::_di_IScrollableContent()
	{
		Fmx::Scrollbox::Style::_di_IScrollableContent intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Scrollbox::Style::IScrollableContent*(void) { return (Fmx::Scrollbox::Style::IScrollableContent*)&__IScrollableContent; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {5BC4EB77-92BE-4CA7-8BC8-FF06846D12CE}
	operator Fmx::Text::_di_ITextSelection()
	{
		Fmx::Text::_di_ITextSelection intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Text::ITextSelection*(void) { return (Fmx::Text::ITextSelection*)&__ITextSelection; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {56D79E74-58D6-4C1E-B832-F133D669B952}
	operator Fmx::Text::_di_ITextInput()
	{
		Fmx::Text::_di_ITextInput intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Text::ITextInput*(void) { return (Fmx::Text::ITextInput*)&__ITextInput; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace New */
}	/* namespace Style */
}	/* namespace Edit */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_EDIT_STYLE_NEW)
using namespace Fmx::Edit::Style::New;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_EDIT_STYLE)
using namespace Fmx::Edit::Style;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_EDIT)
using namespace Fmx::Edit;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Edit_Style_NewHPP
