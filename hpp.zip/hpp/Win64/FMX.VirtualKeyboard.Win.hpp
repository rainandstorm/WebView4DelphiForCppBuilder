﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.VirtualKeyboard.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Virtualkeyboard_WinHPP
#define Fmx_Virtualkeyboard_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <Winapi.Windows.hpp>
#include <FMX.Types.hpp>
#include <FMX.Pickers.hpp>
#include <FMX.Platform.hpp>
#include <FMX.VirtualKeyboard.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Virtualkeyboard
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWinVirtualKeyboard;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWinVirtualKeyboard : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
	
private:
	enum class DECLSPEC_DENUM TvkbState : unsigned char { None, Hidden, Shown };
	
	
private:
	System::UnicodeString FPath;
	System::UnicodeString FExeName;
	System::UnicodeString FWndClassName;
	Fmx::Types::TFmxHandle FHTmerLang;
	Fmx::Types::TFmxHandle FHTmerVisible;
	bool FKBPresent;
	HWND FFormHandle;
	Winapi::Windows::HINST FInst;
	bool FError;
	TvkbState FLastvkbState;
	HWND FLastHandle;
	System::TDateTime FLastTime;
	TvkbState FNewvkbState;
	bool FWait;
	int FStepActivate;
	HKL FCodeKeyboard;
	Fmx::Types::_di_IFMXTimerService FTimerService;
	void __fastcall KillTimerLang();
	void __fastcall TimerLangProc();
	void __fastcall StartTimerLang();
	void __fastcall KillTimerVisible();
	void __fastcall TimerVisibleProc();
	void __fastcall StartTimerVisible();
	System::UnicodeString __fastcall FindKeyValue(const HKEY Key, const System::UnicodeString Name, const System::UnicodeString Value, const System::UnicodeString SubKeyName, const System::UnicodeString SubValueName);
	Fmx::Types::TVirtualKeyboardStates __fastcall GetVirtualKeyboardState();
	void __fastcall vkbExecute(HWND FormHandle);
	HWND __fastcall vkbHandle();
	TvkbState __fastcall vkbState();
	Winapi::Windows::TRect __fastcall GetVKBounds();
	
protected:
	void __fastcall Clear();
	bool __fastcall IsAutoShow();
	
public:
	__fastcall TWinVirtualKeyboard();
	__fastcall virtual ~TWinVirtualKeyboard();
	bool __fastcall ShowVirtualKeyboard(Fmx::Types::TFmxObject* const AControl);
	bool __fastcall HideVirtualKeyboard();
	void __fastcall SetTransientState(bool Value);
	__property Fmx::Types::TVirtualKeyboardStates VirtualKeyboardState = {read=GetVirtualKeyboardState, nodefault};
	__property System::UnicodeString ExeName = {read=FExeName, write=FExeName};
	__property System::UnicodeString Path = {read=FPath, write=FPath};
	__property System::UnicodeString WndClassName = {read=FWndClassName, write=FWndClassName};
private:
	void *__IFMXVirtualKeyboardService;	// Fmx::Virtualkeyboard::IFMXVirtualKeyboardService 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {BB6F6668-C582-42E4-A766-863C1B9139D2}
	operator Fmx::Virtualkeyboard::_di_IFMXVirtualKeyboardService()
	{
		Fmx::Virtualkeyboard::_di_IFMXVirtualKeyboardService intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Virtualkeyboard::IFMXVirtualKeyboardService*(void) { return (Fmx::Virtualkeyboard::IFMXVirtualKeyboardService*)&__IFMXVirtualKeyboardService; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Win */
}	/* namespace Virtualkeyboard */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_VIRTUALKEYBOARD_WIN)
using namespace Fmx::Virtualkeyboard::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_VIRTUALKEYBOARD)
using namespace Fmx::Virtualkeyboard;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Virtualkeyboard_WinHPP
