﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Platform.SaveState.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Platform_Savestate_WinHPP
#define Fmx_Platform_Savestate_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <FMX.Platform.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Platform
{
namespace Savestate
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWinSaveStateService;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWinSaveStateService : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
private:
	System::UnicodeString FSaveStateStoragePath;
	
protected:
	System::UnicodeString __fastcall GetSaveStateFileName(const System::UnicodeString ABlockName);
	
public:
	bool __fastcall GetBlock(const System::UnicodeString ABlockName, System::Classes::TStream* const ABlockData);
	bool __fastcall SetBlock(const System::UnicodeString ABlockName, System::Classes::TStream* const ABlockData);
	System::UnicodeString __fastcall GetStoragePath();
	void __fastcall SetStoragePath(const System::UnicodeString ANewPath);
	bool __fastcall GetNotifications();
public:
	/* TObject.Create */ inline __fastcall TWinSaveStateService() : System::TInterfacedObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TWinSaveStateService() { }
	
private:
	void *__IFMXSaveStateService;	// Fmx::Platform::IFMXSaveStateService 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {34CB784A-E262-4E2C-B3B6-C3A41B722D7A}
	operator Fmx::Platform::_di_IFMXSaveStateService()
	{
		Fmx::Platform::_di_IFMXSaveStateService intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Platform::IFMXSaveStateService*(void) { return (Fmx::Platform::IFMXSaveStateService*)&__IFMXSaveStateService; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Win */
}	/* namespace Savestate */
}	/* namespace Platform */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM_SAVESTATE_WIN)
using namespace Fmx::Platform::Savestate::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM_SAVESTATE)
using namespace Fmx::Platform::Savestate;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM)
using namespace Fmx::Platform;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Platform_Savestate_WinHPP
