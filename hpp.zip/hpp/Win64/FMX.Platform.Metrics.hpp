﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Platform.Metrics.pas' rev: 36.00 (Windows)

#ifndef Fmx_Platform_MetricsHPP
#define Fmx_Platform_MetricsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Generics.Collections.hpp>
#include <System.Rtti.hpp>
#include <FMX.Platform.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Platform
{
namespace Metrics
{
//-- forward type declarations -----------------------------------------------
__interface DELPHIINTERFACE IFMXPlatformPropertiesService;
typedef System::DelphiInterface<IFMXPlatformPropertiesService> _di_IFMXPlatformPropertiesService;
class DELPHICLASS TDefaultPlatformPropertiesService;
//-- type declarations -------------------------------------------------------
__interface  INTERFACE_UUID("{7CF49B46-FE43-4675-B386-244158474656}") IFMXPlatformPropertiesService  : public System::IInterface 
{
	virtual void __fastcall SetValue(const System::UnicodeString AName, const System::Rtti::TValue &AValue) = 0 ;
	virtual System::Rtti::TValue __fastcall GetValue(const System::UnicodeString AName, const System::Rtti::TValue &ADefaultValue) = 0 ;
};

class PASCALIMPLEMENTATION TDefaultPlatformPropertiesService : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
private:
	System::Generics::Collections::TDictionary__2<System::UnicodeString,System::Rtti::TValue>* FValues;
	
public:
	__fastcall TDefaultPlatformPropertiesService();
	__fastcall virtual ~TDefaultPlatformPropertiesService();
	virtual System::UnicodeString __fastcall ToString();
	void __fastcall SetValue(const System::UnicodeString AName, const System::Rtti::TValue &AValue);
	System::Rtti::TValue __fastcall GetValue(const System::UnicodeString AName, const System::Rtti::TValue &ADefaultValue);
private:
	void *__IFMXPlatformPropertiesService;	// IFMXPlatformPropertiesService 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {7CF49B46-FE43-4675-B386-244158474656}
	operator _di_IFMXPlatformPropertiesService()
	{
		_di_IFMXPlatformPropertiesService intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator IFMXPlatformPropertiesService*(void) { return (IFMXPlatformPropertiesService*)&__IFMXPlatformPropertiesService; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Metrics */
}	/* namespace Platform */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM_METRICS)
using namespace Fmx::Platform::Metrics;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PLATFORM)
using namespace Fmx::Platform;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Platform_MetricsHPP
