﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.InteractiveSelectors.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_InteractiveselectorsHPP
#define Fmx_Text_InteractiveselectorsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <System.UITypes.hpp>
#include <FMX.Objects.hpp>
#include <FMX.Text.SelectionController.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Text.TextEditor.hpp>
#include <FMX.Types.hpp>
#include <FMX.MagnifierGlass.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Interactiveselectors
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TInteractiveTextSelectors;
//-- type declarations -------------------------------------------------------
enum class DECLSPEC_DENUM TTextSelectorType : unsigned char { Left, Right, Caret, Unknown };

typedef void __fastcall (__closure *TSelectionEvent)(System::TObject* Sender, const TTextSelectorType AInitiator);

typedef void __fastcall (__closure *TSelectorChangedEvent)(System::TObject* Sender, const TTextSelectorType ASelector, const System::Types::TPointF &AContentPoint);

class PASCALIMPLEMENTATION TInteractiveTextSelectors : public System::TNoRefCountObject
{
	typedef System::TNoRefCountObject inherited;
	
public:
	static _DELPHI_CONST System::Int8 LoupeOffset = System::Int8(0xa);
	
	
private:
	Fmx::Controls::TStyledControl* FOwner;
	Fmx::Text::Texteditor::TTextEditor* FEditor;
	TTextSelectorType FActiveInitiator;
	bool FShouldPlaceLeftSelectionPointBelow;
	bool FLoupeEnabled;
	Fmx::Magnifierglass::_di_ILoupeService FLoupeService;
	Fmx::Objects::TSelectionPoint* FLeftSelector;
	Fmx::Objects::TSelectionPoint* FRightSelector;
	Fmx::Objects::TSelectionPoint* FCaretSelector;
	TSelectionEvent FOnBeginSelection;
	TSelectionEvent FOnEndSelection;
	TSelectorChangedEvent FOnSelectorPositionChanged;
	void __fastcall SetLoupeEnabled(const bool Value);
	void __fastcall SetShouldPlaceLeftSelectionPointBelow(const bool Value);
	void __fastcall SelectorMouseDownHandler(System::TObject* Sender, System::Uitypes::TMouseButton Button, System::Classes::TShiftState Shift, float X, float Y);
	void __fastcall SelectorMouseUpHandler(System::TObject* Sender, System::Uitypes::TMouseButton Button, System::Classes::TShiftState Shift, float X, float Y);
	void __fastcall LeftSelectorChangePositionHandler(System::TObject* Sender, float &X, float &Y);
	void __fastcall RightSelectorChangePositionHandler(System::TObject* Sender, float &X, float &Y);
	void __fastcall CaretSelectorChangePositionHandler(System::TObject* Sender, float &X, float &Y);
	
protected:
	virtual void __fastcall DoBeginSelection(const TTextSelectorType AInitiator);
	virtual void __fastcall DoEndSelection();
	virtual void __fastcall DoSelectorPositionChanged(const TTextSelectorType AInitiator, const System::Types::TPointF &AContentPoint);
	void __fastcall RealignCaretSelector();
	void __fastcall RealignSelectionSelectors();
	virtual System::Types::TPointF __fastcall GetCaretSelectorPosition();
	virtual System::Types::TPointF __fastcall GetLeftSelectorPosition();
	virtual System::Types::TPointF __fastcall GetRightSelectorPosition();
	bool __fastcall HasSelection();
	bool __fastcall IsVisibleInOwner(Fmx::Objects::TSelectionPoint* const ASelector);
	void __fastcall ShowLoupe();
	void __fastcall SetLoupePosition(const TTextSelectorType AInitiator)/* overload */;
	virtual bool __fastcall CanUseLoupe();
	void __fastcall FreeNotification(System::TObject* AObject);
	__property Fmx::Objects::TSelectionPoint* LeftSelector = {read=FLeftSelector};
	__property Fmx::Objects::TSelectionPoint* RightSelector = {read=FRightSelector};
	__property Fmx::Objects::TSelectionPoint* CaretSelector = {read=FCaretSelector};
	
public:
	__fastcall TInteractiveTextSelectors(Fmx::Controls::TStyledControl* const AOwner, Fmx::Text::Texteditor::TTextEditor* const ATextEditor);
	__fastcall virtual ~TInteractiveTextSelectors();
	void __fastcall Install();
	void __fastcall Uninstall();
	void __fastcall ApplyStyle();
	void __fastcall FreeStyle();
	void __fastcall Realign();
	bool __fastcall IsSupported();
	void __fastcall HideLoupe();
	void __fastcall SetLoupePosition(const float X, const float Y)/* overload */;
	__property TTextSelectorType ActiveInitiator = {read=FActiveInitiator, nodefault};
	__property bool LoupeEnabled = {read=FLoupeEnabled, write=SetLoupeEnabled, nodefault};
	__property bool ShouldPlaceLeftSelectionPointBelow = {read=FShouldPlaceLeftSelectionPointBelow, write=SetShouldPlaceLeftSelectionPointBelow, nodefault};
	__property Fmx::Controls::TStyledControl* Owner = {read=FOwner};
	__property Fmx::Text::Texteditor::TTextEditor* Editor = {read=FEditor};
	__property TSelectionEvent OnBeginSelection = {read=FOnBeginSelection, write=FOnBeginSelection};
	__property TSelectionEvent OnEndSelection = {read=FOnEndSelection, write=FOnEndSelection};
	__property TSelectorChangedEvent OnSelectorPositionChanged = {read=FOnSelectorPositionChanged, write=FOnSelectorPositionChanged};
private:
	void *__IFreeNotification;	// Fmx::Types::IFreeNotification 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {FEB50EAF-A3B9-4B37-8EDB-1EF9EE2F22D4}
	operator Fmx::Types::_di_IFreeNotification()
	{
		Fmx::Types::_di_IFreeNotification intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Types::IFreeNotification*(void) { return (Fmx::Types::IFreeNotification*)&__IFreeNotification; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Interactiveselectors */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_INTERACTIVESELECTORS)
using namespace Fmx::Text::Interactiveselectors;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_InteractiveselectorsHPP
