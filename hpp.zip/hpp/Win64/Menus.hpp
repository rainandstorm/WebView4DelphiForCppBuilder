//-- WARNING -----------------------------------------------------------------
// Deprecated legacy header
//----------------------------------------------------------------------------
#ifdef WARN_LEGACY_HEADER_USAGE
  #pragma message("Include <Vcl.Menus.hpp> instead")
#endif
#ifdef ERROR_LEGACY_HEADER_USAGE
  #error Include 'Vcl.Menus.hpp' instead
#endif

#include <Vcl.Menus.hpp>
