﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2WebResourceResponse.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2webresourceresponseHPP
#define Uwvcorewebview2webresourceresponseHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2webresourceresponse
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2WebResourceResponse;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2WebResourceResponse : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2WebResourceResponse FBaseIntf;
	bool __fastcall GetInitialized();
	_di_IStream __fastcall GetContent();
	Uwvtypelibrary::_di_ICoreWebView2HttpResponseHeaders __fastcall GetHeaders();
	int __fastcall GetStatusCode();
	Uwvtypes::wvstring __fastcall GetReasonPhrase();
	void __fastcall SetContent(const _di_IStream aContent);
	void __fastcall SetStatusCode(int aStatusCode);
	void __fastcall SetReasonPhrase(const Uwvtypes::wvstring aValue);
	
public:
	__fastcall TCoreWebView2WebResourceResponse(const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponse aBaseIntf);
	__fastcall virtual ~TCoreWebView2WebResourceResponse();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceResponse BaseIntf = {read=FBaseIntf};
	__property int StatusCode = {read=GetStatusCode, write=SetStatusCode, nodefault};
	__property Uwvtypes::wvstring ReasonPhrase = {read=GetReasonPhrase, write=SetReasonPhrase};
	__property _di_IStream Content = {read=GetContent, write=SetContent};
	__property Uwvtypelibrary::_di_ICoreWebView2HttpResponseHeaders Headers = {read=GetHeaders};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2webresourceresponse */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2WEBRESOURCERESPONSE)
using namespace Uwvcorewebview2webresourceresponse;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2webresourceresponseHPP
