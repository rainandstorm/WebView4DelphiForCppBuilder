﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Printer.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Printer_WinHPP
#define Fmx_Printer_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.WinSpool.hpp>
#include <Winapi.Messages.hpp>
#include <System.Classes.hpp>
#include <System.UITypes.hpp>
#include <FMX.Types.hpp>
#include <FMX.Canvas.GDIP.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Printer.hpp>
#include <FMX.Graphics.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Printer
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TPrinterWin;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TPrinterWin : public Fmx::Printer::TPrinter
{
	typedef Fmx::Printer::TPrinter inherited;
	
protected:
	int FPrinterIndex;
	System::Uitypes::TPrinterState FState;
	HDC FDC;
	Winapi::Windows::THandle FPrinterHandle;
	Winapi::Windows::PDeviceMode FDevMode;
	Winapi::Windows::THandle FDeviceMode;
	System::Uitypes::TPrinterOrientation FOrientation;
	System::Uitypes::TPrinterCapabilities FCapabilities;
	void __fastcall SetCanvasDefaultSettings();
	void __fastcall RefreshActivePrinter();
	virtual void __fastcall ActivePrinterChanged();
	virtual void __fastcall DoAbortDoc();
	virtual void __fastcall DoBeginDoc();
	virtual void __fastcall DoEndDoc();
	virtual void __fastcall DoNewPage();
	void __fastcall SetState(System::Uitypes::TPrinterState Value);
	virtual Fmx::Graphics::TCanvas* __fastcall GetCanvas();
	virtual System::Uitypes::TPrinterCapabilities __fastcall GetCapabilities();
	virtual int __fastcall GetNumCopies();
	HDC __fastcall GetHandle();
	virtual System::Uitypes::TPrinterOrientation __fastcall GetOrientation();
	virtual int __fastcall GetPageHeight();
	virtual int __fastcall GetPageWidth();
	virtual void __fastcall RefreshFonts();
	virtual void __fastcall RefreshPrinterDevices();
	void __fastcall SetPrinterCapabilities(int Value);
	virtual void __fastcall SetOrientation(System::Uitypes::TPrinterOrientation Value);
	virtual void __fastcall SetNumCopies(int Value);
	virtual void __fastcall SetDefaultPrinter();
	
public:
	__fastcall virtual TPrinterWin();
	__fastcall virtual ~TPrinterWin();
	HIDESBASE void __fastcall GetPrinter _DEPRECATED_ATTRIBUTE0 (System::WideChar * ADevice, System::WideChar * ADriver, System::WideChar * APort, Winapi::Windows::THandle &ADeviceMode)/* overload */;
	HIDESBASE void __fastcall GetPrinter(System::UnicodeString &ADevice, System::UnicodeString &ADriver, System::UnicodeString &APort, Winapi::Windows::THandle &ADeviceMode)/* overload */;
	void __fastcall SetPrinter _DEPRECATED_ATTRIBUTE0 (System::WideChar * ADevice, System::WideChar * ADriver, System::WideChar * APort, Winapi::Windows::THandle ADeviceMode)/* overload */;
	void __fastcall SetPrinter(System::UnicodeString ADevice, System::UnicodeString ADriver, System::UnicodeString APort, Winapi::Windows::THandle ADeviceMode)/* overload */;
	__property HDC Handle = {read=GetHandle};
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE Fmx::Printer::TPrinterClass __fastcall ActualPrinterClass(void);
}	/* namespace Win */
}	/* namespace Printer */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PRINTER_WIN)
using namespace Fmx::Printer::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_PRINTER)
using namespace Fmx::Printer;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Printer_WinHPP
