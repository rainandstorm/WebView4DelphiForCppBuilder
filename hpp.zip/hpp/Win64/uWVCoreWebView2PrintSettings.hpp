﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2PrintSettings.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2printsettingsHPP
#define Uwvcorewebview2printsettingsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2printsettings
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2PrintSettings;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2PrintSettings : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2PrintSettings FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2PrintSettings2 FBaseIntf2;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVPrintOrientation __fastcall GetOrientation();
	double __fastcall GetScaleFactor();
	double __fastcall GetPageWidth();
	double __fastcall GetPageHeight();
	double __fastcall GetMarginTop();
	double __fastcall GetMarginBottom();
	double __fastcall GetMarginLeft();
	double __fastcall GetMarginRight();
	bool __fastcall GetShouldPrintBackgrounds();
	bool __fastcall GetShouldPrintSelectionOnly();
	bool __fastcall GetShouldPrintHeaderAndFooter();
	Uwvtypes::wvstring __fastcall GetHeaderTitle();
	Uwvtypes::wvstring __fastcall GetFooterUri();
	Uwvtypes::wvstring __fastcall GetPageRanges();
	int __fastcall GetPagesPerSide();
	int __fastcall GetCopies();
	Uwvtypes::TWVPrintCollation __fastcall GetCollation();
	Uwvtypes::TWVPrintColorMode __fastcall GetColorMode();
	Uwvtypes::TWVPrintDuplex __fastcall GetDuplex();
	Uwvtypes::TWVPrintMediaSize __fastcall GetMediaSize();
	Uwvtypes::wvstring __fastcall GetPrinterName();
	void __fastcall SetOrientation(Uwvtypes::TWVPrintOrientation aValue);
	void __fastcall SetScaleFactor(const double aValue);
	void __fastcall SetPageWidth(const double aValue);
	void __fastcall SetPageHeight(const double aValue);
	void __fastcall SetMarginTop(const double aValue);
	void __fastcall SetMarginBottom(const double aValue);
	void __fastcall SetMarginLeft(const double aValue);
	void __fastcall SetMarginRight(const double aValue);
	void __fastcall SetShouldPrintBackgrounds(bool aValue);
	void __fastcall SetShouldPrintSelectionOnly(bool aValue);
	void __fastcall SetShouldPrintHeaderAndFooter(bool aValue);
	void __fastcall SetHeaderTitle(const Uwvtypes::wvstring aValue);
	void __fastcall SetFooterUri(const Uwvtypes::wvstring aValue);
	void __fastcall SetPageRanges(const Uwvtypes::wvstring aValue);
	void __fastcall SetPagesPerSide(int aValue);
	void __fastcall SetCopies(int aValue);
	void __fastcall SetCollation(Uwvtypes::TWVPrintCollation aValue);
	void __fastcall SetColorMode(Uwvtypes::TWVPrintColorMode aValue);
	void __fastcall SetDuplex(Uwvtypes::TWVPrintDuplex aValue);
	void __fastcall SetMediaSize(Uwvtypes::TWVPrintMediaSize aValue);
	void __fastcall SetPrinterName(const Uwvtypes::wvstring aValue);
	
public:
	__fastcall TCoreWebView2PrintSettings(const Uwvtypelibrary::_di_ICoreWebView2PrintSettings aBaseIntf);
	__fastcall virtual ~TCoreWebView2PrintSettings();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2PrintSettings BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVPrintOrientation Orientation = {read=GetOrientation, write=SetOrientation, nodefault};
	__property double ScaleFactor = {read=GetScaleFactor, write=SetScaleFactor};
	__property double PageWidth = {read=GetPageWidth, write=SetPageWidth};
	__property double PageHeight = {read=GetPageHeight, write=SetPageHeight};
	__property double MarginTop = {read=GetMarginTop, write=SetMarginTop};
	__property double MarginBottom = {read=GetMarginBottom, write=SetMarginBottom};
	__property double MarginLeft = {read=GetMarginLeft, write=SetMarginLeft};
	__property double MarginRight = {read=GetMarginRight, write=SetMarginRight};
	__property bool ShouldPrintBackgrounds = {read=GetShouldPrintBackgrounds, write=SetShouldPrintBackgrounds, nodefault};
	__property bool ShouldPrintSelectionOnly = {read=GetShouldPrintSelectionOnly, write=SetShouldPrintSelectionOnly, nodefault};
	__property bool ShouldPrintHeaderAndFooter = {read=GetShouldPrintHeaderAndFooter, write=SetShouldPrintHeaderAndFooter, nodefault};
	__property Uwvtypes::wvstring HeaderTitle = {read=GetHeaderTitle, write=SetHeaderTitle};
	__property Uwvtypes::wvstring FooterUri = {read=GetFooterUri, write=SetFooterUri};
	__property Uwvtypes::wvstring PageRanges = {read=GetPageRanges, write=SetPageRanges};
	__property int PagesPerSide = {read=GetPagesPerSide, write=SetPagesPerSide, nodefault};
	__property int Copies = {read=GetCopies, write=SetCopies, nodefault};
	__property Uwvtypes::TWVPrintCollation Collation = {read=GetCollation, write=SetCollation, nodefault};
	__property Uwvtypes::TWVPrintColorMode ColorMode = {read=GetColorMode, write=SetColorMode, nodefault};
	__property Uwvtypes::TWVPrintDuplex Duplex = {read=GetDuplex, write=SetDuplex, nodefault};
	__property Uwvtypes::TWVPrintMediaSize MediaSize = {read=GetMediaSize, write=SetMediaSize, nodefault};
	__property Uwvtypes::wvstring PrinterName = {read=GetPrinterName, write=SetPrinterName};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2printsettings */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2PRINTSETTINGS)
using namespace Uwvcorewebview2printsettings;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2printsettingsHPP
