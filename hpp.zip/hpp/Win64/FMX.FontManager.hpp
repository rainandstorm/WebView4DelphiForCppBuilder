﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.FontManager.pas' rev: 36.00 (Windows)

#ifndef Fmx_FontmanagerHPP
#define Fmx_FontmanagerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <System.SysUtils.hpp>
#include <System.UITypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Fontmanager
{
//-- forward type declarations -----------------------------------------------
struct TFontInfo;
__interface DELPHIINTERFACE IFMXFontManagerService;
typedef System::DelphiInterface<IFMXFontManagerService> _di_IFMXFontManagerService;
class DELPHICLASS TFontManager;
//-- type declarations -------------------------------------------------------
struct DECLSPEC_DRECORD TFontInfo
{
public:
	System::Uitypes::TFontName FamilyName;
};


__interface  INTERFACE_UUID("{2F494059-AFEF-4652-93BB-8DE03F41D822}") IFMXFontManagerService  : public System::IInterface 
{
	virtual bool __fastcall AddCustomFontFromFile(const System::Sysutils::TFileName AFileName) = 0 ;
	virtual bool __fastcall AddCustomFontFromResource(const System::UnicodeString AResourceName) = 0 ;
	virtual bool __fastcall AddCustomFontFromStream(System::Classes::TStream* const AStream) = 0 ;
	virtual bool __fastcall HasCustomFont(const System::Uitypes::TFontName AFontFamily) = 0 ;
	virtual bool __fastcall HasCustomFonts() = 0 ;
	virtual TFontInfo __fastcall GetCustomFontInfo(const int AIndex) = 0 ;
	virtual int __fastcall GetCustomFontInfoCount() = 0 ;
};

class PASCALIMPLEMENTATION TFontManager : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	static _di_IFMXFontManagerService __fastcall GetService();
	static TFontInfo __fastcall GetCustomFontInfo(const int AIndex);
	static int __fastcall GetCustomFontInfoCount();
	
public:
	__classmethod bool __fastcall AddCustomFontFromFile(const System::Sysutils::TFileName AFileName);
	__classmethod bool __fastcall AddCustomFontFromResource(const System::UnicodeString AResourceName);
	__classmethod bool __fastcall AddCustomFontFromStream(System::Classes::TStream* const AStream);
	__classmethod bool __fastcall HasCustomFont(const System::Uitypes::TFontName AFontFamily);
	__classmethod bool __fastcall HasCustomFonts();
	/* static */ __property TFontInfo CustomFontInfo[const int AIndex] = {read=GetCustomFontInfo};
	/* static */ __property int CustomFontInfoCount = {read=GetCustomFontInfoCount, nodefault};
	__classmethod bool __fastcall IsSupported();
	/* static */ __property _di_IFMXFontManagerService Service = {read=GetService};
public:
	/* TObject.Create */ inline __fastcall TFontManager() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TFontManager() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Fontmanager */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_FONTMANAGER)
using namespace Fmx::Fontmanager;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_FontmanagerHPP
