﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Certificate.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2certificateHPP
#define Uwvcorewebview2certificateHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2certificate
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Certificate;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2Certificate : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Certificate FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetSubject();
	Uwvtypes::wvstring __fastcall GetIssuer();
	System::TDateTime __fastcall GetValidFrom();
	System::TDateTime __fastcall GetValidTo();
	Uwvtypes::wvstring __fastcall GetDerEncodedSerialNumber();
	Uwvtypes::wvstring __fastcall GetDisplayName();
	Uwvtypelibrary::_di_ICoreWebView2StringCollection __fastcall GetPemEncodedIssuerCertificateChain();
	
public:
	__fastcall TCoreWebView2Certificate(const Uwvtypelibrary::_di_ICoreWebView2Certificate aBaseIntf);
	__fastcall virtual ~TCoreWebView2Certificate();
	Uwvtypes::wvstring __fastcall ToPemEncoding();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Certificate BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring Subject = {read=GetSubject};
	__property Uwvtypes::wvstring Issuer = {read=GetIssuer};
	__property System::TDateTime ValidFrom = {read=GetValidFrom};
	__property System::TDateTime ValidTo = {read=GetValidTo};
	__property Uwvtypes::wvstring DerEncodedSerialNumber = {read=GetDerEncodedSerialNumber};
	__property Uwvtypes::wvstring DisplayName = {read=GetDisplayName};
	__property Uwvtypelibrary::_di_ICoreWebView2StringCollection PemEncodedIssuerCertificateChain = {read=GetPemEncodedIssuerCertificateChain};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2certificate */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2CERTIFICATE)
using namespace Uwvcorewebview2certificate;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2certificateHPP
