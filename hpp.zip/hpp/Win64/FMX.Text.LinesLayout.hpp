﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.LinesLayout.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_LineslayoutHPP
#define Fmx_Text_LineslayoutHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <System.Generics.Collections.hpp>
#include <FMX.TextLayout.hpp>
#include <FMX.Graphics.hpp>
#include <FMX.Text.hpp>
#include <FMX.ScrollBox.Style.hpp>
#include <FMX.Types.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Lineslayout
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TLineObject;
class DELPHICLASS TLinesLayout;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TLineObject : public System::TObject
{
	typedef System::TObject inherited;
	
	
public:
	enum class DECLSPEC_DENUM TState : unsigned char { InvalidSize, InvalidPositionByX, InvalidPositionByY, InvalidLayout };
	
	typedef System::Set<TState, _DELPHI_SET_ENUMERATOR(TState::InvalidSize), _DELPHI_SET_ENUMERATOR(TState::InvalidLayout)> TStates;
	
	enum class DECLSPEC_DENUM TRenderingMode : unsigned char { MatchToLineTop, MatchLayoutToLineRect };
	
	
private:
	Fmx::Textlayout::TTextLayout* FLayout;
	System::Types::TRectF FRect;
	TStates FState;
	TRenderingMode FRenderingMode;
	void __fastcall SetRect(const System::Types::TRectF &Value);
	System::Types::TSizeF __fastcall GetSize();
	void __fastcall SetSize(const System::Types::TSizeF &Value);
	void __fastcall SetLocation(const System::Types::TPointF &Value);
	System::Types::TPointF __fastcall GetLocation();
	void __fastcall SetLayout(Fmx::Textlayout::TTextLayout* const Value);
	void __fastcall SetRenderingMode(const TRenderingMode Value);
	
protected:
	virtual void __fastcall DoRender(Fmx::Graphics::TCanvas* const ACanvas);
	void __fastcall UpdateLayoutTopLeft();
	
public:
	__fastcall TLineObject()/* overload */;
	__fastcall virtual ~TLineObject();
	void __fastcall ReleaseLayoutIfNotVisible(const System::Types::TRectF &AViewportRect);
	bool __fastcall IsVisible(const System::Types::TRectF &AViewportRect);
	bool __fastcall IsVerticallyIn(const System::Types::TRectF &AViewportRect);
	bool __fastcall IsInvalidPosition();
	bool __fastcall ContainsPoint(const System::Types::TPointF &AHitPoint);
	void __fastcall InvalidateSize();
	void __fastcall InvalidatePosition();
	void __fastcall InvalidateLayout();
	void __fastcall Invalidate();
	void __fastcall Render(Fmx::Graphics::TCanvas* const ACanvas);
	virtual System::UnicodeString __fastcall ToString();
	__property TStates State = {read=FState, nodefault};
	__property System::Types::TSizeF Size = {read=GetSize, write=SetSize};
	__property System::Types::TRectF Rect = {read=FRect, write=SetRect};
	__property TRenderingMode RenderingMode = {read=FRenderingMode, write=SetRenderingMode, nodefault};
	__property System::Types::TPointF Location = {read=GetLocation, write=SetLocation};
	__property Fmx::Textlayout::TTextLayout* Layout = {read=FLayout, write=SetLayout};
};


class PASCALIMPLEMENTATION TLinesLayout : public System::TObject
{
	typedef System::TObject inherited;
	
	
private:
	enum class DECLSPEC_DENUM TState : unsigned char { NeedAlignmentByX, NeedAlignmentByY, ContentSizeChanged };
	
	typedef System::Set<TState, _DELPHI_SET_ENUMERATOR(TState::NeedAlignmentByX), _DELPHI_SET_ENUMERATOR(TState::ContentSizeChanged)> TStates;
	
	
public:
	TLineObject* operator[](const int Index) { return this->Items[Index]; }
	
public:
	static _DELPHI_CONST System::WideChar DefaultMaskChar = (System::WideChar)(0x2a);
	
	static _DELPHI_CONST System::Int8 DefaultCaretWidth = System::Int8(0x1);
	
	static bool DebugDrawLinesBounds;
	static bool DebugDrawContentSize;
	
private:
	Fmx::Text::_di_ITextLinesSource FLinesSource;
	Fmx::Scrollbox::Style::_di_IScrollableContent FScrollableContent;
	float FLineHeight;
	System::Generics::Collections::TObjectList__1<TLineObject*>* FLines;
	System::Types::TRectF FViewportRect;
	System::Types::TSizeF FContentSize;
	bool FNeedMaskContent;
	System::WideChar FMaskChar;
	bool FIsRightToLeft;
	bool FIsMultiLineMode;
	TStates FState;
	int FUpdating;
	int FFirstVisibleLineIndex;
	int FLastVisibleLineIndex;
	Fmx::Graphics::TTextSettings* FTextSettings;
	float FCaretWidth;
	float FOpacity;
	void __fastcall SetOpacity(const float Value);
	void __fastcall SetTextSettings(Fmx::Graphics::TTextSettings* const Value);
	void __fastcall SetViewportRect(const System::Types::TRectF &Value);
	void __fastcall SetCaretWidth(const float Value);
	void __fastcall SetNeedMaskContent(const bool Value);
	void __fastcall SetMaskChar(const System::WideChar Value);
	void __fastcall SetIsRightToLeft(const bool Value);
	Fmx::Textlayout::TTextLayout* __fastcall CreateLayout(const int ALineIndex, const System::UnicodeString S);
	void __fastcall UpdateLayoutsColor();
	int __fastcall GetCount();
	TLineObject* __fastcall GetItem(const int Index);
	void __fastcall SetContentSize(const System::Types::TSizeF &AContentSize);
	Fmx::Types::TTextAlign __fastcall GetHorzAlignRTL();
	void __fastcall TextSettingsChanged(System::TObject* Sender);
	
protected:
	void __fastcall RefreshLineLayout(const int ALineIndex);
	virtual void __fastcall UpdateLayoutParams(const int ALineIndex, Fmx::Textlayout::TTextLayout* const ALayout);
	Fmx::Textlayout::TTextLayout* __fastcall CreateLineLayoutIfNotCreated(const int ALineIndex);
	void __fastcall CreateLayoutsForVisibleLinesIfNotCreated();
	void __fastcall CalculateLineSize(const int ALineIndex);
	void __fastcall CalculateLinesX();
	void __fastcall CalculateLineX(const int ALineIndex);
	void __fastcall CalculateLineY(const int ALineIndex);
	void __fastcall OffsetLinesYFrom(const int ALineIndex, const float AOffset);
	void __fastcall OffsetLinesLocationBetween(const int AStartLineIndex, const int AEndLineIndex, const float AOffsetY);
	Fmx::Text::TCaretPosition __fastcall GetCaretPositionByPointInLine(const int ALineIndex, const System::Types::TPointF &AHitPoint, const bool ARoundToWord = false);
	void __fastcall UpdateVisibleIndexes();
	void __fastcall MarkInvalidatePositionFrom(const int AFromIndex);
	void __fastcall MarkForRealign();
	virtual System::UnicodeString __fastcall ApplyMaskIfRequired(const System::UnicodeString AText);
	TLineObject::TRenderingMode __fastcall RenderingMode();
	
public:
	__fastcall TLinesLayout(const Fmx::Text::_di_ITextLinesSource ALineSource, const Fmx::Scrollbox::Style::_di_IScrollableContent AScrollableContent);
	__fastcall virtual ~TLinesLayout();
	void __fastcall BeginUpdate();
	void __fastcall EndUpdate();
	bool __fastcall IsUpdating();
	virtual void __fastcall InsertLine(const int AIndex, const System::UnicodeString ALine);
	virtual void __fastcall DeleteLine(const int AIndex);
	virtual void __fastcall ReplaceLine(const int AIndex, const System::UnicodeString ALine);
	virtual void __fastcall ExchangeLines(const int AOldIndex, const int ANewIndex);
	virtual void __fastcall Clear();
	float __fastcall GetLineHeight()/* overload */;
	float __fastcall GetLineHeight(const int AIndex)/* overload */;
	bool __fastcall IsWordWrap();
	bool __fastcall IsLeftAlignment();
	Fmx::Text::TCaretPosition __fastcall GetCaretPositionByPoint(const System::Types::TPointF &AHitPoint, const bool RoundToWord = false);
	System::Types::TPointF __fastcall GetPointByCaretPosition(const Fmx::Text::TCaretPosition &ACaretPosition);
	Fmx::Graphics::TRegion __fastcall GetRegionForRange(const Fmx::Text::TCaretPosition &ACaretPosition, const int ALength, const bool RoundToWord = false);
	void __fastcall Realign();
	void __fastcall RealignIfNeeded();
	void __fastcall Render(Fmx::Graphics::TCanvas* const ACanvas);
	__property TLineObject* Items[const int Index] = {read=GetItem/*, default*/};
	__property int Count = {read=GetCount, nodefault};
	__property int FirstVisibleLineIndex = {read=FFirstVisibleLineIndex, nodefault};
	__property int LastVisibleLineIndex = {read=FLastVisibleLineIndex, nodefault};
	__property Fmx::Types::TTextAlign HorzAlignRTL = {read=GetHorzAlignRTL, nodefault};
	__property bool IsMultiLine = {read=FIsMultiLineMode, write=FIsMultiLineMode, nodefault};
	__property bool IsRightToLeft = {read=FIsRightToLeft, write=SetIsRightToLeft, nodefault};
	__property System::WideChar MaskChar = {read=FMaskChar, write=SetMaskChar, nodefault};
	__property bool NeedMaskContent = {read=FNeedMaskContent, write=SetNeedMaskContent, nodefault};
	__property float CaretWidth = {read=FCaretWidth, write=SetCaretWidth};
	__property float Opacity = {read=FOpacity, write=SetOpacity};
	__property Fmx::Graphics::TTextSettings* TextSettings = {read=FTextSettings, write=SetTextSettings};
	__property System::Types::TSizeF ContentSize = {read=FContentSize};
	__property System::Types::TRectF ViewportRect = {read=FViewportRect, write=SetViewportRect};
	__property Fmx::Text::_di_ITextLinesSource LinesSource = {read=FLinesSource};
	__property Fmx::Scrollbox::Style::_di_IScrollableContent ScrollableContent = {read=FScrollableContent};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Lineslayout */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_LINESLAYOUT)
using namespace Fmx::Text::Lineslayout;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_LineslayoutHPP
