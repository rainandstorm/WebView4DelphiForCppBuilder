﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.IMERender.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_ImerenderHPP
#define Fmx_Text_ImerenderHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <System.UITypes.hpp>
#include <FMX.TextLayout.hpp>
#include <FMX.Text.hpp>
#include <FMX.Graphics.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Imerender
{
//-- forward type declarations -----------------------------------------------
struct TIMEParagraphLine;
class DELPHICLASS TIMETextLayout;
//-- type declarations -------------------------------------------------------
struct DECLSPEC_DRECORD TIMEParagraphLine
{
public:
	Fmx::Textlayout::TTextRange Range;
	System::Types::TRectF LineRect;
};


typedef System::DynamicArray<TIMEParagraphLine> TIMEParagraphLines;

class PASCALIMPLEMENTATION TIMETextLayout : public System::TObject
{
	typedef System::TObject inherited;
	
public:
	static _DELPHI_CONST System::Int8 MarkedTextBackgroundOpacity = System::Int8(0x1);
	
	static System::Uitypes::TAlphaColor DefaultDarkBackgroundColor;
	static System::Uitypes::TAlphaColor DefaultLightBackgroundColor;
	static _DELPHI_CONST System::Int8 DefaultBackgroundCornerRadius = System::Int8(0x0);
	
	static System::Types::TRectF DefaultExpandBackgroundMargins;
	static _DELPHI_CONST System::Int8 MaxThickness = System::Int8(0x4);
	
	
private:
	Fmx::Textlayout::TTextLayout* FTextLayout;
	float FFirstLineOffset;
	System::Types::TSizeF FMaxSize;
	System::Types::TPointF FTopLeft;
	System::UnicodeString FText;
	System::Uitypes::TAlphaColor FColor;
	float FOpacity;
	System::DynamicArray<Fmx::Text::TMarkedTextAttribute> FMarkedTextAttributes;
	System::Uitypes::TAlphaColor FLightBackgroundColor;
	System::Uitypes::TAlphaColor FDarkBackgroundColor;
	float FBackgroundCornerRadius;
	System::Types::TRectF FExpandBackgroundMargins;
	TIMEParagraphLines FLines;
	bool FNeedRecalculate;
	void __fastcall SetTopLeft(const System::Types::TPointF &Value);
	void __fastcall SetMaxSize(const System::Types::TSizeF &Value);
	void __fastcall SetText(const System::UnicodeString Value);
	Fmx::Graphics::TFont* __fastcall GetFont();
	void __fastcall SetFont(Fmx::Graphics::TFont* const Value);
	void __fastcall SetOpacity(const float Value);
	void __fastcall SetColor(const System::Uitypes::TAlphaColor Value);
	void __fastcall SetRightToLeft(const bool Value);
	bool __fastcall GetRightToLeft();
	TIMEParagraphLines __fastcall GetLines();
	System::Types::TRectF __fastcall GetBoundsRect();
	
protected:
	__classmethod Fmx::Graphics::TStrokeDash __fastcall MarkedTextAttributeToStrokeDash(const Fmx::Text::TMarkedTextAttribute AAttribute);
	__classmethod float __fastcall MarkedTextAttributeToThickness(const Fmx::Text::TMarkedTextAttribute AAttribute);
	Fmx::Textlayout::TTextRange __fastcall GetTextRangeFor(const System::Types::TRectF &ARegion);
	System::Types::TRectF __fastcall GetAbsoluteTextRectFor(const System::Types::TRectF &ARegion);
	void __fastcall RecalculateMetrics();
	virtual void __fastcall DrawBackground(Fmx::Graphics::TCanvas* const ACanvas);
	void __fastcall DrawLines(Fmx::Graphics::TCanvas* const ACanvas);
	virtual void __fastcall UnderlineLine(Fmx::Graphics::TCanvas* const ACanvas, const Fmx::Textlayout::TTextRange &ARange);
	virtual void __fastcall UnderlineRegion(Fmx::Graphics::TCanvas* const ACanvas, const Fmx::Graphics::TRegion ARegions, const bool ANeedAddSpace);
	virtual void __fastcall ApplyMarkedTextAttribute(Fmx::Graphics::TCanvas* const ACanvas, const Fmx::Text::TMarkedTextAttribute AAttribute);
	
public:
	__fastcall TIMETextLayout();
	__fastcall virtual ~TIMETextLayout();
	void __fastcall Render(Fmx::Graphics::TCanvas* const ACanvas);
	void __fastcall BeginUpdate();
	void __fastcall EndUpdate();
	System::Types::TPointF __fastcall GetPositionPoint(const int APos);
	__property System::Types::TRectF BoundsRect = {read=GetBoundsRect};
	__property System::UnicodeString Text = {read=FText, write=SetText};
	__property System::Types::TPointF TopLeft = {read=FTopLeft, write=SetTopLeft};
	__property System::Types::TSizeF MaxSize = {read=FMaxSize, write=SetMaxSize};
	__property System::DynamicArray<Fmx::Text::TMarkedTextAttribute> TextAttributes = {read=FMarkedTextAttributes, write=FMarkedTextAttributes};
	__property float FirstLineOffset = {read=FFirstLineOffset, write=FFirstLineOffset};
	__property Fmx::Graphics::TFont* Font = {read=GetFont, write=SetFont};
	__property System::Uitypes::TAlphaColor Color = {read=FColor, write=SetColor, nodefault};
	__property float Opacity = {read=FOpacity, write=SetOpacity};
	__property bool RightToLeft = {read=GetRightToLeft, write=SetRightToLeft, nodefault};
	__property TIMEParagraphLines Lines = {read=GetLines};
	__property float BackgroundCornerRadius = {read=FBackgroundCornerRadius, write=FBackgroundCornerRadius};
	__property System::Uitypes::TAlphaColor LightBackgroundColor = {read=FLightBackgroundColor, write=FLightBackgroundColor, nodefault};
	__property System::Uitypes::TAlphaColor DarkBackgroundColor = {read=FDarkBackgroundColor, write=FDarkBackgroundColor, nodefault};
	__property System::Types::TRectF ExpandBackgroundMargins = {read=FExpandBackgroundMargins, write=FExpandBackgroundMargins};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Imerender */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_IMERENDER)
using namespace Fmx::Text::Imerender;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_ImerenderHPP
