﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.MultiTouch.pas' rev: 36.00 (Windows)

#ifndef Fmx_MultitouchHPP
#define Fmx_MultitouchHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <System.Classes.hpp>
#include <System.Generics.Collections.hpp>
#include <FMX.Types.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Multitouch
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TMultiTouchManager;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TMultiTouchManager : public System::TNoRefCountObject
{
	typedef System::TNoRefCountObject inherited;
	
public:
	static System::Types::TPointF UndefinedPoint;
	static _DELPHI_CONST System::Int8 LongTaptreshold = System::Int8(0xa);
	
	
private:
	System::Classes::TComponent* FParent;
	System::Classes::TComponent* FGestureControl;
	System::Classes::TComponent* FTouchDownControl;
	Fmx::Types::TTouches FTouches;
	System::Generics::Collections::TDictionary__2<Fmx::Types::TInteractiveGesture,System::Classes::TComponent*>* FActiveGestures;
	Fmx::Types::TInteractiveGestures FActiveInteractiveGestures;
	Fmx::Types::TInteractiveGestures FEnabledInteractiveGestures;
	void __fastcall SetGestureControl(System::Classes::TComponent* const Value);
	void __fastcall SetTouchDownControl(System::Classes::TComponent* const Value);
	void __fastcall SetEnabledInteractiveGestures(const Fmx::Types::TInteractiveGestures Value);
	void __fastcall FreeNotification(System::TObject* AObject);
	
protected:
	System::Types::TPointF FFirstPointerDownCoordinates;
	System::Types::TPointF FFirstPointer;
	System::Types::TPointF FSecondPointer;
	System::Types::TPointF FOldPoint1;
	System::Types::TPointF FOldPoint2;
	float FRotationAngle;
	virtual void __fastcall TouchDown();
	virtual void __fastcall TouchUp();
	virtual void __fastcall TouchMove() = 0 ;
	virtual void __fastcall TouchCancel();
	__property System::Classes::TComponent* GestureControl = {read=FGestureControl, write=SetGestureControl};
	__property System::Classes::TComponent* TouchDownControl = {read=FTouchDownControl, write=SetTouchDownControl};
	bool __fastcall IsZoom(const System::Types::TPointF &APoint1, const System::Types::TPointF &APoint2);
	bool __fastcall IsRotate(const System::Types::TPointF &APoint1, const System::Types::TPointF &APoint2);
	virtual bool __fastcall SendCMGestureMessage(const Fmx::Types::TGestureEventInfo &AEventInfo);
	virtual Fmx::Types::TGestureEventInfo __fastcall CreateGestureEventInfo(const Fmx::Types::TInteractiveGesture AGesture, const bool AGestureEnded = false);
	void __fastcall CancelStandardGestures();
	bool __fastcall FindAndHandleInteractiveGesture(const Fmx::Types::TInteractiveGestures EffectiveGestureSet, const System::Types::TPointF &APoint, const bool AGestureStarted = false);
	void __fastcall BeginInteractiveGesture(const Fmx::Types::TInteractiveGesture AGesture, System::Classes::TComponent* const AControl);
	bool __fastcall EndInteractiveGesture(const Fmx::Types::TInteractiveGesture AGesture);
	void __fastcall CancelAllInteractiveGestures();
	
public:
	__fastcall virtual TMultiTouchManager(System::Classes::TComponent* const AParent);
	__fastcall virtual ~TMultiTouchManager();
	virtual void __fastcall HandleTouches(const Fmx::Types::TTouches ATouches, const Fmx::Types::TTouchAction Action, const Fmx::Types::_di_IControl Control);
	bool __fastcall IsActive(const Fmx::Types::TInteractiveGesture AGesture);
	bool __fastcall IsEnabled(const Fmx::Types::TInteractiveGesture AGesture);
	__property System::Classes::TComponent* Parent = {read=FParent, write=FParent};
	__property Fmx::Types::TInteractiveGestures ActiveInteractiveGestures = {read=FActiveInteractiveGestures, nodefault};
	__property Fmx::Types::TInteractiveGestures EnabledInteractiveGestures = {read=FEnabledInteractiveGestures, write=SetEnabledInteractiveGestures, nodefault};
	__property Fmx::Types::TTouches Touches = {read=FTouches};
private:
	void *__IFreeNotification;	// Fmx::Types::IFreeNotification 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {FEB50EAF-A3B9-4B37-8EDB-1EF9EE2F22D4}
	operator Fmx::Types::_di_IFreeNotification()
	{
		Fmx::Types::_di_IFreeNotification intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Fmx::Types::IFreeNotification*(void) { return (Fmx::Types::IFreeNotification*)&__IFreeNotification; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Multitouch */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_MULTITOUCH)
using namespace Fmx::Multitouch;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_MultitouchHPP
