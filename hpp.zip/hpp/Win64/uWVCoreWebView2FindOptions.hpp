﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2FindOptions.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2findoptionsHPP
#define Uwvcorewebview2findoptionsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2findoptions
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2FindOptions;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2FindOptions : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2FindOptions FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetFindTerm();
	bool __fastcall GetIsCaseSensitive();
	bool __fastcall GetShouldHighlightAllMatches();
	bool __fastcall GetShouldMatchWord();
	bool __fastcall GetSuppressDefaultFindDialog();
	void __fastcall SetFindTerm(const Uwvtypes::wvstring aValue);
	void __fastcall SetIsCaseSensitive(bool aValue);
	void __fastcall SetShouldHighlightAllMatches(bool aValue);
	void __fastcall SetShouldMatchWord(bool aValue);
	void __fastcall SetSuppressDefaultFindDialog(bool aValue);
	
public:
	__fastcall TCoreWebView2FindOptions(const Uwvtypelibrary::_di_ICoreWebView2FindOptions aBaseIntf);
	__fastcall virtual ~TCoreWebView2FindOptions();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2FindOptions BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring FindTerm = {read=GetFindTerm, write=SetFindTerm};
	__property bool IsCaseSensitive = {read=GetIsCaseSensitive, write=SetIsCaseSensitive, nodefault};
	__property bool ShouldHighlightAllMatches = {read=GetShouldHighlightAllMatches, write=SetShouldHighlightAllMatches, nodefault};
	__property bool ShouldMatchWord = {read=GetShouldMatchWord, write=SetShouldMatchWord, nodefault};
	__property bool SuppressDefaultFindDialog = {read=GetSuppressDefaultFindDialog, write=SetSuppressDefaultFindDialog, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2findoptions */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2FINDOPTIONS)
using namespace Uwvcorewebview2findoptions;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2findoptionsHPP
