﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2EnvironmentOptions.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2environmentoptionsHPP
#define Uwvcorewebview2environmentoptionsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2environmentoptions
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2EnvironmentOptions;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2EnvironmentOptions : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
protected:
	Uwvtypes::wvstring FAdditionalBrowserArguments;
	Uwvtypes::wvstring FLanguage;
	Uwvtypes::wvstring FTargetCompatibleBrowserVersion;
	bool FAllowSingleSignOnUsingOSPrimaryAccount;
	bool FExclusiveUserDataFolderAccess;
	bool FCustomCrashReportingEnabled;
	Uwvtypes::TWVCustomSchemeRegistrationArray FSchemeRegistrations;
	bool FEnableTrackingPrevention;
	bool FAreBrowserExtensionsEnabled;
	Uwvtypes::TWVChannelSearchKind FChannelSearchKind;
	Uwvtypes::TWVReleaseChannels FReleaseChannels;
	Uwvtypes::TWVScrollBarStyle FScrollBarStyle;
	HRESULT __stdcall Get_AdditionalBrowserArguments(/* out */ System::WideChar * &value);
	HRESULT __stdcall Set_AdditionalBrowserArguments(System::WideChar * value);
	HRESULT __stdcall Get_Language(/* out */ System::WideChar * &value);
	HRESULT __stdcall Set_Language(System::WideChar * value);
	HRESULT __stdcall Get_TargetCompatibleBrowserVersion(/* out */ System::WideChar * &value);
	HRESULT __stdcall Set_TargetCompatibleBrowserVersion(System::WideChar * value);
	HRESULT __stdcall Get_AllowSingleSignOnUsingOSPrimaryAccount(/* out */ int &allow);
	HRESULT __stdcall Set_AllowSingleSignOnUsingOSPrimaryAccount(int allow);
	HRESULT __stdcall Get_ExclusiveUserDataFolderAccess(/* out */ int &value);
	HRESULT __stdcall Set_ExclusiveUserDataFolderAccess(int value);
	HRESULT __stdcall Get_IsCustomCrashReportingEnabled(/* out */ int &value);
	HRESULT __stdcall Set_IsCustomCrashReportingEnabled(int value);
	HRESULT __stdcall GetCustomSchemeRegistrations(/* out */ unsigned &Count, /* out */ Uwvtypelibrary::PPCoreWebView2CustomSchemeRegistration &schemeRegistrations);
	HRESULT __stdcall SetCustomSchemeRegistrations(unsigned Count, Uwvtypelibrary::PPCoreWebView2CustomSchemeRegistration schemeRegistrations);
	HRESULT __stdcall Get_EnableTrackingPrevention(/* out */ int &value);
	HRESULT __stdcall Set_EnableTrackingPrevention(int value);
	HRESULT __stdcall Get_AreBrowserExtensionsEnabled(/* out */ int &value);
	HRESULT __stdcall Set_AreBrowserExtensionsEnabled(int value);
	HRESULT __stdcall Get_ChannelSearchKind(/* out */ Uwvtypelibrary::COREWEBVIEW2_CHANNEL_SEARCH_KIND &value);
	HRESULT __stdcall Set_ChannelSearchKind(Uwvtypelibrary::COREWEBVIEW2_CHANNEL_SEARCH_KIND value);
	HRESULT __stdcall Get_ReleaseChannels(/* out */ Uwvtypelibrary::COREWEBVIEW2_RELEASE_CHANNELS &value);
	HRESULT __stdcall Set_ReleaseChannels(Uwvtypelibrary::COREWEBVIEW2_RELEASE_CHANNELS value);
	HRESULT __stdcall Get_ScrollBarStyle(/* out */ Uwvtypelibrary::COREWEBVIEW2_SCROLLBAR_STYLE &value);
	HRESULT __stdcall Set_ScrollBarStyle(Uwvtypelibrary::COREWEBVIEW2_SCROLLBAR_STYLE value);
	void __fastcall DestroySchemeRegistrations();
	
public:
	__fastcall TCoreWebView2EnvironmentOptions(const Uwvtypes::wvstring aAdditionalBrowserArguments, const Uwvtypes::wvstring aLanguage, const Uwvtypes::wvstring aTargetCompatibleBrowserVersion, bool aAllowSingleSignOnUsingOSPrimaryAccount, bool aExclusiveUserDataFolderAccess, bool aCustomCrashReportingEnabled, const Uwvtypes::TWVCustomSchemeRegistrationArray aSchemeRegistrations, bool aEnableTrackingPrevention, bool aAreBrowserExtensionsEnabled, Uwvtypes::TWVChannelSearchKind aChannelSearchKind, Uwvtypes::TWVReleaseChannels aReleaseChannels, Uwvtypes::TWVScrollBarStyle aScrollBarStyle);
	__fastcall virtual ~TCoreWebView2EnvironmentOptions();
private:
	void *__ICoreWebView2EnvironmentOptions8;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions8 
	void *__ICoreWebView2EnvironmentOptions7;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions7 
	void *__ICoreWebView2EnvironmentOptions6;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions6 
	void *__ICoreWebView2EnvironmentOptions5;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions5 
	void *__ICoreWebView2EnvironmentOptions4;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions4 
	void *__ICoreWebView2EnvironmentOptions3;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions3 
	void *__ICoreWebView2EnvironmentOptions2;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions2 
	void *__ICoreWebView2EnvironmentOptions;	// Uwvtypelibrary::ICoreWebView2EnvironmentOptions 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {7C7ECF51-E918-5CAF-853C-E9A2BCC27775}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions8()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions8 intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions8*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions8*)&__ICoreWebView2EnvironmentOptions8; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {C48D539F-E39F-441C-AE68-1F66E570BDC5}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions7()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions7 intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions7*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions7*)&__ICoreWebView2EnvironmentOptions7; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {57D29CC3-C84F-42A0-B0E2-EFFBD5E179DE}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions6()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions6 intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions6*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions6*)&__ICoreWebView2EnvironmentOptions6; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {0AE35D64-C47F-4464-814E-259C345D1501}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions5()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions5 intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions5*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions5*)&__ICoreWebView2EnvironmentOptions5; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {AC52D13F-0D38-475A-9DCA-876580D6793E}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions4()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions4 intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions4*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions4*)&__ICoreWebView2EnvironmentOptions4; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {4A5C436E-A9E3-4A2E-89C3-910D3513F5CC}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions3()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions3 intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions3*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions3*)&__ICoreWebView2EnvironmentOptions3; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {FF85C98A-1BA7-4A6B-90C8-2B752C89E9E2}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions2()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions2 intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions2*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions2*)&__ICoreWebView2EnvironmentOptions2; }
	#endif
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {2FDE08A8-1E9A-4766-8C05-95A9CEB9D1C5}
	operator Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions()
	{
		Uwvtypelibrary::_di_ICoreWebView2EnvironmentOptions intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator Uwvtypelibrary::ICoreWebView2EnvironmentOptions*(void) { return (Uwvtypelibrary::ICoreWebView2EnvironmentOptions*)&__ICoreWebView2EnvironmentOptions; }
	#endif
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2environmentoptions */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2ENVIRONMENTOPTIONS)
using namespace Uwvcorewebview2environmentoptions;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2environmentoptionsHPP
