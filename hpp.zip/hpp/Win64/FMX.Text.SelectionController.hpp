﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Text.SelectionController.pas' rev: 36.00 (Windows)

#ifndef Fmx_Text_SelectioncontrollerHPP
#define Fmx_Text_SelectioncontrollerHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <FMX.Text.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Text
{
namespace Selectioncontroller
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TSelectionController;
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TSelectionChangedEvent)(System::TObject* Sender, const int ASelStart, const int ALength);

class PASCALIMPLEMENTATION TSelectionController : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Fmx::Text::_di_ITextLinesSource FLineSource;
	Fmx::Text::TCaretPosition FSelStart;
	Fmx::Text::TCaretPosition FSelFinish;
	Fmx::Text::TCaretPosition FHoldSelBegin;
	Fmx::Text::TCaretPosition FHoldSelEnd;
	TSelectionChangedEvent FOnChanged;
	void __fastcall SetSelStart(const Fmx::Text::TCaretPosition &Value);
	void __fastcall SetSelFinish(const Fmx::Text::TCaretPosition &Value);
	void __fastcall SetLength(const int Value);
	int __fastcall GetLength();
	int __fastcall GetSelLength();
	
protected:
	virtual void __fastcall DoSelectionChanged();
	
public:
	__fastcall TSelectionController(const Fmx::Text::_di_ITextLinesSource ALineSource);
	__fastcall virtual ~TSelectionController();
	void __fastcall SetRange(const Fmx::Text::TCaretPosition &ASelStart, const Fmx::Text::TCaretPosition &ASelEnd)/* overload */;
	void __fastcall SetRange(const int AStartPos, const int ALength)/* overload */;
	void __fastcall Reset();
	bool __fastcall IsSelected();
	Fmx::Text::TCaretPosition __fastcall SelBegin();
	int __fastcall BeginPos();
	Fmx::Text::TCaretPosition __fastcall SelEnd();
	int __fastcall EndPos();
	__property int SelLength = {read=GetSelLength, nodefault};
	void __fastcall HoldSelection();
	void __fastcall UnholdSelection();
	__property Fmx::Text::TCaretPosition HoldSelBegin = {read=FHoldSelBegin};
	__property Fmx::Text::TCaretPosition HoldSelEnd = {read=FHoldSelEnd};
	virtual System::UnicodeString __fastcall ToString();
	__property Fmx::Text::TCaretPosition Start = {read=FSelStart, write=SetSelStart};
	__property Fmx::Text::TCaretPosition Finish = {read=FSelFinish, write=SetSelFinish};
	__property int Length = {read=GetLength, write=SetLength, nodefault};
	__property TSelectionChangedEvent OnChanged = {read=FOnChanged, write=FOnChanged};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Selectioncontroller */
}	/* namespace Text */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT_SELECTIONCONTROLLER)
using namespace Fmx::Text::Selectioncontroller;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_TEXT)
using namespace Fmx::Text;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Text_SelectioncontrollerHPP
