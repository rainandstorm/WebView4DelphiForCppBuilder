﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Notification.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2notificationHPP
#define Uwvcorewebview2notificationHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2notification
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Notification;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2Notification : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Notification FBaseIntf;
	Uwvtypelibrary::EventRegistrationToken FCloseRequestedToken;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetBody();
	Uwvtypes::TWVTextDirectionKind __fastcall GetDirection();
	Uwvtypes::wvstring __fastcall GetLanguage();
	Uwvtypes::wvstring __fastcall GetTag();
	Uwvtypes::wvstring __fastcall GetIconUri();
	Uwvtypes::wvstring __fastcall GetTitle();
	Uwvtypes::wvstring __fastcall GetBadgeUri();
	Uwvtypes::wvstring __fastcall GetBodyImageUri();
	bool __fastcall GetShouldRenotify();
	bool __fastcall GetRequiresInteraction();
	bool __fastcall GetIsSilent();
	System::TDateTime __fastcall GetTimestamp();
	Uwvtypelibrary::Uint64Array __fastcall GetVibrationPattern();
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddCloseRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2Notification(const Uwvtypelibrary::_di_ICoreWebView2Notification aBaseIntf);
	__fastcall virtual ~TCoreWebView2Notification();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall ReportShown();
	bool __fastcall ReportClicked();
	bool __fastcall ReportClosed();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Notification BaseIntf = {read=FBaseIntf, write=FBaseIntf};
	__property Uwvtypes::wvstring Body = {read=GetBody};
	__property Uwvtypes::TWVTextDirectionKind Direction = {read=GetDirection, nodefault};
	__property Uwvtypes::wvstring Language = {read=GetLanguage};
	__property Uwvtypes::wvstring Tag = {read=GetTag};
	__property Uwvtypes::wvstring IconUri = {read=GetIconUri};
	__property Uwvtypes::wvstring Title = {read=GetTitle};
	__property Uwvtypes::wvstring BadgeUri = {read=GetBadgeUri};
	__property Uwvtypes::wvstring BodyImageUri = {read=GetBodyImageUri};
	__property bool ShouldRenotify = {read=GetShouldRenotify, nodefault};
	__property bool RequiresInteraction = {read=GetRequiresInteraction, nodefault};
	__property bool IsSilent = {read=GetIsSilent, nodefault};
	__property System::TDateTime Timestamp = {read=GetTimestamp};
	__property Uwvtypelibrary::Uint64Array VibrationPattern = {read=GetVibrationPattern};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2notification */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2NOTIFICATION)
using namespace Uwvcorewebview2notification;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2notificationHPP
