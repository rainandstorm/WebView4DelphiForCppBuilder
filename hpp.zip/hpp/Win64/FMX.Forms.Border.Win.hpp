﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Forms.Border.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Forms_Border_WinHPP
#define Fmx_Forms_Border_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <System.Classes.hpp>
#include <System.Generics.Collections.hpp>
#include <Winapi.Messages.hpp>
#include <Winapi.Windows.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Types.hpp>
#include <FMX.Forms.Border.hpp>
#include <FMX.Controls.hpp>
#include <FMX.Menus.hpp>
#include <FMX.Graphics.hpp>
#include <FMX.Helpers.Win.hpp>
#include <System.SysUtils.hpp>
#include <System.Generics.Defaults.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Forms
{
namespace Border
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWinWindowBorder;
class DELPHICLASS TWinBuffer;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TWinWindowBorder : public Fmx::Forms::Border::TStyledWindowBorder
{
	typedef Fmx::Forms::Border::TStyledWindowBorder inherited;
	
	
public:
	enum class DECLSPEC_DENUM TWindowElement : unsigned char { Caption, LeftBorder, RightBorder, BottomBorder, ClientArea, TopLeftSizingArea, TopSizingArea, TopRightSizingArea, LeftSizingArea, RightSizingArea, BottomleftSizingArea, BottomSizingArea, BottomRightSizingArea };
	
	
private:
	enum class DECLSPEC_DENUM TNCElement : unsigned char { Caption, LeftBorder, RightBorder, BottomBorder };
	
	
private:
	System::StaticArray<TWinBuffer*, 4> FBuffers;
	bool FNCClick;
	int FUpdating;
	Fmx::Controls::TControl* FBottomBorder;
	Fmx::Controls::TControl* FLeftBorder;
	Fmx::Controls::TControl* FRightBorder;
	System::Types::TRectF FSavedCaptionPadding;
	System::Types::TPointF FSavedIconPos;
	System::Types::TPointF FSavedTitleMargins;
	Fmx::Graphics::TCanvas* FCurrentCanvas;
	Winapi::Windows::THandle FIcon;
	Fmx::Menus::TMenuBar* FMenuBar;
	System::Generics::Collections::TDictionary__2<unsigned __int64,Fmx::Menus::TMenuItem*>* FMenuMap;
	Fmx::Types::TTimer* FMouseLeaveTimer;
	void __fastcall UpdateButtonsState();
	void __fastcall UpdateBuffersSizes();
	TWinBuffer* __fastcall GetBuffer(const TNCElement AIndex);
	System::Types::TSize __fastcall GetWndSize();
	HWND __fastcall GetWnd();
	Winapi::Windows::TRect __fastcall GetWndElementBounds(const TWindowElement AIndex);
	Winapi::Windows::TRect __fastcall GetWndOverlapScreenFormThickness();
	Winapi::Windows::TRect __fastcall GetWndDefaultFrameResizeThickness();
	Winapi::Windows::TRect __fastcall GetWndClientMargins();
	float __fastcall GetTopOffset();
	System::Types::TRectF __fastcall GetDefaultFrameThickness();
	float __fastcall GetScale();
	void __fastcall InvalidateRegion();
	void __fastcall RecreateRegion();
	void __fastcall Paint();
	void __fastcall PaintCaption(const HDC DC);
	void __fastcall PaintBottom(const HDC DC);
	void __fastcall PaintLeft(const HDC DC);
	void __fastcall PaintRight(const HDC DC);
	MESSAGE void __fastcall WMNCCalcSize(Winapi::Messages::TWMNCCalcSize &Message);
	MESSAGE void __fastcall WMNCHitTest(Winapi::Messages::TWMNCHitTest &Message);
	MESSAGE void __fastcall WMNCMouseMove(Winapi::Messages::TWMNCMouseMove &Message);
	MESSAGE void __fastcall WMNCLButtonDown(Winapi::Messages::TWMNCLButtonDown &Message);
	MESSAGE void __fastcall WMNCLButtonUp(Winapi::Messages::TWMNCLButtonUp &Message);
	MESSAGE void __fastcall WMNCActivate(Winapi::Messages::TWMNCActivate &Message);
	MESSAGE void __fastcall WMNCPaint(Winapi::Messages::TWMNCPaint &Message);
	MESSAGE void __fastcall WMNCMouseLeave(Winapi::Messages::TMessage &Message);
	MESSAGE void __fastcall WMNCAddUpdateRect(Winapi::Messages::TMessage &Message);
	MESSAGE void __fastcall WMLButtonUp(Winapi::Messages::TWMLButtonUp &Message);
	MESSAGE void __fastcall WMMouseMove(Winapi::Messages::TWMMouseMove &Message);
	MESSAGE void __fastcall WMMouseLeave(Winapi::Messages::TMessage &Message);
	void __fastcall MouseLeaveCheckHandler(System::TObject* Sender);
	
protected:
	virtual void __fastcall EnableChanged();
	virtual System::Types::TSizeF __fastcall GetFormSize();
	virtual void __fastcall Resize();
	virtual System::Types::TRectF __fastcall GetClientMargins();
	void __fastcall RealignMenuBar();
	void __fastcall WindowFrameCouldChanged();
	virtual void __fastcall ApplyStyle();
	virtual void __fastcall FreeStyle();
	virtual void __fastcall StyleChanged();
	virtual System::UnicodeString __fastcall GetStyleLookup();
	bool __fastcall IsOldStyleStructure();
	virtual void __fastcall DoPaint _DEPRECATED_ATTRIBUTE1("Override PaintNC instead.") ();
	virtual void __fastcall PaintNC();
	virtual void __fastcall Invalidate();
	virtual void __fastcall DoAddUpdateRect(const System::Types::TRectF &R);
	virtual Fmx::Graphics::TCanvas* __fastcall GetCanvas();
	__property TWinBuffer* LeftBuffer = {read=GetBuffer, index=1};
	__property TWinBuffer* RightBuffer = {read=GetBuffer, index=2};
	__property TWinBuffer* CaptionBuffer = {read=GetBuffer, index=0};
	__property TWinBuffer* BottomBuffer = {read=GetBuffer, index=3};
	
public:
	__fastcall virtual TWinWindowBorder(Fmx::Forms::TCommonCustomForm* const AForm);
	__fastcall virtual ~TWinWindowBorder();
	void __fastcall CreateOSMenu(const Fmx::Types::_di_IItemsContainer AMenu);
	bool __fastcall HandleExists(const Fmx::Types::TFmxHandle Handle);
	void __fastcall RemoveHandle(const Fmx::Types::TFmxHandle Handle);
	void __fastcall BeginUpdate();
	void __fastcall EndUpdate();
	bool __fastcall IsUpdating();
	__property bool NCClick = {read=FNCClick, nodefault};
	__property float Scale = {read=GetScale};
	__property System::Types::TSize WndSize = {read=GetWndSize};
	__property HWND Wnd = {read=GetWnd};
	__property Winapi::Windows::TRect WndClientMargins = {read=GetWndClientMargins};
	__property Winapi::Windows::TRect WndElementBounds[const TWindowElement AIndex] = {read=GetWndElementBounds};
};


typedef TWinWindowBorder TWindowBorderWin;

class PASCALIMPLEMENTATION TWinBuffer : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	Fmx::Graphics::TBitmap* FBitmap;
	HDC FBitmapDC;
	HBITMAP FBitmapHandle;
	void *FData;
	float __fastcall GetScale();
	void __fastcall SetScale(const float Value);
	float __fastcall GetLogicalWidth();
	float __fastcall GetLogicalHeight();
	int __fastcall GetHeight();
	int __fastcall GetWidth();
	Fmx::Graphics::TCanvas* __fastcall GetCanvas();
	
protected:
	void __fastcall FillBitmapInfo(Winapi::Windows::TBitmapInfo &BitmapInfo, const int Width, const int Height);
	
public:
	__fastcall TWinBuffer();
	__fastcall virtual ~TWinBuffer();
	void __fastcall SetSize(const System::Types::TSize &ASize);
	bool __fastcall IsAllocated();
	void __fastcall CopyFMXBitmapToWinBitmap();
	void __fastcall Paint(const HDC DC, const Winapi::Windows::TPoint &ADestPos, const Winapi::Windows::TPoint &ASrcPoint);
	__property float LogicalWidth = {read=GetLogicalWidth};
	__property float LogicalHeight = {read=GetLogicalHeight};
	__property int Width = {read=GetWidth, nodefault};
	__property int Height = {read=GetHeight, nodefault};
	__property Fmx::Graphics::TCanvas* Canvas = {read=GetCanvas};
	__property HDC BitmapDC = {read=FBitmapDC};
	__property System::Types::TSize Size = {write=SetSize};
	__property float Scale = {read=GetScale, write=SetScale};
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE __int64 __fastcall WMNCMessages(Fmx::Forms::TCommonCustomForm* AForm, unsigned uMsg, unsigned __int64 wParam, __int64 lParam);
extern DELPHI_PACKAGE Fmx::Forms::TWindowBorder* __fastcall CreateWindowBorder _DEPRECATED_ATTRIBUTE1("Use TWinWindowBorder.Create instead") (Fmx::Forms::TCommonCustomForm* const AForm);
}	/* namespace Win */
}	/* namespace Border */
}	/* namespace Forms */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_FORMS_BORDER_WIN)
using namespace Fmx::Forms::Border::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_FORMS_BORDER)
using namespace Fmx::Forms::Border;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_FORMS)
using namespace Fmx::Forms;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Forms_Border_WinHPP
