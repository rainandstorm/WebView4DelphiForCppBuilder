//-- WARNING -----------------------------------------------------------------
// Deprecated legacy header
//----------------------------------------------------------------------------
#ifdef WARN_LEGACY_HEADER_USAGE
  #pragma message("Include <Vcl.Consts.hpp> instead")
#endif
#ifdef ERROR_LEGACY_HEADER_USAGE
  #error Include 'Vcl.Consts.hpp' instead
#endif

#include <Vcl.Consts.hpp>
