﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.WebBrowser.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Webbrowser_WinHPP
#define Fmx_Webbrowser_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Webbrowser
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TGlobalEdgeBrowserSettings;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TGlobalEdgeBrowserSettings : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	static System::UnicodeString FBrowserExecutableFolder;
	static System::UnicodeString FUserDataFolder;
	
public:
	/* static */ __property System::UnicodeString BrowserExecutableFolder = {read=FBrowserExecutableFolder, write=FBrowserExecutableFolder};
	/* static */ __property System::UnicodeString UserDataFolder = {read=FUserDataFolder, write=FUserDataFolder};
	
private:
	// __classmethod void __fastcall Create@();
	// __classmethod void __fastcall Destroy@();
public:
	/* TObject.Create */ inline __fastcall TGlobalEdgeBrowserSettings() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TGlobalEdgeBrowserSettings() { }
	
};


//-- var, const, procedure ---------------------------------------------------
extern DELPHI_PACKAGE void __fastcall RegisterWebBrowserService(void);
extern DELPHI_PACKAGE void __fastcall UnRegisterWebBrowserService(void);
}	/* namespace Win */
}	/* namespace Webbrowser */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_WEBBROWSER_WIN)
using namespace Fmx::Webbrowser::Win;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_WEBBROWSER)
using namespace Fmx::Webbrowser;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Webbrowser_WinHPP
