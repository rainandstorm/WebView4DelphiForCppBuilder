﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2SharedBuffer.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2sharedbufferHPP
#define Uwvcorewebview2sharedbufferHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2sharedbuffer
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2SharedBuffer;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2SharedBuffer : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2SharedBuffer FBaseIntf;
	bool __fastcall GetInitialized();
	unsigned __int64 __fastcall GetSize();
	System::PByte __fastcall GetBuffer();
	_di_IStream __fastcall GetOpenStream();
	Uwvtypelibrary::HANDLE __fastcall GetFileMappingHandle();
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2SharedBuffer(const Uwvtypelibrary::_di_ICoreWebView2SharedBuffer aBaseIntf);
	__fastcall virtual ~TCoreWebView2SharedBuffer();
	bool __fastcall Close();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2SharedBuffer BaseIntf = {read=FBaseIntf};
	__property unsigned __int64 Size = {read=GetSize};
	__property System::PByte Buffer = {read=GetBuffer};
	__property _di_IStream OpenStream = {read=GetOpenStream};
	__property Uwvtypelibrary::HANDLE FileMappingHandle = {read=GetFileMappingHandle};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2sharedbuffer */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2SHAREDBUFFER)
using namespace Uwvcorewebview2sharedbuffer;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2sharedbufferHPP
