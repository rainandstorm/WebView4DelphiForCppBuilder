﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Args.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2argsHPP
#define Uwvcorewebview2argsHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Types.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2args
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2AcceleratorKeyPressedEventArgs;
class DELPHICLASS TCoreWebView2ContentLoadingEventArgs;
class DELPHICLASS TCoreWebView2DevToolsProtocolEventReceivedEventArgs;
class DELPHICLASS TCoreWebView2MoveFocusRequestedEventArgs;
class DELPHICLASS TCoreWebView2NavigationCompletedEventArgs;
class DELPHICLASS TCoreWebView2NavigationStartingEventArgs;
class DELPHICLASS TCoreWebView2NewWindowRequestedEventArgs;
class DELPHICLASS TCoreWebView2PermissionRequestedEventArgs;
class DELPHICLASS TCoreWebView2ProcessFailedEventArgs;
class DELPHICLASS TCoreWebView2ScriptDialogOpeningEventArgs;
class DELPHICLASS TCoreWebView2SourceChangedEventArgs;
class DELPHICLASS TCoreWebView2WebMessageReceivedEventArgs;
class DELPHICLASS TCoreWebView2WebResourceRequestedEventArgs;
class DELPHICLASS TCoreWebView2BrowserProcessExitedEventArgs;
class DELPHICLASS TCoreWebView2WebResourceResponseReceivedEventArgs;
class DELPHICLASS TCoreWebView2DOMContentLoadedEventArgs;
class DELPHICLASS TCoreWebView2FrameCreatedEventArgs;
class DELPHICLASS TCoreWebView2DownloadStartingEventArgs;
class DELPHICLASS TCoreWebView2ClientCertificateRequestedEventArgs;
class DELPHICLASS TCoreWebView2BasicAuthenticationRequestedEventArgs;
class DELPHICLASS TCoreWebView2ContextMenuRequestedEventArgs;
class DELPHICLASS TCoreWebView2ServerCertificateErrorDetectedEventArgs;
class DELPHICLASS TCoreWebView2LaunchingExternalUriSchemeEventArgs;
class DELPHICLASS TCoreWebView2NonClientRegionChangedEventArgs;
class DELPHICLASS TCoreWebView2NotificationReceivedEventArgs;
class DELPHICLASS TCoreWebView2SaveAsUIShowingEventArgs;
class DELPHICLASS TCoreWebView2SaveFileSecurityCheckStartingEventArgs;
class DELPHICLASS TCoreWebView2ScreenCaptureStartingEventArgs;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2AcceleratorKeyPressedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventArgs2 FBaseIntf2;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVKeyEventKind __fastcall GetKeyEventKind();
	System::LongWord __fastcall GetVirtualKey();
	int __fastcall GetKeyEventLParam();
	bool __fastcall GetHandled();
	System::LongWord __fastcall GetRepeatCount();
	System::LongWord __fastcall GetScanCode();
	bool __fastcall GetIsExtendedKey();
	bool __fastcall GetIsMenuKeyDown();
	bool __fastcall GetWasKeyDown();
	bool __fastcall GetIsKeyReleased();
	bool __fastcall GetIsBrowserAcceleratorKeyEnabled();
	void __fastcall SetHandled(bool aValue);
	void __fastcall SetIsBrowserAcceleratorKeyEnabled(bool aValue);
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2AcceleratorKeyPressedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2AcceleratorKeyPressedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2AcceleratorKeyPressedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVKeyEventKind KeyEventKind = {read=GetKeyEventKind, nodefault};
	__property System::LongWord VirtualKey = {read=GetVirtualKey, nodefault};
	__property int KeyEventLParam = {read=GetKeyEventLParam, nodefault};
	__property System::LongWord RepeatCount = {read=GetRepeatCount, nodefault};
	__property System::LongWord ScanCode = {read=GetScanCode, nodefault};
	__property bool IsExtendedKey = {read=GetIsExtendedKey, nodefault};
	__property bool IsMenuKeyDown = {read=GetIsMenuKeyDown, nodefault};
	__property bool WasKeyDown = {read=GetWasKeyDown, nodefault};
	__property bool IsKeyReleased = {read=GetIsKeyReleased, nodefault};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property bool IsBrowserAcceleratorKeyEnabled = {read=GetIsBrowserAcceleratorKeyEnabled, write=SetIsBrowserAcceleratorKeyEnabled, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2ContentLoadingEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	bool __fastcall GetIsErrorPage();
	unsigned __int64 __fastcall GetNavigationId();
	
public:
	__fastcall TCoreWebView2ContentLoadingEventArgs(const Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2ContentLoadingEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ContentLoadingEventArgs BaseIntf = {read=FBaseIntf};
	__property bool IsErrorPage = {read=GetIsErrorPage, nodefault};
	__property unsigned __int64 NavigationId = {read=GetNavigationId};
};


class PASCALIMPLEMENTATION TCoreWebView2DevToolsProtocolEventReceivedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventArgs2 FBaseIntf2;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetParameterObjectAsJson();
	Uwvtypes::wvstring __fastcall GetSessionId();
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2DevToolsProtocolEventReceivedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2DevToolsProtocolEventReceivedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2DevToolsProtocolEventReceivedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring ParameterObjectAsJson = {read=GetParameterObjectAsJson};
	__property Uwvtypes::wvstring SessionId = {read=GetSessionId};
};


class PASCALIMPLEMENTATION TCoreWebView2MoveFocusRequestedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVMoveFocusReason __fastcall GetReason();
	bool __fastcall GetHandled();
	void __fastcall SetHandled(bool aValue);
	
public:
	__fastcall TCoreWebView2MoveFocusRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2MoveFocusRequestedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2MoveFocusRequestedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVMoveFocusReason Reason = {read=GetReason, nodefault};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2NavigationCompletedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs2 FBaseIntf2;
	bool __fastcall GetInitialized();
	bool __fastcall GetIsSuccess();
	Uwvtypes::TWVWebErrorStatus __fastcall GetWebErrorStatus();
	unsigned __int64 __fastcall GetNavigationID();
	int __fastcall GetHttpStatusCode();
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2NavigationCompletedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2NavigationCompletedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2NavigationCompletedEventArgs BaseIntf = {read=FBaseIntf};
	__property bool IsSuccess = {read=GetIsSuccess, nodefault};
	__property Uwvtypes::TWVWebErrorStatus WebErrorStatus = {read=GetWebErrorStatus, nodefault};
	__property unsigned __int64 NavigationID = {read=GetNavigationID};
	__property int HttpStatusCode = {read=GetHttpStatusCode, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2NavigationStartingEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs3 FBaseIntf3;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetURI();
	bool __fastcall GetIsUserInitiated();
	bool __fastcall GetIsRedirected();
	bool __fastcall GetCancel();
	unsigned __int64 __fastcall GetNavigationID();
	Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders __fastcall GetRequestHeaders();
	Uwvtypes::wvstring __fastcall GetAdditionalAllowedFrameAncestors();
	Uwvtypes::TWVNavigationKind __fastcall GetNavigationKind();
	void __fastcall SetAdditionalAllowedFrameAncestors(const Uwvtypes::wvstring aValue);
	void __fastcall SetCancel(bool aValue);
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2NavigationStartingEventArgs(const Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2NavigationStartingEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2NavigationStartingEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring URI = {read=GetURI};
	__property bool IsUserInitiated = {read=GetIsUserInitiated, nodefault};
	__property bool IsRedirected = {read=GetIsRedirected, nodefault};
	__property bool Cancel = {read=GetCancel, write=SetCancel, nodefault};
	__property unsigned __int64 NavigationID = {read=GetNavigationID};
	__property Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders RequestHeaders = {read=GetRequestHeaders};
	__property Uwvtypes::wvstring AdditionalAllowedFrameAncestors = {read=GetAdditionalAllowedFrameAncestors, write=SetAdditionalAllowedFrameAncestors};
	__property Uwvtypes::TWVNavigationKind NavigationKind = {read=GetNavigationKind, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2NewWindowRequestedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs3 FBaseIntf3;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetURI();
	Uwvtypelibrary::_di_ICoreWebView2 __fastcall GetNewWindow();
	bool __fastcall GetHandled();
	bool __fastcall GetIsUserInitiated();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	Uwvtypelibrary::_di_ICoreWebView2WindowFeatures __fastcall GetWindowFeatures();
	Uwvtypes::wvstring __fastcall GetName();
	Uwvtypelibrary::_di_ICoreWebView2FrameInfo __fastcall GetOriginalSourceFrameInfo();
	void __fastcall SetNewWindow(const Uwvtypelibrary::_di_ICoreWebView2 aValue);
	void __fastcall SetHandled(bool aValue);
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2NewWindowRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2NewWindowRequestedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2NewWindowRequestedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring URI = {read=GetURI};
	__property Uwvtypelibrary::_di_ICoreWebView2 NewWindow = {read=GetNewWindow, write=SetNewWindow};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property bool IsUserInitiated = {read=GetIsUserInitiated, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
	__property Uwvtypelibrary::_di_ICoreWebView2WindowFeatures WindowFeatures = {read=GetWindowFeatures};
	__property Uwvtypes::wvstring Name = {read=GetName};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameInfo OriginalSourceFrameInfo = {read=GetOriginalSourceFrameInfo};
};


class PASCALIMPLEMENTATION TCoreWebView2PermissionRequestedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs3 FBaseIntf3;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetURI();
	Uwvtypes::TWVPermissionKind __fastcall GetPermissionKind();
	bool __fastcall GetIsUserInitiated();
	Uwvtypes::TWVPermissionState __fastcall GetState();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	bool __fastcall GetHandled();
	bool __fastcall GetSavesInProfile();
	void __fastcall SetState(Uwvtypes::TWVPermissionState aValue);
	void __fastcall SetHandled(bool aValue);
	void __fastcall SetSavesInProfile(bool aValue);
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2PermissionRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs aArgs)/* overload */;
	__fastcall TCoreWebView2PermissionRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs2 aArgs)/* overload */;
	__fastcall virtual ~TCoreWebView2PermissionRequestedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2PermissionRequestedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring URI = {read=GetURI};
	__property Uwvtypes::TWVPermissionState State = {read=GetState, write=SetState, nodefault};
	__property Uwvtypes::TWVPermissionKind PermissionKind = {read=GetPermissionKind, nodefault};
	__property bool IsUserInitiated = {read=GetIsUserInitiated, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property bool SavesInProfile = {read=GetSavesInProfile, write=SetSavesInProfile, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2ProcessFailedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs3 FBaseIntf3;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVProcessFailedKind __fastcall GetProcessFailedKind();
	Uwvtypes::TWVProcessFailedReason __fastcall GetReason();
	int __fastcall GetExtiCode();
	Uwvtypes::wvstring __fastcall GetProcessDescription();
	Uwvtypelibrary::_di_ICoreWebView2FrameInfoCollection __fastcall GetFrameInfosForFailedProcess();
	Uwvtypes::wvstring __fastcall GetFailureSourceModulePath();
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2ProcessFailedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2ProcessFailedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ProcessFailedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVProcessFailedKind ProcessFailedKind = {read=GetProcessFailedKind, nodefault};
	__property Uwvtypes::TWVProcessFailedReason Reason = {read=GetReason, nodefault};
	__property int ExtiCode = {read=GetExtiCode, nodefault};
	__property Uwvtypes::wvstring ProcessDescription = {read=GetProcessDescription};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameInfoCollection FrameInfosForFailedProcess = {read=GetFrameInfosForFailedProcess};
	__property Uwvtypes::wvstring FailureSourceModulePath = {read=GetFailureSourceModulePath};
};


class PASCALIMPLEMENTATION TCoreWebView2ScriptDialogOpeningEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetURI();
	Uwvtypes::TWVScriptDialogKind __fastcall GetKind();
	Uwvtypes::wvstring __fastcall GetMessage();
	Uwvtypes::wvstring __fastcall GetDefaultText();
	Uwvtypes::wvstring __fastcall GetResultText();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetResultText(const Uwvtypes::wvstring aValue);
	
public:
	__fastcall TCoreWebView2ScriptDialogOpeningEventArgs(const Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2ScriptDialogOpeningEventArgs();
	bool __fastcall Accept();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ScriptDialogOpeningEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring URI = {read=GetURI};
	__property Uwvtypes::TWVScriptDialogKind Kind = {read=GetKind, nodefault};
	__property Uwvtypes::wvstring Message_ = {read=GetMessage};
	__property Uwvtypes::wvstring DefaultText = {read=GetDefaultText};
	__property Uwvtypes::wvstring ResultText = {read=GetResultText, write=SetResultText};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2SourceChangedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	bool __fastcall GetIsNewDocument();
	
public:
	__fastcall TCoreWebView2SourceChangedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2SourceChangedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2SourceChangedEventArgs BaseIntf = {read=FBaseIntf};
	__property bool IsNewDocument = {read=GetIsNewDocument, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2WebMessageReceivedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs2 FBaseIntf2;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetSource();
	Uwvtypes::wvstring __fastcall GetWebMessageAsJson();
	Uwvtypes::wvstring __fastcall GetWebMessageAsString();
	Uwvtypelibrary::_di_ICoreWebView2ObjectCollectionView __fastcall GetAdditionalObjects();
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2WebMessageReceivedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2WebMessageReceivedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2WebMessageReceivedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring Source = {read=GetSource};
	__property Uwvtypes::wvstring WebMessageAsJson = {read=GetWebMessageAsJson};
	__property Uwvtypes::wvstring WebMessageAsString = {read=GetWebMessageAsString};
	__property Uwvtypelibrary::_di_ICoreWebView2ObjectCollectionView AdditionalObjects = {read=GetAdditionalObjects};
};


class PASCALIMPLEMENTATION TCoreWebView2WebResourceRequestedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventArgs FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventArgs2 FBaseIntf2;
	bool __fastcall GetInitialized();
	Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest __fastcall GetRequest();
	Uwvtypelibrary::_di_ICoreWebView2WebResourceResponse __fastcall GetResponse();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	Uwvtypes::TWVWebResourceContext __fastcall GetResourceContext();
	Uwvtypes::TWVWebResourceRequestSourceKind __fastcall GetRequestedSourceKind();
	void __fastcall SetResponse(const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponse aValue);
	void __fastcall InitializeFields();
	
public:
	__fastcall TCoreWebView2WebResourceRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2WebResourceRequestedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceRequestedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest Request = {read=GetRequest};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceResponse Response = {read=GetResponse, write=SetResponse};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
	__property Uwvtypes::TWVWebResourceContext ResourceContext = {read=GetResourceContext, nodefault};
	__property Uwvtypes::TWVWebResourceRequestSourceKind RequestedSourceKind = {read=GetRequestedSourceKind, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2BrowserProcessExitedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVBrowserProcessExitKind __fastcall GetBrowserProcessExitKind();
	unsigned __fastcall GetBrowserProcessId();
	
public:
	__fastcall TCoreWebView2BrowserProcessExitedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2BrowserProcessExitedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2BrowserProcessExitedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVBrowserProcessExitKind BrowserProcessExitKind = {read=GetBrowserProcessExitKind, nodefault};
	__property unsigned BrowserProcessId = {read=GetBrowserProcessId, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2WebResourceResponseReceivedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest __fastcall GetRequest();
	Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseView __fastcall GetResponse();
	
public:
	__fastcall TCoreWebView2WebResourceResponseReceivedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2WebResourceResponseReceivedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseReceivedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceRequest Request = {read=GetRequest};
	__property Uwvtypelibrary::_di_ICoreWebView2WebResourceResponseView Response = {read=GetResponse};
};


class PASCALIMPLEMENTATION TCoreWebView2DOMContentLoadedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	unsigned __int64 __fastcall GetNavigationId();
	
public:
	__fastcall TCoreWebView2DOMContentLoadedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2DOMContentLoadedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2DOMContentLoadedEventArgs BaseIntf = {read=FBaseIntf};
	__property unsigned __int64 NavigationId = {read=GetNavigationId};
};


class PASCALIMPLEMENTATION TCoreWebView2FrameCreatedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypelibrary::_di_ICoreWebView2Frame __fastcall GetFrame();
	
public:
	__fastcall TCoreWebView2FrameCreatedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2FrameCreatedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameCreatedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypelibrary::_di_ICoreWebView2Frame Frame = {read=GetFrame};
};


class PASCALIMPLEMENTATION TCoreWebView2DownloadStartingEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypelibrary::_di_ICoreWebView2DownloadOperation __fastcall GetDownloadOperation();
	bool __fastcall GetCancel();
	Uwvtypes::wvstring __fastcall GetResultFilePath();
	bool __fastcall GetHandled();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetCancel(bool aValue);
	void __fastcall SetResultFilePath(const Uwvtypes::wvstring aValue);
	void __fastcall SetHandled(bool aValue);
	
public:
	__fastcall TCoreWebView2DownloadStartingEventArgs(const Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2DownloadStartingEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2DownloadStartingEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypelibrary::_di_ICoreWebView2DownloadOperation DownloadOperation = {read=GetDownloadOperation};
	__property bool Cancel = {read=GetCancel, write=SetCancel, nodefault};
	__property Uwvtypes::wvstring ResultFilePath = {read=GetResultFilePath, write=SetResultFilePath};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2ClientCertificateRequestedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetHost();
	int __fastcall GetPort();
	bool __fastcall GetIsProxy();
	Uwvtypelibrary::_di_ICoreWebView2StringCollection __fastcall GetAllowedCertificateAuthorities();
	Uwvtypelibrary::_di_ICoreWebView2ClientCertificateCollection __fastcall GetMutuallyTrustedCertificates();
	Uwvtypelibrary::_di_ICoreWebView2ClientCertificate __fastcall GetSelectedCertificate();
	bool __fastcall GetCancel();
	bool __fastcall GetHandled();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetSelectedCertificate(const Uwvtypelibrary::_di_ICoreWebView2ClientCertificate aValue);
	void __fastcall SetCancel(bool aValue);
	void __fastcall SetHandled(bool aValue);
	
public:
	__fastcall TCoreWebView2ClientCertificateRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2ClientCertificateRequestedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ClientCertificateRequestedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring Host = {read=GetHost};
	__property int Port = {read=GetPort, nodefault};
	__property bool IsProxy = {read=GetIsProxy, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2StringCollection AllowedCertificateAuthorities = {read=GetAllowedCertificateAuthorities};
	__property Uwvtypelibrary::_di_ICoreWebView2ClientCertificateCollection MutuallyTrustedCertificates = {read=GetMutuallyTrustedCertificates};
	__property Uwvtypelibrary::_di_ICoreWebView2ClientCertificate SelectedCertificate = {read=GetSelectedCertificate, write=SetSelectedCertificate};
	__property bool Cancel = {read=GetCancel, write=SetCancel, nodefault};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2BasicAuthenticationRequestedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetUri();
	Uwvtypes::wvstring __fastcall GetChallenge();
	Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationResponse __fastcall GetResponse();
	bool __fastcall GetCancel();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetCancel(bool aValue);
	
public:
	__fastcall TCoreWebView2BasicAuthenticationRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2BasicAuthenticationRequestedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationRequestedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring Uri = {read=GetUri};
	__property Uwvtypes::wvstring Challenge = {read=GetChallenge};
	__property Uwvtypelibrary::_di_ICoreWebView2BasicAuthenticationResponse Response = {read=GetResponse};
	__property bool Cancel = {read=GetCancel, write=SetCancel, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2ContextMenuRequestedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypelibrary::_di_ICoreWebView2ContextMenuItemCollection __fastcall GetMenuItems();
	Uwvtypelibrary::_di_ICoreWebView2ContextMenuTarget __fastcall GetContextMenuTarget();
	System::Types::TPoint __fastcall GetLocation();
	int __fastcall GetSelectedCommandId();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	bool __fastcall GetHandled();
	void __fastcall SetSelectedCommandId(int aValue);
	void __fastcall SetHandled(bool aValue);
	
public:
	__fastcall TCoreWebView2ContextMenuRequestedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2ContextMenuRequestedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ContextMenuRequestedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypelibrary::_di_ICoreWebView2ContextMenuItemCollection MenuItems = {read=GetMenuItems};
	__property Uwvtypelibrary::_di_ICoreWebView2ContextMenuTarget ContextMenuTarget = {read=GetContextMenuTarget};
	__property System::Types::TPoint Location = {read=GetLocation};
	__property int SelectedCommandId = {read=GetSelectedCommandId, write=SetSelectedCommandId, nodefault};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2ServerCertificateErrorDetectedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVWebErrorStatus __fastcall GetErrorStatus();
	Uwvtypes::wvstring __fastcall GetRequestUri();
	Uwvtypelibrary::_di_ICoreWebView2Certificate __fastcall GetServerCertificate();
	Uwvtypes::TWVServerCertificateErrorAction __fastcall GetAction();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetAction(Uwvtypes::TWVServerCertificateErrorAction aValue);
	
public:
	__fastcall TCoreWebView2ServerCertificateErrorDetectedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2ServerCertificateErrorDetectedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ServerCertificateErrorDetectedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVWebErrorStatus ErrorStatus = {read=GetErrorStatus, nodefault};
	__property Uwvtypes::wvstring RequestUri = {read=GetRequestUri};
	__property Uwvtypelibrary::_di_ICoreWebView2Certificate ServerCertificate = {read=GetServerCertificate};
	__property Uwvtypes::TWVServerCertificateErrorAction Action = {read=GetAction, write=SetAction, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2LaunchingExternalUriSchemeEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetUri();
	Uwvtypes::wvstring __fastcall GetInitiatingOrigin();
	bool __fastcall GetIsUserInitiated();
	bool __fastcall GetCancel();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetCancel(bool aValue);
	
public:
	__fastcall TCoreWebView2LaunchingExternalUriSchemeEventArgs(const Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2LaunchingExternalUriSchemeEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2LaunchingExternalUriSchemeEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring Uri = {read=GetUri};
	__property Uwvtypes::wvstring InitiatingOrigin = {read=GetInitiatingOrigin};
	__property bool IsUserInitiated = {read=GetIsUserInitiated, nodefault};
	__property bool Cancel = {read=GetCancel, write=SetCancel, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2NonClientRegionChangedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::TWVNonClientRegionKind __fastcall GetRegionKind();
	
public:
	__fastcall TCoreWebView2NonClientRegionChangedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2NonClientRegionChangedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2NonClientRegionChangedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::TWVNonClientRegionKind RegionKind = {read=GetRegionKind, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2NotificationReceivedEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetSenderOrigin();
	Uwvtypelibrary::_di_ICoreWebView2Notification __fastcall GetNotification();
	bool __fastcall GetHandled();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetHandled(bool aValue);
	
public:
	__fastcall TCoreWebView2NotificationReceivedEventArgs(const Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2NotificationReceivedEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2NotificationReceivedEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring SenderOrigin = {read=GetSenderOrigin};
	__property Uwvtypelibrary::_di_ICoreWebView2Notification Notification = {read=GetNotification};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2SaveAsUIShowingEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetContentMimeType();
	bool __fastcall GetCancel();
	bool __fastcall GetSuppressDefaultDialog();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	Uwvtypes::wvstring __fastcall GetSaveAsFilePath();
	bool __fastcall GetAllowReplace();
	Uwvtypes::TWVSaveAsKind __fastcall GetKind();
	void __fastcall SetCancel(bool aValue);
	void __fastcall SetSuppressDefaultDialog(bool aValue);
	void __fastcall SetSaveAsFilePath(const Uwvtypes::wvstring aValue);
	void __fastcall SetAllowReplace(bool aValue);
	void __fastcall SetKind(Uwvtypes::TWVSaveAsKind aValue);
	
public:
	__fastcall TCoreWebView2SaveAsUIShowingEventArgs(const Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2SaveAsUIShowingEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2SaveAsUIShowingEventArgs BaseIntf = {read=FBaseIntf};
	__property Uwvtypes::wvstring ContentMimeType = {read=GetContentMimeType};
	__property bool Cancel = {read=GetCancel, write=SetCancel, nodefault};
	__property bool SuppressDefaultDialog = {read=GetSuppressDefaultDialog, write=SetSuppressDefaultDialog, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
	__property Uwvtypes::wvstring SaveAsFilePath = {read=GetSaveAsFilePath, write=SetSaveAsFilePath};
	__property bool AllowReplace = {read=GetAllowReplace, write=SetAllowReplace, nodefault};
	__property Uwvtypes::TWVSaveAsKind Kind = {read=GetKind, write=SetKind, nodefault};
};


class PASCALIMPLEMENTATION TCoreWebView2SaveFileSecurityCheckStartingEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	bool __fastcall GetCancelSave();
	Uwvtypes::wvstring __fastcall GetDocumentOriginUri();
	Uwvtypes::wvstring __fastcall GetFileExtension();
	Uwvtypes::wvstring __fastcall GetFilePath();
	bool __fastcall GetSuppressDefaultPolicy();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetCancelSave(bool aValue);
	void __fastcall SetSuppressDefaultPolicy(bool aValue);
	
public:
	__fastcall TCoreWebView2SaveFileSecurityCheckStartingEventArgs(const Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2SaveFileSecurityCheckStartingEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2SaveFileSecurityCheckStartingEventArgs BaseIntf = {read=FBaseIntf};
	__property bool CancelSave = {read=GetCancelSave, write=SetCancelSave, nodefault};
	__property Uwvtypes::wvstring DocumentOriginUri = {read=GetDocumentOriginUri};
	__property Uwvtypes::wvstring FileExtension = {read=GetFileExtension};
	__property Uwvtypes::wvstring FilePath = {read=GetFilePath};
	__property bool SuppressDefaultPolicy = {read=GetSuppressDefaultPolicy, write=SetSuppressDefaultPolicy, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


class PASCALIMPLEMENTATION TCoreWebView2ScreenCaptureStartingEventArgs : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs FBaseIntf;
	bool __fastcall GetInitialized();
	bool __fastcall GetCancel();
	bool __fastcall GetHandled();
	Uwvtypelibrary::_di_ICoreWebView2FrameInfo __fastcall GetCoreWebView2FrameInfo();
	Uwvtypelibrary::_di_ICoreWebView2Deferral __fastcall GetDeferral();
	void __fastcall SetCancel(bool aValue);
	void __fastcall SetHandled(bool aValue);
	
public:
	__fastcall TCoreWebView2ScreenCaptureStartingEventArgs(const Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs aArgs);
	__fastcall virtual ~TCoreWebView2ScreenCaptureStartingEventArgs();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ScreenCaptureStartingEventArgs BaseIntf = {read=FBaseIntf};
	__property bool Cancel = {read=GetCancel, write=SetCancel, nodefault};
	__property bool Handled = {read=GetHandled, write=SetHandled, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2FrameInfo OriginalSourceFrameInfo = {read=GetCoreWebView2FrameInfo};
	__property Uwvtypelibrary::_di_ICoreWebView2Deferral Deferral = {read=GetDeferral};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2args */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2ARGS)
using namespace Uwvcorewebview2args;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2argsHPP
