﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Package1.dpk' rev: 36.00 (Windows)

#ifndef Package1HPP
#define Package1HPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>	// (rtl)
#include <SysInit.hpp>
#include <uWVBrowser.hpp>
#include <uWVBrowserBase.hpp>
#include <uWVConstants.hpp>
#include <uWVCoreWebView2.hpp>
#include <uWVCoreWebView2Args.hpp>
#include <uWVCoreWebView2BasicAuthenticationResponse.hpp>
#include <uWVCoreWebView2BrowserExtension.hpp>
#include <uWVCoreWebView2BrowserExtensionList.hpp>
#include <uWVCoreWebView2Certificate.hpp>
#include <uWVCoreWebView2ClientCertificate.hpp>
#include <uWVCoreWebView2ClientCertificateCollection.hpp>
#include <uWVCoreWebView2CompositionController.hpp>
#include <uWVCoreWebView2ContextMenuItem.hpp>
#include <uWVCoreWebView2ContextMenuItemCollection.hpp>
#include <uWVCoreWebView2ContextMenuTarget.hpp>
#include <uWVCoreWebView2Controller.hpp>
#include <uWVCoreWebView2ControllerOptions.hpp>
#include <uWVCoreWebView2Cookie.hpp>
#include <uWVCoreWebView2CookieList.hpp>
#include <uWVCoreWebView2CookieManager.hpp>
#include <uWVCoreWebView2CustomSchemeRegistration.hpp>
#include <uWVCoreWebView2Deferral.hpp>
#include <uWVCoreWebView2Delegates.hpp>
#include <uWVCoreWebView2DownloadOperation.hpp>
#include <uWVCoreWebView2Environment.hpp>
#include <uWVCoreWebView2EnvironmentOptions.hpp>
#include <uWVCoreWebView2ExecuteScriptResult.hpp>
#include <uWVCoreWebView2File.hpp>
#include <uWVCoreWebView2FileSystemHandle.hpp>
#include <uWVCoreWebView2Find.hpp>
#include <uWVCoreWebView2FindOptions.hpp>
#include <uWVCoreWebView2Frame.hpp>
#include <uWVCoreWebView2FrameInfo.hpp>
#include <uWVCoreWebView2FrameInfoCollection.hpp>
#include <uWVCoreWebView2FrameInfoCollectionIterator.hpp>
#include <uWVCoreWebView2HttpHeadersCollectionIterator.hpp>
#include <uWVCoreWebView2HttpRequestHeaders.hpp>
#include <uWVCoreWebView2HttpResponseHeaders.hpp>
#include <uWVCoreWebView2Notification.hpp>
#include <uWVCoreWebView2ObjectCollection.hpp>
#include <uWVCoreWebView2ObjectCollectionView.hpp>
#include <uWVCoreWebView2PermissionSetting.hpp>
#include <uWVCoreWebView2PermissionSettingCollectionView.hpp>
#include <uWVCoreWebView2PointerInfo.hpp>
#include <uWVCoreWebView2PrintSettings.hpp>
#include <uWVCoreWebView2ProcessExtendedInfo.hpp>
#include <uWVCoreWebView2ProcessExtendedInfoCollection.hpp>
#include <uWVCoreWebView2ProcessInfo.hpp>
#include <uWVCoreWebView2ProcessInfoCollection.hpp>
#include <uWVCoreWebView2Profile.hpp>
#include <uWVCoreWebView2RegionRectCollectionView.hpp>
#include <uWVCoreWebView2ScriptException.hpp>
#include <uWVCoreWebView2Settings.hpp>
#include <uWVCoreWebView2SharedBuffer.hpp>
#include <uWVCoreWebView2StringCollection.hpp>
#include <uWVCoreWebView2WebResourceRequest.hpp>
#include <uWVCoreWebView2WebResourceResponse.hpp>
#include <uWVCoreWebView2WebResourceResponseView.hpp>
#include <uWVCoreWebView2WindowFeatures.hpp>
#include <uWVEvents.hpp>
#include <uWVFMXBrowser.hpp>
#include <uWVFMXWindowParent.hpp>
#include <uWVInterfaces.hpp>
#include <uWVLibFunctions.hpp>
#include <uWVLoader.hpp>
#include <uWVLoaderInternal.hpp>
#include <uWVMiscFunctions.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>
#include <uWVWinControl.hpp>
#include <uWVWindowParent.hpp>
#include <System.Types.hpp>	// (rtl)
#include <System.UITypes.hpp>	// (rtl)
#include <Winapi.Windows.PkgHelper.hpp>	// (rtl)
#include <Winapi.Windows.hpp>	// (rtl)
#include <Winapi.Messages.hpp>	// (rtl)
#include <System.SysConst.hpp>	// (rtl)
#include <Winapi.ImageHlp.hpp>	// (rtl)
#include <Winapi.SHFolder.hpp>	// (rtl)
#include <Winapi.PsAPI.hpp>	// (rtl)
#include <System.RTLConsts.hpp>	// (rtl)
#include <System.Character.hpp>	// (rtl)
#include <System.Internal.ExcUtils.hpp>	// (rtl)
#include <System.SysUtils.hpp>	// (rtl)
#include <System.VarUtils.hpp>	// (rtl)
#include <System.Variants.hpp>	// (rtl)
#include <Winapi.ActiveX.hpp>	// (rtl)
#include <System.TypInfo.hpp>	// (rtl)
#include <System.Hash.hpp>	// (rtl)
#include <System.Math.hpp>	// (rtl)
#include <System.Generics.Defaults.hpp>	// (rtl)
#include <System.Generics.Collections.hpp>	// (rtl)
#include <System.TimeSpan.hpp>	// (rtl)
#include <System.Diagnostics.hpp>	// (rtl)
#include <System.SyncObjs.hpp>	// (rtl)
#include <System.Rtti.hpp>	// (rtl)
#include <System.Classes.hpp>	// (rtl)
#include <System.Messaging.hpp>	// (rtl)
#include <System.Actions.hpp>	// (rtl)
#include <Winapi.Wincodec.hpp>	// (rtl)
#include <Winapi.CommCtrl.hpp>	// (rtl)
#include <Winapi.Qos.hpp>	// (rtl)
#include <Winapi.Winsock2.hpp>	// (rtl)
#include <Winapi.IpExport.hpp>	// (rtl)
#include <Winapi.ShellAPI.hpp>	// (rtl)
#include <Winapi.RegStr.hpp>	// (rtl)
#include <Winapi.WinInet.hpp>	// (rtl)
#include <Winapi.UrlMon.hpp>	// (rtl)
#include <Winapi.ObjectArray.hpp>	// (rtl)
#include <Winapi.StructuredQueryCondition.hpp>	// (rtl)
#include <Winapi.PropSys.hpp>	// (rtl)
#include <Winapi.MSXMLIntf.hpp>	// (rtl)
#include <Winapi.ShlObj.hpp>	// (rtl)
#include <Winapi.KnownFolders.hpp>	// (rtl)
#include <System.Masks.hpp>	// (rtl)
#include <System.StrUtils.hpp>	// (rtl)
#include <System.DateUtils.hpp>	// (rtl)
#include <System.IOUtils.hpp>	// (rtl)
#include <System.IniFiles.hpp>	// (rtl)
#include <System.Win.Registry.hpp>	// (rtl)
#include <System.UIConsts.hpp>	// (rtl)
#include <Vcl.Consts.hpp>	// (vcl)
#include <Vcl.Graphics.hpp>	// (vcl)
#include <System.Contnrs.hpp>	// (rtl)
#include <System.ImageList.hpp>	// (rtl)
#include <Winapi.UxTheme.hpp>	// (rtl)
#include <Winapi.MultiMon.hpp>	// (rtl)
#include <Winapi.Imm.hpp>	// (rtl)
#include <Vcl.ActnList.hpp>	// (vcl)
#include <Winapi.TpcShrd.hpp>	// (rtl)
#include <Winapi.MsCTF.PkgHelper.hpp>	// (rtl)
#include <System.AnsiStrings.hpp>	// (rtl)
#include <System.Win.ComConst.hpp>	// (rtl)
#include <System.Win.ComObj.hpp>	// (rtl)
#include <Winapi.MsCTF.hpp>	// (rtl)
#include <Winapi.Dwmapi.hpp>	// (rtl)
#include <System.Win.Crtl.hpp>	// (rtl)
#include <System.ZLib.hpp>	// (rtl)
#include <Vcl.GraphUtil.hpp>	// (vcl)
#include <Winapi.MsInkAut.hpp>	// (rtl)
#include <Winapi.PenInputPanel.hpp>	// (rtl)
#include <Vcl.Controls.hpp>	// (vcl)
#include <Vcl.StdCtrls.hpp>	// (vcl)
#include <System.MaskUtils.hpp>	// (rtl)
#include <Vcl.Clipbrd.hpp>	// (vcl)
#include <Vcl.Mask.hpp>	// (vcl)
#include <Winapi.CommDlg.hpp>	// (rtl)
#include <Winapi.WinSpool.hpp>	// (rtl)
#include <Vcl.Printers.hpp>	// (vcl)
#include <Winapi.RichEdit.hpp>	// (rtl)
#include <Vcl.ToolWin.hpp>	// (vcl)
#include <Vcl.ListActns.hpp>	// (vcl)
#include <Vcl.ComStrs.hpp>	// (vcl)
#include <Vcl.StdActns.hpp>	// (vcl)
#include <Vcl.ComCtrls.hpp>	// (vcl)
#include <System.WideStrUtils.hpp>	// (rtl)
#include <Winapi.Dlgs.hpp>	// (rtl)
#include <System.HelpIntfs.hpp>	// (rtl)
#include <Vcl.Dialogs.hpp>	// (vcl)
#include <Vcl.ExtCtrls.hpp>	// (vcl)
#include <Vcl.Themes.hpp>	// (vcl)
#include <Vcl.ImgList.hpp>	// (vcl)
#include <Vcl.Menus.hpp>	// (vcl)
#include <System.Win.Taskbar.hpp>	// (rtl)
#include <System.Win.TaskbarCore.hpp>	// (rtl)
#include <Winapi.ShellScaling.hpp>	// (rtl)
#include <Winapi.Wtsapi32.hpp>	// (rtl)
#include <Winapi.FlatSB.hpp>	// (rtl)
#include <Vcl.Forms.hpp>	// (vcl)
#include <System.JSONConsts.hpp>	// (rtl)
#include <System.JSON.hpp>	// (rtl)
#include <System.NetEncoding.hpp>	// (rtl)
#include <System.Win.StdVCL.hpp>	// (rtl)
#include <System.Analytics.hpp>	// (rtl)
#include <System.Math.Vectors.hpp>	// (rtl)
#include <FMX.Consts.hpp>	// (fmx)
#include <System.Win.Devices.hpp>	// (rtl)
#include <System.Devices.hpp>	// (rtl)
#include <FMX.DialogService.Sync.hpp>	// (fmx)
#include <FMX.Dialogs.hpp>	// (fmx)
#include <FMX.Surfaces.hpp>	// (fmx)
#include <FMX.TextLayout.hpp>	// (fmx)
#include <FMX.Utils.hpp>	// (fmx)
#include <FMX.Graphics.hpp>	// (fmx)
#include <System.RegularExpressionsAPI.hpp>	// (rtl)
#include <System.RegularExpressionsConsts.hpp>	// (rtl)
#include <System.RegularExpressionsCore.hpp>	// (rtl)
#include <System.RegularExpressions.hpp>	// (rtl)
#include <FMX.Text.hpp>	// (fmx)
#include <FMX.BehaviorManager.hpp>	// (fmx)
#include <FMX.VirtualKeyboard.hpp>	// (fmx)
#include <FMX.Materials.hpp>	// (fmx)
#include <FMX.Types3D.hpp>	// (fmx)
#include <FMX.Filter.hpp>	// (fmx)
#include <FMX.Filter.Custom.hpp>	// (fmx)
#include <FMX.Effects.hpp>	// (fmx)
#include <FMX.MultiResBitmap.hpp>	// (fmx)
#include <FMX.Ani.hpp>	// (fmx)
#include <FMX.AcceleratorKey.hpp>	// (fmx)
#include <FMX.ImgList.hpp>	// (fmx)
#include <Winapi.DxgiFormat.hpp>	// (rtl)
#include <Winapi.DXTypes.hpp>	// (rtl)
#include <Winapi.DxgiType.hpp>	// (rtl)
#include <Winapi.DXGI.hpp>	// (rtl)
#include <Winapi.D3DCommon.hpp>	// (rtl)
#include <Winapi.D2D1.hpp>	// (rtl)
#include <FMX.DialogService.hpp>	// (fmx)
#include <FMX.Menus.hpp>	// (fmx)
#include <FMX.Helpers.Win.hpp>	// (fmx)
#include <FMX.FontGlyphs.Win.hpp>	// (fmx)
#include <FMX.FontGlyphs.hpp>	// (fmx)
#include <FMX.Objects.hpp>	// (fmx)
#include <Winapi.Manipulations.hpp>	// (rtl)
#include <Winapi.RtsCom.hpp>	// (rtl)
#include <FMX.Gestures.Win.hpp>	// (fmx)
#include <FMX.Gestures.hpp>	// (fmx)
#include <FMX.Controls.hpp>	// (fmx)
#include <FMX.Styles.hpp>	// (fmx)
#include <FMX.Platform.Common.hpp>	// (fmx)
#include <FMX.Clipboard.Win.hpp>	// (fmx)
#include <FMX.Clipboard.hpp>	// (fmx)
#include <FMX.Platform.hpp>	// (fmx)
#include <FMX.ActnList.hpp>	// (fmx)
#include <FMX.Types.hpp>	// (fmx)
#include <FMX.Materials.Canvas.hpp>	// (fmx)
#include <FMX.Canvas.GPU.Helpers.hpp>	// (fmx)
#include <FMX.StrokeBuilder.hpp>	// (fmx)
#include <FMX.Canvas.GPU.hpp>	// (fmx)
#include <FMX.TextLayout.GPU.hpp>	// (fmx)
#include <FMX.StdActns.hpp>	// (fmx)
#include <FMX.Presentation.Messages.hpp>	// (fmx)
#include <FMX.Controls.Model.hpp>	// (fmx)
#include <FMX.Presentation.Factory.hpp>	// (fmx)
#include <FMX.Presentation.Style.hpp>	// (fmx)
#include <FMX.Controls.Win.hpp>	// (fmx)
#include <FMX.ZOrder.hpp>	// (fmx)
#include <FMX.ZOrder.Win.hpp>	// (fmx)
#include <FMX.Presentation.Win.hpp>	// (fmx)
#include <FMX.Presentation.Style.Common.hpp>	// (fmx)
#include <FMX.Presentation.Win.Style.hpp>	// (fmx)
#include <FMX.Controls.Presentation.hpp>	// (fmx)
#include <FMX.Styles.Objects.hpp>	// (fmx)
#include <FMX.Styles.Switch.hpp>	// (fmx)
#include <FMX.Switch.Style.hpp>	// (fmx)
#include <FMX.Platform.Metrics.hpp>	// (fmx)
#include <FMX.Switch.Win.hpp>	// (fmx)
#include <FMX.StdCtrls.hpp>	// (fmx)
#include <FMX.InertialMovement.hpp>	// (fmx)
#include <FMX.Layouts.hpp>	// (fmx)
#include <FMX.Header.hpp>	// (fmx)
#include <FMX.Forms.hpp>	// (fmx)
#include <Winapi.MMSystem.hpp>	// (rtl)
#include <FMX.MediaLibrary.hpp>	// (fmx)
#include <Winapi.DirectDraw.hpp>	// (rtl)
#include <Winapi.GDIPAPI.hpp>	// (rtl)
#include <Winapi.GDIPOBJ.hpp>	// (rtl)
#include <Winapi.GDIPUTIL.hpp>	// (rtl)
#include <FMX.FontManager.hpp>	// (fmx)
#include <Winapi.D3D10.hpp>	// (rtl)
#include <Winapi.D3D10_1.hpp>	// (rtl)
#include <FMX.Canvas.D2D.hpp>	// (fmx)
#include <FMX.FontManager.Win.hpp>	// (fmx)
#include <FMX.Canvas.GDIP.hpp>	// (fmx)
#include <FMX.Printer.Win.hpp>	// (fmx)
#include <FMX.Printer.hpp>	// (fmx)
#include <FMX.Text.UndoManager.hpp>	// (fmx)
#include <FMX.ScrollBox.Win.hpp>	// (fmx)
#include <FMX.ScrollBox.hpp>	// (fmx)
#include <FMX.ScrollBox.Style.hpp>	// (fmx)
#include <FMX.Text.LinesLayout.hpp>	// (fmx)
#include <FMX.Text.SelectionController.hpp>	// (fmx)
#include <FMX.Text.AutoscrollController.hpp>	// (fmx)
#include <FMX.SpellChecker.hpp>	// (fmx)
#include <FMX.Text.SpellingManager.hpp>	// (fmx)
#include <FMX.Text.IMERender.hpp>	// (fmx)
#include <FMX.Text.TextEditor.hpp>	// (fmx)
#include <FMX.MagnifierGlass.hpp>	// (fmx)
#include <FMX.Text.InteractiveSelectors.hpp>	// (fmx)
#include <FMX.Edit.Style.New.hpp>	// (fmx)
#include <FMX.Edit.Win.hpp>	// (fmx)
#include <FMX.Edit.hpp>	// (fmx)
#include <FMX.Dialogs.Default.hpp>	// (fmx)
#include <FMX.DialogHelper.hpp>	// (fmx)
#include <FMX.Dialogs.Win.hpp>	// (fmx)
#include <Winapi.Direct3D9.hpp>	// (rtl)
#include <FMX.Context.DX9.hpp>	// (fmx)
#include <Winapi.D3D11.hpp>	// (rtl)
#include <FMX.Context.DX11.hpp>	// (fmx)
#include <FMX.Forms.Border.hpp>	// (fmx)
#include <FMX.Forms.Border.Win.hpp>	// (fmx)
#include <FMX.MultiTouch.hpp>	// (fmx)
#include <FMX.MultiTouch.Win.hpp>	// (fmx)
#include <System.Win.OleControls.hpp>	// (rtl)
#include <System.Win.OleServers.hpp>	// (rtl)
#include <System.Win.InternetExplorer.hpp>	// (rtl)
#include <System.Win.IEInterfaces.hpp>	// (rtl)
#include <Winapi.WebView2.hpp>	// (rtl)
#include <Winapi.EdgeUtils.hpp>	// (rtl)
#include <FMX.Controls.Ole.hpp>	// (fmx)
#include <FMX.WebBrowser.Win.hpp>	// (fmx)
#include <FMX.WebBrowser.hpp>	// (fmx)
#include <FMX.KeyMapping.hpp>	// (fmx)
#include <FMX.AcceleratorKey.Win.hpp>	// (fmx)
#include <FMX.Platform.Screen.Win.hpp>	// (fmx)
#include <FMX.Platform.SaveState.Win.hpp>	// (fmx)
#include <FMX.Platform.Device.Win.hpp>	// (fmx)
#include <FMX.Platform.Metrics.Win.hpp>	// (fmx)
#include <FMX.ListBox.Selection.hpp>	// (fmx)
#include <FMX.ListBox.hpp>	// (fmx)
#include <FMX.DateTimeCtrls.Types.hpp>	// (fmx)
#include <FMX.DateTimeCtrls.hpp>	// (fmx)
#include <FMX.ExtCtrls.hpp>	// (fmx)
#include <FMX.Calendar.Style.hpp>	// (fmx)
#include <FMX.Calendar.hpp>	// (fmx)
#include <FMX.Pickers.Default.hpp>	// (fmx)
#include <FMX.Pickers.hpp>	// (fmx)
#include <FMX.VirtualKeyboard.Win.hpp>	// (fmx)
#include <FMX.Platform.Timer.Win.hpp>	// (fmx)
#include <FMX.Platform.Logger.Win.hpp>	// (fmx)
#include <FMX.Platform.Menu.Win.hpp>	// (fmx)
#include <FMX.Platform.Win.hpp>	// (fmx)
// PRG_EXT: .bpl
// BPI_DIR: C:\Users\Public\Documents\Embarcadero\Studio\23.0\Dcp\Win64
// OBJ_DIR: C:\Users\Public\Documents\Embarcadero\Studio\23.0\Dcp\Win64
// OBJ_EXT: .o

//-- user supplied -----------------------------------------------------------

namespace Package1
{
//-- forward type declarations -----------------------------------------------
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
}	/* namespace Package1 */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_PACKAGE1)
using namespace Package1;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Package1HPP
