﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2ScriptException.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2scriptexceptionHPP
#define Uwvcorewebview2scriptexceptionHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2scriptexception
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2ScriptException;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2ScriptException : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2ScriptException FBaseIntf;
	bool __fastcall GetInitialized();
	unsigned __fastcall GetLineNumber();
	unsigned __fastcall GetColumnNumber();
	Uwvtypes::wvstring __fastcall GetName();
	Uwvtypes::wvstring __fastcall GetMessage();
	
public:
	__fastcall TCoreWebView2ScriptException(const Uwvtypelibrary::_di_ICoreWebView2ScriptException aBaseIntf);
	__fastcall virtual ~TCoreWebView2ScriptException();
	Uwvtypes::wvstring __fastcall ToJson();
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2ScriptException BaseIntf = {read=FBaseIntf};
	__property unsigned LineNumber = {read=GetLineNumber, nodefault};
	__property unsigned ColumnNumber = {read=GetColumnNumber, nodefault};
	__property Uwvtypes::wvstring Name = {read=GetName};
	__property Uwvtypes::wvstring Message_ = {read=GetMessage};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2scriptexception */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2SCRIPTEXCEPTION)
using namespace Uwvcorewebview2scriptexception;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2scriptexceptionHPP
