//-- WARNING -----------------------------------------------------------------
// Deprecated legacy header
//----------------------------------------------------------------------------
#ifdef WARN_LEGACY_HEADER_USAGE
  #pragma message("Include <Vcl.StdActns.hpp> instead")
#endif
#ifdef ERROR_LEGACY_HEADER_USAGE
  #error Include 'Vcl.StdActns.hpp' instead
#endif

#include <Vcl.StdActns.hpp>
