﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2Frame.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2frameHPP
#define Uwvcorewebview2frameHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Classes.hpp>
#include <Winapi.ActiveX.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2frame
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2Frame;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2Frame : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2Frame FBaseIntf;
	Uwvtypelibrary::_di_ICoreWebView2Frame2 FBaseIntf2;
	Uwvtypelibrary::_di_ICoreWebView2Frame3 FBaseIntf3;
	Uwvtypelibrary::_di_ICoreWebView2Frame4 FBaseIntf4;
	Uwvtypelibrary::_di_ICoreWebView2Frame5 FBaseIntf5;
	Uwvtypelibrary::_di_ICoreWebView2Frame6 FBaseIntf6;
	Uwvtypelibrary::_di_ICoreWebView2Frame7 FBaseIntf7;
	Uwvtypelibrary::EventRegistrationToken FNameChangedToken;
	Uwvtypelibrary::EventRegistrationToken FDestroyedToken;
	Uwvtypelibrary::EventRegistrationToken FFrameNavigationStartingToken;
	Uwvtypelibrary::EventRegistrationToken FFrameNavigationCompletedToken;
	Uwvtypelibrary::EventRegistrationToken FFrameContentLoadingToken;
	Uwvtypelibrary::EventRegistrationToken FFrameDOMContentLoadedToken;
	Uwvtypelibrary::EventRegistrationToken FFrameWebMessageReceivedToken;
	Uwvtypelibrary::EventRegistrationToken FPermissionRequestedToken;
	Uwvtypelibrary::EventRegistrationToken FFrameScreenCaptureStartingToken;
	Uwvtypelibrary::EventRegistrationToken FFrameChildFrameCreatedToken;
	unsigned FFrameIDCopy;
	bool __fastcall GetInitialized();
	Uwvtypes::wvstring __fastcall GetName();
	bool __fastcall GetIsDestroyed();
	unsigned __fastcall GetFrameID();
	void __fastcall InitializeFields();
	void __fastcall InitializeTokens();
	void __fastcall RemoveAllEvents();
	bool __fastcall AddFrameNameChangedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameDestroyedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameNavigationStartingEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameNavigationCompletedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameContentLoadingEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameDOMContentLoadedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameWebMessageReceivedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddPermissionRequestedEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameScreenCaptureStartingEvent(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddFrameCreatedEvent(System::Classes::TComponent* const aBrowserComponent);
	
public:
	__fastcall TCoreWebView2Frame(const Uwvtypelibrary::_di_ICoreWebView2Frame aBaseIntf);
	__fastcall virtual ~TCoreWebView2Frame();
	bool __fastcall AddAllBrowserEvents(System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall AddHostObjectToScriptWithOrigins(const Uwvtypes::wvstring aName, const System::OleVariant &aObject, unsigned aOriginsCount, Uwvtypes::wvstring &aOrigins);
	bool __fastcall RemoveHostObjectFromScript(const Uwvtypes::wvstring aName);
	bool __fastcall ExecuteScript(const Uwvtypes::wvstring JavaScript, int aExecutionID, System::Classes::TComponent* const aBrowserComponent);
	bool __fastcall PostWebMessageAsJson(const Uwvtypes::wvstring aWebMessageAsJson);
	bool __fastcall PostWebMessageAsString(const Uwvtypes::wvstring aWebMessageAsString);
	bool __fastcall PostSharedBufferToScript(const Uwvtypelibrary::_di_ICoreWebView2SharedBuffer aSharedBuffer, Uwvtypes::TWVSharedBufferAccess aAccess, const Uwvtypes::wvstring aAdditionalDataAsJson);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2Frame BaseIntf = {read=FBaseIntf};
	__property unsigned FrameID = {read=GetFrameID, nodefault};
	__property Uwvtypes::wvstring Name = {read=GetName};
	__property bool IsDestroyed = {read=GetIsDestroyed, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2frame */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2FRAME)
using namespace Uwvcorewebview2frame;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2frameHPP
