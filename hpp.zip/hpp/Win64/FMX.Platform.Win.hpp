﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Platform.Win.pas' rev: 36.00 (Windows)

#ifndef Fmx_Platform_WinHPP
#define Fmx_Platform_WinHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.Messaging.hpp>
#include <Winapi.CommCtrl.hpp>
#include <Winapi.Windows.hpp>
#include <Winapi.ActiveX.hpp>
#include <System.Types.hpp>
#include <Winapi.Messages.hpp>
#include <System.Classes.hpp>
#include <System.UITypes.hpp>
#include <System.UIConsts.hpp>
#include <System.Generics.Collections.hpp>
#include <FMX.Forms.hpp>
#include <FMX.Platform.hpp>
#include <FMX.Types.hpp>
#include <FMX.Graphics.hpp>
#include <FMX.ZOrder.Win.hpp>

//-- user supplied -----------------------------------------------------------
#if defined(WIN32) && defined(CreateWindow)
  #define __SAVE_CREATEWINDOW CreateWindow
  #undef  CreateWindow
#endif

namespace Fmx
{
namespace Platform
{
namespace Win
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TWinWindowHandle;
class DELPHICLASS TWinDropTarget;
//-- type declarations -------------------------------------------------------
typedef System::StaticArray<System::Types::TRect, 134217727> TRgnRects;

typedef TRgnRects *PRgnRects;

typedef System::DynamicArray<System::Types::TRectF> TUpdateRects;

class PASCALIMPLEMENTATION TWinWindowHandle : public Fmx::Types::TWindowHandle
{
	typedef Fmx::Types::TWindowHandle inherited;
	
private:
	static float FForcedScale;
	Fmx::Forms::TCommonCustomForm* FForm;
	HWND FWnd;
	Fmx::Zorder::Win::TWinZOrderManager* FZOrderManager;
	Winapi::Windows::THandle FBufferBitmap;
	Winapi::Windows::TBitmapInfo FBitmapInfo;
	void *FBufferBits;
	Winapi::Windows::THandle FBufferHandle;
	System::Types::TSize FBufferSize;
	bool FDisableDeactivate;
	TWinDropTarget* FWinDropTarget;
	float FCurrentScale;
	System::Types::TSizeF FClientSize;
	System::Types::TSize FWndClientSize;
	System::Types::TRectF FBounds;
	System::Types::TRect FWndBounds;
	int FNearestIntegerMultiple;
	void __fastcall UpdateLayer();
	Fmx::Zorder::Win::TWinZOrderManager* __fastcall GetZOrderManager();
	void __fastcall SetBounds(const System::Types::TRectF &Value);
	void __fastcall SetWndBounds(const System::Types::TRect &Value);
	void __fastcall SetClientSize(const System::Types::TSizeF &Value);
	void __fastcall CalculateClientSizeFromWindow();
	void __fastcall ApplyWndBoundsToWnd();
	void __fastcall ApplyWndClientSizeToWnd();
	void __fastcall CalcNearestIntegerMultiple();
	int __fastcall GetNearestIntegerMultiple();
	System::Types::TSize __fastcall GetWndBorderSize();
	
protected:
	virtual System::Types::TRectF __fastcall GetBounds();
	virtual System::Types::TSizeF __fastcall GetClientSize();
	virtual System::Types::TRect __fastcall GetWndBounds();
	virtual System::Types::TSize __fastcall GetWndClientSize();
	virtual bool __fastcall GetTransparency();
	virtual float __fastcall GetScale();
	MESSAGE void __fastcall WMDpiChanged(Winapi::Messages::TWMDpi &AMessage);
	MESSAGE void __fastcall WMWindowPosChanging(Winapi::Messages::TWMWindowPosChanging &AMessage);
	MESSAGE void __fastcall WMWindowPosChanged(Winapi::Messages::TWMWindowPosChanged &AMessage);
	MESSAGE void __fastcall WMSize(Winapi::Messages::TWMSize &AMessage);
	MESSAGE void __fastcall WMGetMinMaxInfo(Winapi::Messages::TWMGetMinMaxInfo &Message);
	
public:
	__fastcall TWinWindowHandle(Fmx::Forms::TCommonCustomForm* const AForm, const HWND AWnd);
	__fastcall virtual ~TWinWindowHandle();
	__classmethod void __fastcall SetForcedScale(const float ANewScale);
	void __fastcall SetForcedScaleForForm(const float ANewScale);
	void __fastcall CreateBuffer(const int Width, const int Height);
	void __fastcall ResizeBuffer(const int Width, const int Height);
	void __fastcall FreeBuffer();
	System::Types::TSize __fastcall RoundWndClientSizeToMatchScale(const System::Types::TSize &AWndClientSize);
	System::Types::TSize __fastcall RoundWndSizeToMatchScale(const System::Types::TSize &AWndSize);
	System::Types::TRectF __fastcall WndToForm(const System::Types::TRect &Rect)/* overload */;
	System::Types::TRectF __fastcall WndToForm(const System::Types::TRectF &Rect)/* overload */;
	System::Types::TRectF __fastcall FormToWnd(const System::Types::TRectF &Rect);
	__property int NearestIntegerMultiple = {read=GetNearestIntegerMultiple, nodefault};
	__property HWND Wnd = {read=FWnd};
	__property Fmx::Forms::TCommonCustomForm* Form = {read=FForm};
	__property Fmx::Zorder::Win::TWinZOrderManager* ZOrderManager = {read=GetZOrderManager};
	__property bool Transparency = {read=GetTransparency, nodefault};
	__property void * BufferBits = {read=FBufferBits};
	__property Winapi::Windows::THandle BufferHandle = {read=FBufferHandle};
	__property System::Types::TSize BufferSize = {read=FBufferSize};
	__property System::Types::TSizeF ClientSize = {read=GetClientSize, write=SetClientSize};
	__property System::Types::TRectF Bounds = {read=GetBounds, write=SetBounds};
	__property System::Types::TSize WndClientSize = {read=GetWndClientSize};
	__property System::Types::TRect WndBounds = {read=GetWndBounds, write=SetWndBounds};
	__property System::Types::TSize WndBorderSize = {read=GetWndBorderSize};
};


class PASCALIMPLEMENTATION TWinDropTarget : public System::Classes::TComponent
{
	typedef System::Classes::TComponent inherited;
	
private:
	Fmx::Forms::TCommonCustomForm* Form;
	Fmx::Types::TDragObject __fastcall GetDataObject();
	HRESULT __stdcall DragEnter(const _di_IDataObject dataObj, System::LongInt grfKeyState, System::Types::TPoint pt, System::LongInt &dwEffect);
	HRESULT __stdcall DragOver(System::LongInt grfKeyState, System::Types::TPoint pt, System::LongInt &dwEffect);
	HRESULT __stdcall DragLeave();
	HRESULT __stdcall Drop(const _di_IDataObject dataObj, System::LongInt grfKeyState, System::Types::TPoint pt, System::LongInt &dwEffect);
public:
	/* TComponent.Create */ inline __fastcall virtual TWinDropTarget(System::Classes::TComponent* AOwner) : System::Classes::TComponent(AOwner) { }
	/* TComponent.Destroy */ inline __fastcall virtual ~TWinDropTarget() { }
	
private:
	void *__IDropTarget;	// IDropTarget 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {00000122-0000-0000-C000-000000000046}
	operator _di_IDropTarget()
	{
		_di_IDropTarget intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator IDropTarget*(void) { return (IDropTarget*)&__IDropTarget; }
	#endif
	
};


typedef HWND __fastcall (*TApplicationHWNDProc)(void);

//-- var, const, procedure ---------------------------------------------------
#define IDC_NODROP (System::WideChar *)(0x0000000000007ff8ULL)
#define IDC_DRAG (System::WideChar *)(0x0000000000007ff7ULL)
#define IDC_MULTIDRAG (System::WideChar *)(0x0000000000007ff4ULL)
#define IDC_SQLWAIT (System::WideChar *)(0x0000000000007ff3ULL)
extern DELPHI_PACKAGE System::Types::TPointF __fastcall PxToDp(const System::Types::TPoint &AValue);
extern DELPHI_PACKAGE System::Types::TPoint __fastcall DpToPx(const System::Types::TPointF &AValue);
extern DELPHI_PACKAGE Fmx::Forms::TCommonCustomForm* __fastcall FindWindow(HWND Handle);
extern DELPHI_PACKAGE HWND __fastcall FmxHandleToHWND(Fmx::Types::TWindowHandle* const FmxHandle);
extern DELPHI_PACKAGE TWinWindowHandle* __fastcall WindowHandleToPlatform(Fmx::Types::TWindowHandle* const AHandle);
extern DELPHI_PACKAGE HWND __fastcall FormToHWND(Fmx::Forms::TCommonCustomForm* Form);
extern DELPHI_PACKAGE HWND __fastcall ApplicationHWND(void);
extern DELPHI_PACKAGE void __fastcall RegisterCorePlatformServices(void);
extern DELPHI_PACKAGE void __fastcall UnregisterCorePlatformServices(void);
extern DELPHI_PACKAGE void __fastcall RegisterApplicationHWNDProc(const TApplicationHWNDProc Proc);
extern DELPHI_PACKAGE void __cdecl ShutDown(void);
}	/* namespace Win */
}	/* namespace Platform */
}	/* namespace Fmx */

//-- user supplied -----------------------------------------------------------
#if defined(__SAVE_CREATEWINDOW)
  #define CreateWindow __SAVE_CREATEWINDOW
  #undef  __SAVE_CREATEWINDOW
#endif

#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_Platform_WinHPP
