﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'FMX.Filter.pas' rev: 36.00 (Windows)

#ifndef Fmx_FilterHPP
#define Fmx_FilterHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <System.SysUtils.hpp>
#include <System.Classes.hpp>
#include <System.Types.hpp>
#include <System.Math.Vectors.hpp>
#include <System.Rtti.hpp>
#include <System.UITypes.hpp>
#include <System.Generics.Collections.hpp>
#include <FMX.Types3D.hpp>
#include <FMX.Graphics.hpp>
#include <System.Generics.Defaults.hpp>

//-- user supplied -----------------------------------------------------------

namespace Fmx
{
namespace Filter
{
//-- forward type declarations -----------------------------------------------
__interface DELPHIINTERFACE IFilterCacheLayer;
typedef System::DelphiInterface<IFilterCacheLayer> _di_IFilterCacheLayer;
__interface DELPHIINTERFACE IBitmapCacheLayer;
typedef System::DelphiInterface<IBitmapCacheLayer> _di_IBitmapCacheLayer;
class DELPHICLASS TBitmapCacheLayer;
struct TFilterValueRec;
struct TFilterRec;
class DELPHICLASS TFilter;
class DELPHICLASS TFilterManager;
class DELPHICLASS TFilterContext;
class DELPHICLASS EFilterException;
class DELPHICLASS EFilterManagerException;
//-- type declarations -------------------------------------------------------
__interface  INTERFACE_UUID("{49EEF76F-3BD6-4688-994F-DC1B55002DEA}") IFilterCacheLayer  : public System::IInterface 
{
	virtual void __fastcall SetNeedUpdate() = 0 ;
};

__interface  INTERFACE_UUID("{C321CAF5-994B-4B64-9E99-8903B7B6A67D}") IBitmapCacheLayer  : public IFilterCacheLayer 
{
	virtual bool __fastcall BeginUpdate(Fmx::Graphics::TCanvas* const ATarget, const System::Types::TRectF &ADestRect, const float AOpacity, const bool AHighSpeed, /* out */ Fmx::Graphics::TCanvas* &ACacheCanvas) = 0 ;
	virtual void __fastcall EndUpdate(const System::DelphiInterface<System::Sysutils::TProc__1<Fmx::Graphics::TBitmap*> > AGeneratedBitmap = System::DelphiInterface<System::Sysutils::TProc__1<Fmx::Graphics::TBitmap*> >()) = 0 ;
};

class PASCALIMPLEMENTATION TBitmapCacheLayer : public System::TInterfacedObject
{
	typedef System::TInterfacedObject inherited;
	
private:
	Fmx::Graphics::TBitmap* FBitmap;
	bool FNeedUpdate;
	System::Types::TRectF FSavedDestRect;
	bool FSavedHighSpeed;
	float FSavedOpacity;
	Fmx::Graphics::TCanvas* FSavedTarget;
	
public:
	__fastcall virtual ~TBitmapCacheLayer();
	bool __fastcall BeginUpdate(Fmx::Graphics::TCanvas* const ATarget, const System::Types::TRectF &ADestRect, const float AOpacity, const bool AHighSpeed, /* out */ Fmx::Graphics::TCanvas* &ACacheCanvas);
	void __fastcall EndUpdate(const System::DelphiInterface<System::Sysutils::TProc__1<Fmx::Graphics::TBitmap*> > AGeneratedBitmap = System::DelphiInterface<System::Sysutils::TProc__1<Fmx::Graphics::TBitmap*> >());
	void __fastcall SetNeedUpdate();
public:
	/* TObject.Create */ inline __fastcall TBitmapCacheLayer() : System::TInterfacedObject() { }
	
private:
	void *__IBitmapCacheLayer;	// IBitmapCacheLayer 
	
public:
	#if defined(MANAGED_INTERFACE_OPERATORS)
	// {C321CAF5-994B-4B64-9E99-8903B7B6A67D}
	operator _di_IBitmapCacheLayer()
	{
		_di_IBitmapCacheLayer intf;
		this->GetInterface(intf);
		return intf;
	}
	#else
	operator IBitmapCacheLayer*(void) { return (IBitmapCacheLayer*)&__IBitmapCacheLayer; }
	#endif
	
};


_DECLARE_METACLASS(System::TMetaClass, TFilterClass);

_DECLARE_METACLASS(System::TMetaClass, TFilterContextClass);

enum class DECLSPEC_DENUM TFilterValueType : unsigned char { Float, Point, Color, Bitmap };

enum class DECLSPEC_DENUM TFilterImageType : unsigned char { Undefined, Bitmap, Texture };

typedef TFilterValueRec *PFilterValueRec;

struct DECLSPEC_DRECORD TFilterValueRec
{
public:
	System::UnicodeString Name;
	System::UnicodeString Desc;
	TFilterValueType ValueType;
	System::Rtti::TValue Value;
	System::Rtti::TValue Min;
	System::Rtti::TValue Max;
	System::Rtti::TValue Default;
	Fmx::Graphics::TBitmap* Bitmap;
	__fastcall TFilterValueRec(const System::UnicodeString AName, const System::UnicodeString ADesc, TFilterValueType AType, const System::Rtti::TValue &ADefault, const System::Rtti::TValue &AMin, const System::Rtti::TValue &AMax)/* overload */;
	__fastcall TFilterValueRec(const System::UnicodeString AName, const System::UnicodeString ADesc, TFilterValueType AType)/* overload */;
	__fastcall TFilterValueRec(const System::UnicodeString AName, const System::UnicodeString ADesc, System::Uitypes::TAlphaColor ADefault)/* overload */;
	__fastcall TFilterValueRec(const System::UnicodeString AName, const System::UnicodeString ADesc, float ADefault, float AMin, float AMax)/* overload */;
	__fastcall TFilterValueRec(const System::UnicodeString AName, const System::UnicodeString ADesc, const System::Types::TPointF &ADefault, const System::Types::TPointF &AMin, const System::Types::TPointF &AMax)/* overload */;
	TFilterValueRec() {}
};


typedef System::DynamicArray<TFilterValueRec> TFilterValueRecArray;

struct DECLSPEC_DRECORD TFilterRec
{
public:
	System::UnicodeString Name;
	System::UnicodeString Desc;
	TFilterValueRecArray Values;
	__fastcall TFilterRec(const System::UnicodeString AName, const System::UnicodeString ADesc, const TFilterValueRecArray AValues)/* overload */;
	TFilterRec() {}
};


class PASCALIMPLEMENTATION TFilter : public System::Classes::TPersistent
{
	typedef System::Classes::TPersistent inherited;
	
	
private:
	typedef System::DynamicArray<Fmx::Types3d::TContextShader*> _TFilter__1;
	
	
public:
	System::Rtti::TValue operator[](const System::UnicodeString Name) { return this->Values[Name]; }
	
private:
	static Fmx::Types3d::TContextShader* FDefaultVertexShader;
	static TFilter* FProcessingFilter;
	_di_IFilterCacheLayer FCacheLayer;
	TFilterContext* FFilterContext;
	TFilter* FInputFilter;
	System::Types::TSize FInputLayerSize;
	System::Types::TSize FInputSize;
	bool FKeepCurrentContext;
	bool FModified;
	System::Generics::Collections::TList__1<TFilter*>* FNotifierList;
	System::Types::TSize FOutputSize;
	bool FRecalcInputSize;
	bool FRecalcOutputSize;
	TFilter* FRootInputFilter;
	TFilterValueRecArray FValues;
	void __fastcall AddChangeNotifier(TFilter* const ATargetFilter);
	TFilterContextClass __fastcall GetBestFilterContext(const TFilterImageType AOutputType, const Fmx::Graphics::TCanvasClass AOutputCanvasClass);
	System::Rtti::TValue __fastcall GetFilterValue(const System::UnicodeString AName);
	Fmx::Graphics::TBitmap* __fastcall GetFilterValuesAsBitmap(const System::UnicodeString AName);
	System::Uitypes::TAlphaColor __fastcall GetFilterValuesAsColor(const System::UnicodeString AName);
	float __fastcall GetFilterValuesAsFloat(const System::UnicodeString AName);
	System::Types::TPointF __fastcall GetFilterValuesAsPoint(const System::UnicodeString AName);
	Fmx::Types3d::TTexture* __fastcall GetFilterValuesAsTexture(const System::UnicodeString AName);
	System::Types::TSize __fastcall GetOutputSize();
	void __fastcall RemoveChangeNotifier(TFilter* const ATargetFilter);
	void __fastcall SetFilterContextClass(const TFilterContextClass AContextClass);
	void __fastcall SetFilterValue(const System::UnicodeString AName, const System::Rtti::TValue &AValue);
	void __fastcall SetFilterValuesAsBitmap(const System::UnicodeString AName, Fmx::Graphics::TBitmap* const AValue);
	void __fastcall SetFilterValuesAsColor(const System::UnicodeString AName, const System::Uitypes::TAlphaColor AValue);
	void __fastcall SetFilterValuesAsFloat(const System::UnicodeString AName, const float AValue);
	void __fastcall SetFilterValuesAsPoint(const System::UnicodeString AName, const System::Types::TPointF &AValue);
	void __fastcall SetFilterValuesAsTexture(const System::UnicodeString AName, Fmx::Types3d::TTexture* const AValue);
	void __fastcall SetInputAsFilter(TFilter* const AValue);
	void __fastcall SetInputLayerSize(const System::Types::TSize &AValue);
	System::Types::TSize __fastcall GetInputSize();
	__property bool KeepCurrentContext = {read=FKeepCurrentContext, write=FKeepCurrentContext, nodefault};
	__property TFilter* RootInputFilter = {read=FRootInputFilter};
	__property System::Rtti::TValue Values[const System::UnicodeString Name] = {read=GetFilterValue, write=SetFilterValue/*, default*/};
	
protected:
	bool FAntiAliasing;
	System::UnicodeString FNeedInternalSecondTex;
	int FPass;
	int FPassCount;
	_TFilter__1 FShaders;
	Fmx::Types3d::TContextShader* FVertexShader;
	virtual void __fastcall CalcSize(int &W, int &H);
	void __fastcall Changed();
	void __fastcall FilterDestroying(TFilter* const AFilter);
	void __fastcall InputChanged();
	virtual void __fastcall LoadShaders();
	virtual void __fastcall LoadTextures();
	
public:
	__fastcall virtual TFilter();
	__fastcall virtual ~TFilter();
	virtual void __fastcall Apply();
	void __fastcall ApplyWithoutCopyToOutput();
	bool __fastcall BeginLayer(Fmx::Graphics::TCanvas* const ATarget, const System::Types::TRectF &ADestRect, const float AOpacity, const bool AHighSpeed, _di_IFilterCacheLayer &ACacheLayer, /* out */ Fmx::Graphics::TCanvas* &ACacheCanvas);
	void __fastcall EndLayer();
	System::Types::TSize __fastcall CalcOutputSize(const System::Types::TSize &AInputSize);
	__classmethod virtual TFilterRec __fastcall FilterAttr();
	static TFilterRec __fastcall FilterAttrForClass(TFilterClass C);
	__property TFilterContext* FilterContext = {read=FFilterContext};
	__property TFilter* InputFilter = {read=FInputFilter, write=SetInputAsFilter};
	__property System::Types::TSize InputSize = {read=GetInputSize};
	__property System::Types::TSize OutputSize = {read=GetOutputSize};
	__property Fmx::Graphics::TBitmap* ValuesAsBitmap[const System::UnicodeString Name] = {read=GetFilterValuesAsBitmap, write=SetFilterValuesAsBitmap};
	__property System::Uitypes::TAlphaColor ValuesAsColor[const System::UnicodeString Name] = {read=GetFilterValuesAsColor, write=SetFilterValuesAsColor};
	__property float ValuesAsFloat[const System::UnicodeString Name] = {read=GetFilterValuesAsFloat, write=SetFilterValuesAsFloat};
	__property System::Types::TPointF ValuesAsPoint[const System::UnicodeString Name] = {read=GetFilterValuesAsPoint, write=SetFilterValuesAsPoint};
	__property Fmx::Types3d::TTexture* ValuesAsTexture[const System::UnicodeString Name] = {read=GetFilterValuesAsTexture, write=SetFilterValuesAsTexture};
};


class PASCALIMPLEMENTATION TFilterManager : /*[[sealed]]*/ public System::TObject
{
	typedef System::TObject inherited;
	
	
private:
	typedef System::Generics::Collections::TDictionary__2<TFilterClass,System::UnicodeString> TFilterCategoryDict;
	typedef System::Generics::Collections::TDictionary__2<System::UnicodeString,TFilterClass> TFilterClassDict;
	typedef System::Generics::Collections::TDictionary__2<Fmx::Graphics::TCanvasClass,TFilterContextClass> TFilterContextClassDict;
	
private:
	static TFilterContextClass FDefaultFilterContextClass;
	static TFilterClassDict* FFilterList;
	static TFilterCategoryDict* FFilterCategoryList;
	static TFilterContextClassDict* FFilterContextDic;
	__classmethod TFilterContextClass __fastcall GetBestFilterContext(Fmx::Types3d::TContextShader* AVertexShader, Fmx::Types3d::TContextShader* const *AShaders, const System::NativeInt AShaders_High, int AShadersCount, Fmx::Graphics::TCanvasClass AInputCanvasClass, Fmx::Graphics::TCanvasClass AOutputCanvasClass, TFilterImageType AInputValue, TFilterImageType AOutputValue);
	
public:
	__classmethod void __fastcall FillCategory(System::Classes::TStrings* AList);
	__classmethod void __fastcall FillFiltersInCategory(const System::UnicodeString ACategory, System::Classes::TStrings* AList);
	__classmethod TFilter* __fastcall FilterByName(const System::UnicodeString AName);
	__classmethod TFilterClass __fastcall FilterClassByName(const System::UnicodeString AName);
	__classmethod void __fastcall RegisterFilter(const System::UnicodeString ACategory, TFilterClass AFilter);
	__classmethod void __fastcall RegisterFilterContextForCanvas(const TFilterContextClass AContextClass, const Fmx::Graphics::TCanvasClass ACanvasClass);
	__classmethod void __fastcall UnInitialize();
	__classmethod void __fastcall UnregisterFilter(TFilterClass AFilter);
	static TFilterContext* __fastcall FilterContext _DEPRECATED_ATTRIBUTE1("use TFilter.FilterContext instead") ();
	static Fmx::Types3d::TTexture* __fastcall FilterTexture _DEPRECATED_ATTRIBUTE1("use TFilter.ValuesAsTexture['Output'] instead") ();
public:
	/* TObject.Create */ inline __fastcall TFilterManager() : System::TObject() { }
	/* TObject.Destroy */ inline __fastcall virtual ~TFilterManager() { }
	
};


class PASCALIMPLEMENTATION TFilterContext : public System::TObject
{
	typedef System::TObject inherited;
	
private:
	TFilter* FFilter;
	bool FNoCopyForOutput;
	
protected:
	virtual void __fastcall Apply(int &APass, const bool AAntiAliasing, int APassCount, const System::UnicodeString ASecondImageResourceName) = 0 ;
	virtual bool __fastcall BeginLayer(Fmx::Graphics::TCanvas* const ATarget, const System::Types::TRectF &ADestRect, const float AOpacity, const bool AHighSpeed, _di_IFilterCacheLayer &ACacheLayer, /* out */ Fmx::Graphics::TCanvas* &ACacheCanvas);
	virtual void __fastcall Changed(const TFilterValueRec &AValue) = 0 ;
	virtual void __fastcall EnableBitmapOutput();
	virtual void __fastcall EndLayer(const _di_IFilterCacheLayer ACacheLayer);
	virtual void __fastcall LoadShaders();
	virtual void __fastcall LoadTextures();
	virtual Fmx::Graphics::TBitmap* __fastcall OutputAsBitmap() = 0 ;
	virtual Fmx::Types3d::TTexture* __fastcall OutputAsTexture() = 0 ;
	void __fastcall SetRootInputLayerSize(const System::Types::TSize &ASize);
	__classmethod virtual bool __fastcall SupportsShaders(Fmx::Types3d::TContextShader* AVertexShader, Fmx::Types3d::TContextShader* const *AShaders, const System::NativeInt AShaders_High, int AShadersCount);
	__property TFilter* Filter = {read=FFilter};
	__property bool NoCopyForOutput = {read=FNoCopyForOutput, write=FNoCopyForOutput, nodefault};
	
public:
	__fastcall virtual TFilterContext(TFilter* const AFilter, const TFilterValueRecArray AValue);
	__classmethod virtual Fmx::Types3d::TContextStyles __fastcall Style();
	virtual __classmethod void __fastcall UnInitialize() = 0 ;
	virtual void __fastcall CopyToBitmap(Fmx::Graphics::TBitmap* const ADest, const System::Types::TRect &ARect) = 0 ;
	virtual void __fastcall SetInputToShaderVariable(const System::UnicodeString AName) = 0 ;
	virtual void __fastcall SetShaders(Fmx::Types3d::TContextShader* const AVertexShader, Fmx::Types3d::TContextShader* const APixelShader) = 0 ;
	virtual void __fastcall SetShaderVariable(const System::UnicodeString AName, const System::Math::Vectors::TVector3D *AData, const System::NativeInt AData_High) = 0 /* overload */;
	virtual void __fastcall SetShaderVariable(const System::UnicodeString AName, Fmx::Types3d::TTexture* const ATexture) = 0 /* overload */;
	virtual void __fastcall SetShaderVariable(const System::UnicodeString AName, const System::Math::Vectors::TMatrix3D &AMatrix) = 0 /* overload */;
	virtual void __fastcall SetShaderVariable(const System::UnicodeString AName, const System::Uitypes::TAlphaColor AColor) = 0 /* overload */;
public:
	/* TObject.Destroy */ inline __fastcall virtual ~TFilterContext() { }
	
};


class PASCALIMPLEMENTATION EFilterException : public System::Sysutils::Exception
{
	typedef System::Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall EFilterException(const System::UnicodeString Msg) : System::Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall EFilterException(const System::UnicodeString Msg, const System::TVarRec *Args, const System::NativeInt Args_High) : System::Sysutils::Exception(Msg, Args, Args_High) { }
	/* Exception.CreateRes */ inline __fastcall EFilterException(System::NativeUInt Ident)/* overload */ : System::Sysutils::Exception(Ident) { }
	/* Exception.CreateRes */ inline __fastcall EFilterException(System::PResStringRec ResStringRec)/* overload */ : System::Sysutils::Exception(ResStringRec) { }
	/* Exception.CreateResFmt */ inline __fastcall EFilterException(System::NativeUInt Ident, const System::TVarRec *Args, const System::NativeInt Args_High)/* overload */ : System::Sysutils::Exception(Ident, Args, Args_High) { }
	/* Exception.CreateResFmt */ inline __fastcall EFilterException(System::PResStringRec ResStringRec, const System::TVarRec *Args, const System::NativeInt Args_High)/* overload */ : System::Sysutils::Exception(ResStringRec, Args, Args_High) { }
	/* Exception.CreateHelp */ inline __fastcall EFilterException(const System::UnicodeString Msg, int AHelpContext) : System::Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EFilterException(const System::UnicodeString Msg, const System::TVarRec *Args, const System::NativeInt Args_High, int AHelpContext) : System::Sysutils::Exception(Msg, Args, Args_High, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EFilterException(System::NativeUInt Ident, int AHelpContext)/* overload */ : System::Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EFilterException(System::PResStringRec ResStringRec, int AHelpContext)/* overload */ : System::Sysutils::Exception(ResStringRec, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EFilterException(System::PResStringRec ResStringRec, const System::TVarRec *Args, const System::NativeInt Args_High, int AHelpContext)/* overload */ : System::Sysutils::Exception(ResStringRec, Args, Args_High, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EFilterException(System::NativeUInt Ident, const System::TVarRec *Args, const System::NativeInt Args_High, int AHelpContext)/* overload */ : System::Sysutils::Exception(Ident, Args, Args_High, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EFilterException() { }
	
};


class PASCALIMPLEMENTATION EFilterManagerException : public System::Sysutils::Exception
{
	typedef System::Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall EFilterManagerException(const System::UnicodeString Msg) : System::Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall EFilterManagerException(const System::UnicodeString Msg, const System::TVarRec *Args, const System::NativeInt Args_High) : System::Sysutils::Exception(Msg, Args, Args_High) { }
	/* Exception.CreateRes */ inline __fastcall EFilterManagerException(System::NativeUInt Ident)/* overload */ : System::Sysutils::Exception(Ident) { }
	/* Exception.CreateRes */ inline __fastcall EFilterManagerException(System::PResStringRec ResStringRec)/* overload */ : System::Sysutils::Exception(ResStringRec) { }
	/* Exception.CreateResFmt */ inline __fastcall EFilterManagerException(System::NativeUInt Ident, const System::TVarRec *Args, const System::NativeInt Args_High)/* overload */ : System::Sysutils::Exception(Ident, Args, Args_High) { }
	/* Exception.CreateResFmt */ inline __fastcall EFilterManagerException(System::PResStringRec ResStringRec, const System::TVarRec *Args, const System::NativeInt Args_High)/* overload */ : System::Sysutils::Exception(ResStringRec, Args, Args_High) { }
	/* Exception.CreateHelp */ inline __fastcall EFilterManagerException(const System::UnicodeString Msg, int AHelpContext) : System::Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EFilterManagerException(const System::UnicodeString Msg, const System::TVarRec *Args, const System::NativeInt Args_High, int AHelpContext) : System::Sysutils::Exception(Msg, Args, Args_High, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EFilterManagerException(System::NativeUInt Ident, int AHelpContext)/* overload */ : System::Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EFilterManagerException(System::PResStringRec ResStringRec, int AHelpContext)/* overload */ : System::Sysutils::Exception(ResStringRec, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EFilterManagerException(System::PResStringRec ResStringRec, const System::TVarRec *Args, const System::NativeInt Args_High, int AHelpContext)/* overload */ : System::Sysutils::Exception(ResStringRec, Args, Args_High, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EFilterManagerException(System::NativeUInt Ident, const System::TVarRec *Args, const System::NativeInt Args_High, int AHelpContext)/* overload */ : System::Sysutils::Exception(Ident, Args, Args_High, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EFilterManagerException() { }
	
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Filter */
}	/* namespace Fmx */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX_FILTER)
using namespace Fmx::Filter;
#endif
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_FMX)
using namespace Fmx;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Fmx_FilterHPP
