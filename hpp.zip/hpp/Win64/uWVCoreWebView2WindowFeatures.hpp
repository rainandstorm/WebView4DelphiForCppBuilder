﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2WindowFeatures.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2windowfeaturesHPP
#define Uwvcorewebview2windowfeaturesHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2windowfeatures
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2WindowFeatures;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2WindowFeatures : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2WindowFeatures FBaseIntf;
	bool __fastcall GetInitialized();
	bool __fastcall GetHasPosition();
	bool __fastcall GetHasSize();
	unsigned __fastcall GetLeft();
	unsigned __fastcall GetTop();
	unsigned __fastcall GetWidth();
	unsigned __fastcall GetHeight();
	bool __fastcall GetShouldDisplayMenuBar();
	bool __fastcall GetShouldDisplayStatus();
	bool __fastcall GetShouldDisplayToolbar();
	bool __fastcall GetShouldDisplayScrollBars();
	
public:
	__fastcall TCoreWebView2WindowFeatures(const Uwvtypelibrary::_di_ICoreWebView2WindowFeatures aBaseIntf);
	__fastcall virtual ~TCoreWebView2WindowFeatures();
	void __fastcall CopyToRecord(Uwvtypes::TWVWindowFeatures &aWindowFeatures);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2WindowFeatures BaseIntf = {read=FBaseIntf};
	__property bool HasPosition = {read=GetHasPosition, nodefault};
	__property bool HasSize = {read=GetHasSize, nodefault};
	__property unsigned Left = {read=GetLeft, nodefault};
	__property unsigned Top = {read=GetTop, nodefault};
	__property unsigned Width = {read=GetWidth, nodefault};
	__property unsigned Height = {read=GetHeight, nodefault};
	__property bool ShouldDisplayMenuBar = {read=GetShouldDisplayMenuBar, nodefault};
	__property bool ShouldDisplayStatus = {read=GetShouldDisplayStatus, nodefault};
	__property bool ShouldDisplayToolbar = {read=GetShouldDisplayToolbar, nodefault};
	__property bool ShouldDisplayScrollBars = {read=GetShouldDisplayScrollBars, nodefault};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2windowfeatures */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2WINDOWFEATURES)
using namespace Uwvcorewebview2windowfeatures;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2windowfeaturesHPP
