﻿// CodeGear C++Builder
// Copyright (c) 1995, 2024 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'uWVCoreWebView2HttpRequestHeaders.pas' rev: 36.00 (Windows)

#ifndef Uwvcorewebview2httprequestheadersHPP
#define Uwvcorewebview2httprequestheadersHPP

#pragma delphiheader begin
#pragma option push
#if defined(__BORLANDC__) && !defined(__clang__)
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member 
#endif
#pragma pack(push,8)
#include <System.hpp>
#include <SysInit.hpp>
#include <uWVTypeLibrary.hpp>
#include <uWVTypes.hpp>

//-- user supplied -----------------------------------------------------------

namespace Uwvcorewebview2httprequestheaders
{
//-- forward type declarations -----------------------------------------------
class DELPHICLASS TCoreWebView2HttpRequestHeaders;
//-- type declarations -------------------------------------------------------
class PASCALIMPLEMENTATION TCoreWebView2HttpRequestHeaders : public System::TObject
{
	typedef System::TObject inherited;
	
protected:
	Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders FBaseIntf;
	bool __fastcall GetInitialized();
	Uwvtypelibrary::_di_ICoreWebView2HttpHeadersCollectionIterator __fastcall GetIterator();
	
public:
	__fastcall TCoreWebView2HttpRequestHeaders(const Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders aBaseIntf);
	__fastcall virtual ~TCoreWebView2HttpRequestHeaders();
	bool __fastcall SetHeader(const Uwvtypes::wvstring aName, const Uwvtypes::wvstring aValue);
	Uwvtypes::wvstring __fastcall GetHeader(const Uwvtypes::wvstring aName);
	bool __fastcall GetHeaders(const Uwvtypes::wvstring aName, Uwvtypelibrary::_di_ICoreWebView2HttpHeadersCollectionIterator &aValue);
	bool __fastcall Contains(const Uwvtypes::wvstring aValue);
	bool __fastcall RemoveHeader(const Uwvtypes::wvstring aName);
	__property bool Initialized = {read=GetInitialized, nodefault};
	__property Uwvtypelibrary::_di_ICoreWebView2HttpRequestHeaders BaseIntf = {read=FBaseIntf};
	__property Uwvtypelibrary::_di_ICoreWebView2HttpHeadersCollectionIterator Iterator = {read=GetIterator};
};


//-- var, const, procedure ---------------------------------------------------
}	/* namespace Uwvcorewebview2httprequestheaders */
#if !defined(DELPHIHEADER_NO_IMPLICIT_NAMESPACE_USE) && !defined(NO_USING_NAMESPACE_UWVCOREWEBVIEW2HTTPREQUESTHEADERS)
using namespace Uwvcorewebview2httprequestheaders;
#endif
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Uwvcorewebview2httprequestheadersHPP
